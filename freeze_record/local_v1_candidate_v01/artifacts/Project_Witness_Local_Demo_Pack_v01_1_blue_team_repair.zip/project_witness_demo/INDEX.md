# Project Witness — Local Demo Pack v0.1

**Move 40 freeze. Do not modify.**

---

## Authority note

The authoritative frozen baseline is `START_HERE/artifacts/frozen_working_projects_baseline.zip`. The organised folders outside `START_HERE/` are reviewer convenience copies of the same frozen materials.

## How to start

Open `START_HERE/` and run:

```bash
python tools/verify_local_demo_pack.py
```

Expected result: `LOCAL_DEMO_PACK_VERIFIED — verify_ok = true`

Then read `START_HERE/START_HERE.md` for the full inspection sequence.

---

## Folder guide

### START_HERE/
The Move 40 freeze wrapper. Contains the manifest, checksums, verifier, known-limits summary, release gate, and freeze record. **Start here.**

### 01_Foundation/
The canonical component artifacts, in pipeline order (Moves 1–29).

| Folder | Move | Description |
|---|---|---|
| Sentinel Core | 1–3 | Action gate — ALLOW/BLOCK/DRY_RUN with INTENT/RESULT receipts and tamper-evident replay |
| Histor-lite | 4 | Append-only case store; imports Sentinel run files |
| Case Bundle v0.1 | 5 | First case bundle format |
| Case Bundle v0.2 | 18 | Revised case bundle with verifier |
| Coordinator Workflow v0.1.8 | 6 | Orchestrates Sentinel → Histor → Case Bundle |
| Companion CLI v0.1 | 7 | Human-facing entry point driving the Coordinator |
| Aletheia Evidence Bundle | 9 | Evidence file packaging and manifest |
| ODIN Claim Reasoner | 10 | Deterministic structural claim reasoner |
| Aletheia ODIN Bridge | 13 | Converts Aletheia evidence manifests to ODIN claim format |
| Evidence Reasoning Demo | 14–15 | End-to-end evidence → ODIN reasoning demonstration |
| Histor-lite Aletheia Importer | 16 | Imports Aletheia bundles into Histor-lite |
| Histor-lite ODIN Importer | 17 | Imports ODIN outputs into Histor-lite |
| Atlas Registry | 21 | Controlled vocabulary registry for workflow statuses |
| Atlas Release Gate | 22 | Validates Coordinator outputs against the Atlas Registry |
| Unified Case Manifest | 26 | Cross-component manifest covering all pipeline outputs |
| Stack Verifier | 27 | Verifies the full assembled stack output end-to-end |

### 02_Red_Blue_Packs/
Adversarial test packs for each major component. Blue tests confirm correct behaviour; red tests confirm correct rejection of invalid or hostile inputs.

| Pack | Component |
|---|---|
| sentinel_red_blue_pack_v01 | Sentinel Core |
| project_witness_workflow_red_blue_pack_v01 | Full workflow |
| odin_red_blue_pack_v01 | ODIN Claim Reasoner |
| Atlas Red Blue Pack | Atlas Registry / Release Gate |
| Stack Red Blue Pack v0.2 | Full stack |

### 03_Repair_Chain/
All intermediate repair versions, in chronological order. These record how the stack evolved — each version has its own REPAIR_LEDGER documenting exactly what was fixed and why. Not needed for a first review; included for completeness and auditability.

### 04_Demo_and_Usability/
Runnable demonstration material (Moves 30–34).

| Folder | Description |
|---|---|
| Connected Demo | Scripted end-to-end pipeline run |
| Beginner Runbook | Step-by-step guide for a first-time reviewer |
| One Command Demo Script | Single-command pipeline invocation |
| Demo Output Bundle | Pre-produced output from a real pipeline run |
| Architecture Diagram | Visual pipeline map |
| E2E Pipeline Output (Step 20) | Frozen real output from a full Companion → Stack run |

### 05_Reviewability/
The honest reviewability layer (Moves 35–39).

| Folder | Description |
|---|---|
| Master Known Limitations | 37 documented limitations; distinguishes what the stack does from what it does not |
| Threat Model | What Sentinel and the stack defend against and what they do not |
| External Review Pack | Packaged material for an external reviewer |
| Hostile Review Prompt Pack | Pre-written hostile review prompts to stress-test documentation claims |
| Response to Review Ledger | Structured ledger for recording and tracking review findings |

### 06_Roadmap/
The 70-step Project Witness Part One roadmap is complete through Step 40. Steps 41–70 remain future work.

---

## Truth boundary

This pack preserves and verifies structured provenance relationships between files, hashes, manifests, receipts, statuses, and declared workflow outputs under tested local conditions.

It does not prove external truth, authenticate sources, sign outputs, externally anchor outputs, or claim production readiness.

The full limitation set is in `05_Reviewability/Master Known Limitations/`.
