# Finding Schema

## Required fields

Every future review finding must use this schema.

```text
Finding ID:
Source:
Prompt or review method:
Date received:
Reviewed artifact:
Artifact version:
Exact evidence:
Missing evidence statement:
Reviewer claim:
Project response:
Severity:
Status:
Closure requirement:
Closure evidence:
Blocks current move?
Blocks Move 40?
Future roadmap area if deferred:
Decision rationale:
Linked repair artifact:
Verifier evidence:
Checksum evidence:
Final decision:
```

## Field rules

### Finding ID

Must use:

```text
RTR-YYYYMMDD-001
```

### Source

Examples:

```text
external reviewer
hostile review prompt HRP-001
manual review
self-review
```

Do not describe self-review as external review.

### Exact evidence

Use exact file names, headings, phrases, command output, or checksum references where available.

If evidence is missing, say:

```text
No evidence supplied.
Cannot determine from supplied material.
```

### Project response

The response must be one of:

```text
ACCEPT
REJECT_WITH_REASON
REQUEST_MORE_EVIDENCE
DEFER_WITH_LIMITATION
FIX
```

### Severity

Allowed values:

```text
BLOCKER
MAJOR
MINOR
NOTE
```

### Status

Allowed values:

```text
OPEN
ACCEPTED
REJECTED_WITH_REASON
NEEDS_MORE_EVIDENCE
DEFERRED_WITH_LIMITATION
FIXED_PENDING_VERIFICATION
CLOSED_VERIFIED
DISPUTED
```

## JSON-style canonical field list

```json
{
  "finding_id": "",
  "source": "",
  "prompt_or_review_method": "",
  "date_received": "",
  "reviewed_artifact": "",
  "artifact_version": "",
  "exact_evidence": "",
  "missing_evidence_statement": "",
  "reviewer_claim": "",
  "project_response": "",
  "severity": "",
  "status": "",
  "closure_requirement": "",
  "closure_evidence": "",
  "blocks_current_move": "",
  "blocks_move_40": "",
  "future_roadmap_area_if_deferred": "",
  "decision_rationale": "",
  "linked_repair_artifact": "",
  "verifier_evidence": "",
  "checksum_evidence": "",
  "final_decision": ""
}
```
