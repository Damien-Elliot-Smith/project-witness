#!/usr/bin/env python3
from pathlib import Path
import sys
import re

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "RESPONSE_TO_REVIEW_LEDGER.md",
    "FINDING_SCHEMA.md",
    "RESPONSE_POLICY.md",
    "SEVERITY_AND_STATUS.md",
    "CLOSURE_POLICY.md",
    "LEDGER_TEMPLATE.md",
    "REVIEW_RESPONSE_TEMPLATE.md",
    "MOVE_40_CARRY_FORWARD.md",
    "SCOPE_BOUNDARY.md",
    "RELEASE_GATE.md",
    "VERIFICATION.md",
    "TEST_RESULTS.md",
    "REPAIR_LEDGER.md",
    "CHECKSUMS.txt",
    "tools/verify_response_to_review_ledger.py",
]

REQUIRED_PHRASES = {
    "README.md": [
        "Move 39",
        "Response-to-Review Ledger",
        "No real external review findings are recorded",
        "RESPONSE_TO_REVIEW_LEDGER_VERIFIED",
    ],
    "RESPONSE_TO_REVIEW_LEDGER.md": [
        "Current real external findings recorded: 0",
        "Current hostile prompt findings recorded: 0",
        "Move 40 local demo pack frozen: no",
        "Do not invent findings",
        "A BLOCKER cannot be closed by explanation alone",
    ],
    "FINDING_SCHEMA.md": [
        "Finding ID:",
        "Source:",
        "Exact evidence:",
        "Project response:",
        "Closure evidence:",
        "Blocks Move 40?",
        "Do not describe self-review as external review",
    ],
    "RESPONSE_POLICY.md": [
        "Do not reword a finding to make it weaker",
        "Do not mark self-review as independent external review",
        "Accepted response types",
        "DEFER_WITH_LIMITATION",
    ],
    "SEVERITY_AND_STATUS.md": [
        "BLOCKER",
        "MAJOR",
        "MINOR",
        "NOTE",
        "CLOSED_VERIFIED",
        "Move 39 does not freeze Move 40",
    ],
    "CLOSURE_POLICY.md": [
        "Closure evidence",
        "CLOSED_VERIFIED",
        "Deferred findings must not disappear",
    ],
    "LEDGER_TEMPLATE.md": [
        "Ledger Entry Template",
        "The example above must not be counted as a real finding",
    ],
    "REVIEW_RESPONSE_TEMPLATE.md": [
        "Independent external review? yes/no",
        "This response does not prove the project is correct",
    ],
    "MOVE_40_CARRY_FORWARD.md": [
        "Real findings recorded: 0",
        "Open blockers for Move 40: 0",
        "This file does not freeze Move 40",
    ],
    "SCOPE_BOUNDARY.md": [
        "Move 39",
        "Local Demo Pack freeze",
        "must not freeze Move 40",
    ],
    "RELEASE_GATE.md": [
        "PASS criteria",
        "FAIL criteria",
        "Package states no real findings are recorded yet",
        "Package states Move 40 is not frozen",
    ],
    "VERIFICATION.md": [
        "What the verifier checks",
        "It does not prove external review has occurred",
        "It does not sign or externally anchor this package",
    ],
    "TEST_RESULTS.md": [
        "RESPONSE_TO_REVIEW_LEDGER_VERIFIED",
        "verify_ok = true",
        "ResourceWarning sweep",
        "Runtime code tests",
    ],
    "REPAIR_LEDGER.md": [
        "Repair Ledger",
        "No open repairs",
    ],
}

FORBIDDEN_DIRS = [
    "ConnectedDemo_FREEZES",
    "BeginnerRunbook_FREEZES",
    "OneCommandDemoScript_FREEZES",
    "DemoOutputBundle_FREEZES",
    "ArchitectureDiagram_FREEZES",
    "Coordinator_FREEZES",
    "Companion_FREEZES",
    "StackSelfcheck_FREEZES",
    "src",
    "app",
    "web",
    "android",
    "windows",
    "runtime",
]

REQUIRED_SCHEMA_FIELDS = [
    "Finding ID:",
    "Source:",
    "Prompt or review method:",
    "Date received:",
    "Reviewed artifact:",
    "Artifact version:",
    "Exact evidence:",
    "Missing evidence statement:",
    "Reviewer claim:",
    "Project response:",
    "Severity:",
    "Status:",
    "Closure requirement:",
    "Closure evidence:",
    "Blocks current move?",
    "Blocks Move 40?",
    "Future roadmap area if deferred:",
    "Decision rationale:",
    "Linked repair artifact:",
    "Verifier evidence:",
    "Checksum evidence:",
    "Final decision:",
]

def fail(message: str) -> None:
    print(f"VERIFY_FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

def read(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        fail(f"missing required file: {rel}")
    return path.read_text(encoding="utf-8")

def main() -> None:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            fail(f"missing required file: {rel}")

    for rel, phrases in REQUIRED_PHRASES.items():
        text = read(rel)
        for phrase in phrases:
            if phrase not in text:
                fail(f"{rel} missing required phrase: {phrase}")

    schema = read("FINDING_SCHEMA.md")
    for field in REQUIRED_SCHEMA_FIELDS:
        if field not in schema:
            fail(f"FINDING_SCHEMA.md missing field: {field}")

    ledger = read("RESPONSE_TO_REVIEW_LEDGER.md")
    if "Current real external findings recorded: 0" not in ledger:
        fail("ledger must state zero real external findings")
    if "Current hostile prompt findings recorded: 0" not in ledger:
        fail("ledger must state zero hostile prompt findings")
    if "Move 40 local demo pack frozen: no" not in ledger:
        fail("ledger must state Move 40 is not frozen")

    severity = read("SEVERITY_AND_STATUS.md")
    for value in ["BLOCKER", "MAJOR", "MINOR", "NOTE", "OPEN", "ACCEPTED", "REJECTED_WITH_REASON", "NEEDS_MORE_EVIDENCE", "DEFERRED_WITH_LIMITATION", "FIXED_PENDING_VERIFICATION", "CLOSED_VERIFIED", "DISPUTED"]:
        if value not in severity:
            fail(f"severity/status rules missing value: {value}")

    policy = read("RESPONSE_POLICY.md")
    for response_type in ["ACCEPT", "REJECT_WITH_REASON", "REQUEST_MORE_EVIDENCE", "DEFER_WITH_LIMITATION", "FIX"]:
        if response_type not in policy:
            fail(f"response policy missing type: {response_type}")

    closure = read("CLOSURE_POLICY.md")
    for phrase in ["closure evidence is present", "verification command/result is recorded", "Deferred findings must not disappear"]:
        if phrase not in closure:
            fail(f"closure policy missing phrase: {phrase}")

    scope = read("SCOPE_BOUNDARY.md")
    if "Move 39 may prepare carry-forward rules for Move 40, but must not freeze Move 40." not in scope:
        fail("scope boundary does not clearly stop Move 40 freeze")

    release_gate = read("RELEASE_GATE.md")
    for claim in [
        "Package does not claim truth proof",
        "Package does not claim external reality verification",
        "Package does not claim production readiness",
    ]:
        if claim not in release_gate:
            fail(f"release gate missing overclaim guard: {claim}")

    # No forbidden runtime/project dirs.
    for name in FORBIDDEN_DIRS:
        if (ROOT / name).exists():
            fail(f"forbidden directory present: {name}")

    # Tools directory must contain only the verifier.
    tools = ROOT / "tools"
    tool_files = [p.relative_to(ROOT).as_posix() for p in tools.rglob("*") if p.is_file()]
    if tool_files != ["tools/verify_response_to_review_ledger.py"]:
        fail(f"unexpected tools contents: {tool_files}")

    # CHECKSUMS should include every non-CHECKSUMS file.
    checksums = read("CHECKSUMS.txt")
    expected_files = []
    for p in ROOT.rglob("*"):
        if p.is_file():
            rel = p.relative_to(ROOT).as_posix()
            if rel != "CHECKSUMS.txt":
                expected_files.append(rel)
    for rel in sorted(expected_files):
        if rel not in checksums:
            fail(f"CHECKSUMS.txt missing entry for {rel}")

    print("RESPONSE_TO_REVIEW_LEDGER_VERIFIED")
    print("verify_ok = true")

if __name__ == "__main__":
    main()
