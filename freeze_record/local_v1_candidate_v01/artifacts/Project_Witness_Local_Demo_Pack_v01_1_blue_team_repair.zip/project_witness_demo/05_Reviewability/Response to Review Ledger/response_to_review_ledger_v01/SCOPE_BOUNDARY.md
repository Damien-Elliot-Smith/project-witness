# Scope Boundary

## Current move

This package is **Move 39 — Response-to-Review Ledger v0.1**.

It may create documentation, ledger structure, templates, release gate, checksums, and a verifier.

## Allowed

Allowed content:

- response-to-review ledger
- finding schema
- response policy
- severity and status rules
- closure policy
- ledger template
- review response template
- Move 40 carry-forward register
- release gate
- verification notes
- test results
- repair ledger
- checksums
- deterministic verifier for this package

## Not allowed

This move must not create:

- Local Demo Pack freeze
- production audit result
- external review result pretending to be real
- runtime code
- new workflow
- new action type
- new Atlas terms
- new Sentinel behaviour
- new ODIN behaviour
- new Histor-lite behaviour
- new Coordinator behaviour
- new Companion behaviour
- GUI
- Android app
- Windows app
- web UI
- LLM integration
- signing
- anchoring
- queues
- concurrency
- organisation governance

## Future move

```text
Move 40 — Freeze Project Witness Local Demo Pack
```

Move 39 may prepare carry-forward rules for Move 40, but must not freeze Move 40.

## Documentation authority limit

This ledger cannot make runtime behaviour true.

It can only record review findings, responses, closure evidence, and carry-forward status.
