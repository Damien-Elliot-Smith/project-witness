# Ledger Entry Template

Copy this for each future finding.

```text
Finding ID:
Source:
Prompt or review method:
Date received:
Reviewed artifact:
Artifact version:
Exact evidence:
Missing evidence statement:
Reviewer claim:
Project response:
Severity:
Status:
Closure requirement:
Closure evidence:
Blocks current move?
Blocks Move 40?
Future roadmap area if deferred:
Decision rationale:
Linked repair artifact:
Verifier evidence:
Checksum evidence:
Final decision:
```

## Example placeholder

This is a placeholder only, not a real finding.

```text
Finding ID: RTR-YYYYMMDD-001
Source: hostile review prompt HRP-001
Prompt or review method: Truth Boundary Attack
Date received: YYYY-MM-DD
Reviewed artifact: example.md
Artifact version: v0.1
Exact evidence: "example wording"
Missing evidence statement: n/a
Reviewer claim: wording may imply truth proof
Project response: ACCEPT
Severity: BLOCKER
Status: OPEN
Closure requirement: weaken wording and rerun verifier
Closure evidence: pending
Blocks current move? yes
Blocks Move 40? yes
Future roadmap area if deferred: n/a
Decision rationale: truth-proof overclaim blocks release
Linked repair artifact: pending
Verifier evidence: pending
Checksum evidence: pending
Final decision: pending
```

The example above must not be counted as a real finding.
