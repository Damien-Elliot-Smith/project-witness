# Response-to-Review Ledger v0.1

## Truth boundary

This ledger does not prove Project Witness is correct, secure, production-ready, or externally reviewed.

It records review findings and the project's responses to those findings.

A finding is not closed merely because it has been answered.  
A finding is closed only when the closure rule for its severity has been satisfied.

## Current status

```text
Ledger version: v0.1
Roadmap move: Move 39
Current real external findings recorded: 0
Current hostile prompt findings recorded: 0
Current closed findings: 0
Current open findings: 0
Current disputed findings: 0
Move 40 local demo pack frozen: no
```

## Ledger entries

No real findings have been entered yet.

This is deliberate.  
Do not invent findings to make the ledger look active.

When findings are received, add them using the schema in `FINDING_SCHEMA.md`.

## Required entry fields

Every future finding must include:

```text
Finding ID
Source
Prompt or review method
Date received
Reviewed artifact
Exact evidence or missing-evidence statement
Reviewer claim
Project response
Severity
Status
Closure requirement
Closure evidence
Blocks current move?
Blocks Move 40?
Future roadmap area if deferred
Decision rationale
```

## Finding ID format

Use deterministic IDs:

```text
RTR-YYYYMMDD-001
RTR-YYYYMMDD-002
RTR-YYYYMMDD-003
```

Do not reuse IDs.

## Status values

Allowed status values:

```text
OPEN
ACCEPTED
REJECTED_WITH_REASON
NEEDS_MORE_EVIDENCE
DEFERRED_WITH_LIMITATION
FIXED_PENDING_VERIFICATION
CLOSED_VERIFIED
DISPUTED
```

## Severity values

Allowed severity values:

```text
BLOCKER
MAJOR
MINOR
NOTE
```

## Blocker rule

A BLOCKER cannot be closed by explanation alone.

A BLOCKER requires one of:

```text
artifact correction plus verifier pass
scope correction plus release gate pass
documented limitation plus removal of overclaim
explicit deferral plus proof that current release does not claim the blocked capability
```

## Anti-fake-green rule

The ledger must not mark a finding closed unless closure evidence is present.

Examples of invalid closure evidence:

```text
"I think this is fine."
"Claude/ChatGPT says it is okay."
"The project intention is clear."
"No one will misunderstand it."
"Future versions will fix it."
```

## Move 40 boundary

This ledger may prepare for Move 40 but must not freeze Move 40.

Move 40 remains future work.

## Ledger authority limit

This ledger does not itself fix bugs, correct documents, verify runtime behaviour, or prove external review.

It records review handling so that issues cannot disappear silently.
