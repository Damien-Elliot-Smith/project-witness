# Review Response Template

Use this to answer a batch of findings.

```text
Review source:
Date reviewed:
Artifacts reviewed:
Package/version:
Reviewer:
Independent external review? yes/no

Summary:
- Findings received:
- Blockers:
- Major:
- Minor:
- Notes:
- Accepted:
- Rejected with reason:
- Deferred with limitation:
- Fixed pending verification:
- Closed verified:

Finding responses:

[Finding ID]
Decision:
Reason:
Action taken:
Verification evidence:
Checksum evidence:
Remaining limitation:
Blocks current move?
Blocks Move 40?
Next required action:
```

## Required honesty statement

Every batch response should include:

```text
This response does not prove the project is correct, secure, production-ready, or externally verified. It only records how the listed findings were handled.
```
