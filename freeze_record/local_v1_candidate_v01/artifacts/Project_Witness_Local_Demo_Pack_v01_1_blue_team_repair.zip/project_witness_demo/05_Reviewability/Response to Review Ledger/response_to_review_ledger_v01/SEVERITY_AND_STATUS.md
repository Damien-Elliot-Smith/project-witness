# Severity and Status Rules

## Severity

| Severity | Meaning | Closure requirement |
|---|---|---|
| BLOCKER | Prevents freeze/release of the relevant package unless fixed, removed, or explicitly scoped out with evidence | must have correction or documented non-claim plus verifier/release-gate evidence |
| MAJOR | Serious issue that may not block current move if honestly documented | must have response, limitation, or future roadmap mapping |
| MINOR | Clarity, wording, formatting, or small reviewability issue | must have response or accepted backlog entry |
| NOTE | Observation that may help but does not require repair | may be acknowledged without repair |

## Status

| Status | Meaning |
|---|---|
| OPEN | Finding has not been answered |
| ACCEPTED | Finding is accepted but not yet fixed or closed |
| REJECTED_WITH_REASON | Finding is rejected with evidence and rationale |
| NEEDS_MORE_EVIDENCE | Finding cannot be assessed from supplied material |
| DEFERRED_WITH_LIMITATION | Finding is real but belongs to a future roadmap area and is documented as a current limit |
| FIXED_PENDING_VERIFICATION | A fix exists but has not passed verification |
| CLOSED_VERIFIED | Closure evidence exists and verification passed |
| DISPUTED | The finding remains unresolved after response |

## Blocker handling

A blocker remains a blocker until one of these happens:

```text
fixed and verified
overclaim removed
missing evidence supplied
release claim weakened
artifact excluded from current release scope
```

## What cannot close a finding

These cannot close a finding:

```text
author confidence
LLM reassurance
good intentions
roadmap promises without limitation wording
unchecked edits
uncited claims
unverified command output
```

## Move 40 rule

Any unresolved blocker marked as blocking Move 40 must be carried forward.

Move 39 does not freeze Move 40.
