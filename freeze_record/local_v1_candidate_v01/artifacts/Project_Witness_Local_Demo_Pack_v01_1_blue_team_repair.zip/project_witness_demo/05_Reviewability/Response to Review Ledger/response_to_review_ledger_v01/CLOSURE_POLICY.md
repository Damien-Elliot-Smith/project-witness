# Closure Policy

## Purpose

Closure means a finding has been dealt with in a way that is visible, testable where possible, and honest about limits.

## Closure evidence by finding type

| Finding type | Required closure evidence |
|---|---|
| Documentation overclaim | corrected wording plus verifier/release-gate pass |
| Missing limitation | added limitation plus index/update evidence |
| Scope creep | removal or future-work reclassification |
| False green | corrected verifier/test/release wording |
| Missing checksum | checksum file regenerated and checked |
| Missing reviewability instruction | instruction added and verified |
| Runtime issue | not closable by this documentation ledger unless a proper repair artifact exists |
| Future feature gap | documented as future work and not claimed as current capability |

## Closed verified status

A finding may be marked `CLOSED_VERIFIED` only when:

```text
closure requirement is stated
closure evidence is present
verification command/result is recorded if applicable
checksum evidence is updated if applicable
remaining limitation is documented if applicable
```

## Deferred findings

Deferred findings must not disappear.

A deferred finding needs:

```text
future roadmap area
current limitation statement
reason it does not block current release
claim that must not be made yet
```

## Disputed findings

A disputed finding must keep the original reviewer claim visible.

Do not delete the finding because the project disagrees.
