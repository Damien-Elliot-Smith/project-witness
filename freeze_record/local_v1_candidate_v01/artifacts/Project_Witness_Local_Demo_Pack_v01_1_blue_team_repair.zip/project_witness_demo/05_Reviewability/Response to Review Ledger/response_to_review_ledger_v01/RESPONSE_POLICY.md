# Response Policy

## Purpose

The response policy prevents defensive or cosmetic handling of review findings.

The project must treat hostile review as useful pressure, not as an insult.

## Core rules

1. Do not reword a finding to make it weaker.
2. Do not close a finding without closure evidence.
3. Do not mark self-review as independent external review.
4. Do not treat an LLM answer as proof.
5. Do not treat a checksum as proof of identity, origin, or trust.
6. Do not treat deterministic verification as truth proof.
7. Do not treat one successful demo path as production readiness.
8. Do not hide limitations by calling them future enhancements.
9. Do not add features while responding to documentation findings unless the roadmap move explicitly allows it.
10. Do not modify frozen artifacts unless the current move explicitly creates a repair artifact.

## Accepted response types

| Response type | Meaning |
|---|---|
| ACCEPT | The finding is valid and needs correction or explicit limitation |
| REJECT_WITH_REASON | The finding is not accepted; reason and evidence are required |
| REQUEST_MORE_EVIDENCE | The finding may be valid but lacks enough evidence |
| DEFER_WITH_LIMITATION | The issue is real but belongs to a future roadmap area and must be documented |
| FIX | A correction will be made in the current allowed scope |

## Rejection rule

A rejected finding must include:

```text
exact reason
supporting artifact evidence
why the issue does not block the current move
whether it still blocks Move 40
```

"Disagree" is not enough.

## Deferral rule

A deferred finding must include:

```text
future roadmap area
current limitation wording
why current release can proceed without the feature
what claim must not be made until the feature exists
```

## Fix rule

A fixed finding must include:

```text
changed artifact
change summary
verifier output
checksum evidence
remaining limitation if any
```
