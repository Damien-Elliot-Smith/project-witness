# Review Scope — External Review Pack v0.1

## In scope

External reviewers may inspect:

- the frozen local demo path through Move 30;
- the beginner runbook from Move 31;
- the one-command demo wrapper from Move 32;
- the demo output bundle from Move 33;
- the architecture diagram package from Move 34;
- the master known limitations document from Move 35;
- the threat model from Move 36;
- this external review pack from Move 37.

Reviewers should check whether claims, documents, examples, manifests, checksums, verifiers, and release gates match each other.

## Out of scope

The following are out of scope for Move 37:

- building the Hostile Review Prompt Pack;
- building the Response-to-Review Ledger;
- freezing the Local Demo Pack;
- adding production incident response;
- adding multi-case search;
- adding multi-actor approval chains;
- adding organisation roles or governance;
- adding signing or anchoring;
- adding cryptographic identity;
- adding remote attestation;
- adding GUI, Android app, Windows app, or web UI;
- adding LLM reasoning or natural-language interpretation.

## Claim boundary

Current Project Witness claims may say:

- the tested local demo path can complete under known conditions;
- the stack records structured artifacts and verification statuses;
- the stack can compare files against expected hashes;
- the stack can produce reviewable bundles and documentation;
- the stack documents known limitations and threat assumptions.

Current Project Witness claims must not say:

- it proves truth;
- it verifies external reality;
- it proves source trust;
- it proves files are authentic beyond matching a known digest;
- it prevents all deception;
- it is tamper-proof;
- it is production-ready;
- it provides full security assurance.

## Reviewer authority

A reviewer can mark a finding as a blocker if the review pack, limitations document, threat model, or demo documentation makes a capability claim that the frozen stack does not support.

A reviewer should not mark the absence of future roadmap features as a blocker if those absences are honestly documented as limitations.
