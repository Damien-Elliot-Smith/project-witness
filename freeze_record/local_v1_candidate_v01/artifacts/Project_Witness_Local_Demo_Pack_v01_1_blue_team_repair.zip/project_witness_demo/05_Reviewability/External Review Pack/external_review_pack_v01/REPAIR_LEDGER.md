# Repair Ledger — External Review Pack v0.1

## Purpose

This ledger records repairs made while building Move 37.

## Repairs

| Repair ID | Issue | Fix | Scope impact | Status |
|---|---|---|---|---|
| R-001 | Initial package design risked becoming a hostile review prompt pack. | Kept `REVIEW_QUESTIONS.md` as reviewer questions only and explicitly deferred hostile prompt templates to Move 38. | Documentation scope only. No runtime impact. | COMPLETE |
| R-002 | Initial review wording risked implying external review equals production assurance. | Added repeated statements that this pack does not prove truth, external reality, source trust, security, or production readiness. | Documentation wording only. | COMPLETE |
| R-003 | Verifier required checksum validation for all files in the package. | Added checksum parsing and digest comparison against `CHECKSUMS.txt`. | Documentation verifier only. No runtime impact. | COMPLETE |
| R-004 | Verifier failed because the reviewer-start document did not contain the exact required phrase `truth proof`. | Added the exact phrase in the overclaim warning section. | Documentation wording only. | COMPLETE |
| R-005 | Verifier failed because the reviewer-start document did not contain exact overclaim boundary phrases for external reality verification and source trust proof. | Added explicit rejection wording for unsupported truth proof, external reality verification, source trust proof, and production-ready status. | Documentation wording only. | COMPLETE |

## Frozen artifact impact

No frozen artifacts were modified.

## Runtime impact

No runtime code was modified.
