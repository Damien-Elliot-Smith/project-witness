# External Review Pack v0.1

```text
Project: Project Witness
Move: 37
Package: external_review_pack_v01
Type: documentation-only review package
Status: candidate for freeze review
```

## Purpose

This package gives an outside reviewer a clean starting point for reviewing the Project Witness local demo stack through Move 36.

It is meant to make review easier, not to make the project look stronger than it is. The pack points reviewers toward what to inspect, what claims to test, what limitations must remain visible, and how to report findings.

## Scope boundary

This is a documentation-only package.

Move 37 does not modify runtime code.
Move 37 does not modify frozen artifacts.
Move 37 does not add a GUI.
Move 37 does not add an Android app.
Move 37 does not add a Windows app.
Move 37 does not add a web UI.
Move 37 does not add LLM integration.
Move 37 does not add signing.
Move 37 does not add external anchoring.
Move 37 does not add new workflows.
Move 37 does not add new action types.
Move 37 does not add new Atlas terms.

This pack is not the Hostile Review Prompt Pack. That is Move 38.
This pack is not the Response-to-Review Ledger. That is Move 39.
This pack is not the Local Demo Pack freeze. That is Move 40.

## Contents

```text
external_review_pack_v01/
  README.md
  START_HERE.md
  REVIEW_SCOPE.md
  ARTIFACT_MANIFEST.md
  REVIEWER_GUIDE.md
  REVIEW_CHECKLIST.md
  REVIEW_QUESTIONS.md
  FINDINGS_TEMPLATE.md
  SUBMISSION_NOTES.md
  RELEASE_GATE.md
  VERIFICATION.md
  TEST_RESULTS.md
  REPAIR_LEDGER.md
  CHECKSUMS.txt
  tools/
    verify_external_review_pack.py
```

## How to use this pack

1. Read `START_HERE.md`.
2. Read `REVIEW_SCOPE.md` before judging the project.
3. Use `ARTIFACT_MANIFEST.md` to identify the frozen artifacts and reference checksums.
4. Use `REVIEWER_GUIDE.md` and `REVIEW_CHECKLIST.md` to inspect the project without accepting hype.
5. Use `REVIEW_QUESTIONS.md` to structure technical questions.
6. Use `FINDINGS_TEMPLATE.md` to report blockers, major issues, minor issues, and questions.
7. Run the verifier:

```bash
python tools/verify_external_review_pack.py
```

Expected output:

```text
EXTERNAL_REVIEW_PACK_VERIFIED
verify_ok = true
```

## What this pack proves

This pack only proves that the Move 37 review documentation package is structurally present, bounded, and internally checkable.

It does not prove evidence contents are true.
It does not verify external reality.
It does not prove source trust.
It does not prove production readiness.
It does not prove the wider Project Witness stack is secure.

## North Star

Power without truth becomes corruption.  
Action without restraint becomes harm.  
Memory without honesty becomes mythology.  
Intelligence without limits becomes predatory.
