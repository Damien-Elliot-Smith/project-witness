# Verification — External Review Pack v0.1

## How to run

From the package root:

```bash
python tools/verify_external_review_pack.py
```

Expected output:

```text
EXTERNAL_REVIEW_PACK_VERIFIED
verify_ok = true
```

## What the verifier checks

The verifier checks:

- required files exist;
- required headings and phrases exist;
- Move 37 is identified;
- the package says documentation-only;
- Move 35 limitations are referenced;
- Move 36 threat model is referenced;
- primary artifact checksums are present;
- release gate includes PASS criteria and FAIL criteria;
- no forbidden runtime/source folders are present;
- no Move 38, Move 39, or Move 40 package is built;
- no dangerous affirmative overclaims appear as standalone claims;
- `CHECKSUMS.txt` exists and matches the package contents;
- the verifier uses Python standard library only.

## What the verifier does not check

The verifier does not run the Project Witness local demo.

The verifier does not verify external reality.

The verifier does not prove evidence contents are true.

The verifier does not prove source trust.

The verifier does not prove production readiness.

The verifier does not independently review the quality of the wider Project Witness stack.

## ResourceWarning sweep

Because this package includes a Python verifier, run it with warnings treated as errors:

```bash
python -W error::ResourceWarning tools/verify_external_review_pack.py
```

Expected output remains:

```text
EXTERNAL_REVIEW_PACK_VERIFIED
verify_ok = true
```
