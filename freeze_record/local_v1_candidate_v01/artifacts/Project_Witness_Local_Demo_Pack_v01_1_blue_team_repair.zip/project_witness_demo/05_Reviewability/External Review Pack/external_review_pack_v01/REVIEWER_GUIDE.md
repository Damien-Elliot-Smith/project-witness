# Reviewer Guide — External Review Pack v0.1

## Review attitude

Review this project as a claim-control and provenance system, not as a truth machine.

The useful review posture is strict but fair:

- accept narrow claims that are backed by artifacts;
- reject broad claims that exceed the artifacts;
- treat limitations as acceptable when visible;
- treat hidden limitations as serious defects;
- do not reward vague ambition over working verification.

## Suggested review sequence

### 1. Artifact identity check

Compare the supplied zip files to the SHA256 values in `ARTIFACT_MANIFEST.md`.

Passing this check only proves byte matching against known digests. It does not prove source trust or external truth.

### 2. Structure check

Unpack each artifact and inspect whether its package tree matches its README, release gate, and verification documents.

### 3. Verifier check

Run each available verifier from the package root. A verifier that cannot be run, gives false green, or ignores missing required files is a serious issue.

### 4. Claim check

Compare project claims against:

- Move 35 Master Known Limitations;
- Move 36 Threat Model;
- the actual demo output;
- release gate criteria;
- repair ledgers.

### 5. Runtime check where artifacts are available

If the frozen local demo artifacts are supplied, run the one-command demo script according to the beginner runbook.

Do not assume runtime success from documentation alone.

### 6. Failure-mode check

Try safe negative checks such as missing files, changed checksums, incomplete package trees, and altered documentation. The system should fail clearly rather than fake green.

Do not perform destructive, illegal, or unsafe tests.

## Severity definitions

| Severity | Meaning |
|---|---|
| BLOCKER | Prevents freeze or public local demo review because the artifact is false, unverifiable, misleading, or scope-breaking. |
| MAJOR | Important defect that should be repaired, but may not invalidate the entire move if documented and bounded. |
| MINOR | Documentation, clarity, naming, or small consistency issue. |
| QUESTION | Needs clarification before judgment. |

## Examples of blocker findings

- A verifier reports pass while required files are missing.
- A document claims Project Witness proves truth.
- A package claims production readiness.
- A checksum does not match the artifact supplied.
- A Move 37 package silently includes Move 38 prompt-pack work.
- A review artifact hides a known limitation from Move 35.
- A threat model deletes residual risks instead of documenting them.

## Examples of non-blocker findings

- There is no GUI.
- There is no signing or anchoring yet.
- There is no LLM reasoning.
- There is no Android or Windows app.
- There is no production incident response.

These are not blockers for the local demo if they remain honestly documented limitations.
