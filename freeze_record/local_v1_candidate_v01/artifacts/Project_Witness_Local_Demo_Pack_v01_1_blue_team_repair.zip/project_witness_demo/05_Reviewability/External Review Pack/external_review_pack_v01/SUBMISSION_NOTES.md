# Submission Notes — External Review Pack v0.1

## Plain-language review request

This package is for asking someone to review Project Witness honestly.

The reviewer should not be asked to praise the project. The reviewer should be asked to find false claims, fake green statuses, hidden limitations, broken verification, and scope creep.

## Suggested message to a reviewer

```text
I am building Project Witness as a local provenance and verification demo.

Please review only what exists, not the future roadmap.

I am especially looking for:
- false or inflated claims;
- verifier false greens;
- hidden limitations;
- checksum or package-structure problems;
- places where the documentation implies truth proof, source trust proof, external reality verification, or production readiness.

If something is missing but honestly documented as future work, mark it as a limitation, not automatically as a blocker.

Please use BLOCKER / MAJOR / MINOR / QUESTION severity labels.
```

## What not to send yet

Do not send a hostile review prompt pack yet. That is Move 38.

Do not send a response-to-review ledger yet. That is Move 39.

Do not claim the Local Demo Pack is frozen yet. That is Move 40.

## Honesty rule

If a reviewer finds a blocker, the correct response is not to argue it away. The correct response is to repair it narrowly, record the repair, and avoid changing frozen artifacts unless the current roadmap move explicitly creates a repair artifact.
