# Review Checklist — External Review Pack v0.1

Use this checklist to review Project Witness without accepting overclaims.

## A. Package identity and structure

- [ ] Supplied artifact names match the manifest.
- [ ] Supplied artifact hashes match the manifest where reference hashes exist.
- [ ] Each package has a clear README.
- [ ] Each package has a release gate.
- [ ] Each package has a verification document.
- [ ] Each package has a repair ledger.
- [ ] Each package has test results.
- [ ] Each package has checksums for its own files.

## B. Scope boundary

- [ ] Move 37 remains documentation-only.
- [ ] Move 37 does not modify runtime code.
- [ ] Move 37 does not modify frozen artifacts.
- [ ] Move 37 does not build the Hostile Review Prompt Pack.
- [ ] Move 37 does not build the Response-to-Review Ledger.
- [ ] Move 37 does not freeze the Local Demo Pack.
- [ ] Move 37 does not add GUI, Android app, Windows app, web UI, LLM integration, signing, anchoring, queues, concurrency, new workflows, new action types, or new Atlas terms.

## C. Claim discipline

- [ ] The project does not claim to prove truth.
- [ ] The project does not claim to verify external reality.
- [ ] The project does not claim to prove source trust.
- [ ] The project does not claim hashes prove authenticity.
- [ ] The project does not claim ODIN proves claims are true.
- [ ] The project does not claim production readiness.
- [ ] The project does not claim to prevent all deception.
- [ ] The project does not claim full security assurance.

## D. Limitations visibility

- [ ] Move 35 limitations are visible and referenced.
- [ ] Hash-only verification limits are visible.
- [ ] Whole-folder fabrication remains visible.
- [ ] Local-only trust assumptions are visible.
- [ ] One successful demo path is not presented as full assurance.

## E. Threat model visibility

- [ ] Move 36 threat model is visible and referenced.
- [ ] Assets are identified.
- [ ] Trust boundaries are identified.
- [ ] Threats are catalogued.
- [ ] Current mitigations are separated from future mitigations.
- [ ] Residual risks are not hidden.
- [ ] Non-goals are explicit.

## F. Verifier behaviour

- [ ] Verifier exists.
- [ ] Verifier is standard-library Python only.
- [ ] Verifier can be run offline.
- [ ] Verifier checks required files.
- [ ] Verifier checks required phrases/headings.
- [ ] Verifier checks checksums.
- [ ] Verifier rejects forbidden scope additions.
- [ ] Verifier rejects dangerous affirmative overclaims.

## G. Review outcome

- [ ] Findings are recorded using severity labels.
- [ ] Blockers are separated from non-blockers.
- [ ] Future roadmap requests are not treated as current defects unless the project claims them as current capability.
- [ ] Final reviewer verdict is explicit: freeze-ready, repair-needed, or rejected.
