# Review Questions — External Review Pack v0.1

These are not hostile prompt templates. They are review questions for a human or external reviewer. The Hostile Review Prompt Pack is a later move.

## Claim questions

1. What exactly does Project Witness claim to prove today?
2. Which claims are backed by artifacts and which are only roadmap intentions?
3. Does any document imply truth proof, external reality verification, source trust proof, or production readiness?
4. Does the wording distinguish byte-level verification from authenticity and authority?
5. Are limitations presented as part of the system's honesty rather than hidden weaknesses?

## Verification questions

1. Can each package verifier be run offline?
2. Does each verifier fail when a required file is missing?
3. Does each verifier check checksums rather than merely printing success?
4. Does each verifier avoid importing runtime components unnecessarily?
5. Does each verifier report useful failure messages?

## Demo questions

1. Can the one-command demo complete from the supplied frozen artifacts?
2. Are statuses such as DEMO_COMPLETED, COMPANION_COMPLETED, WORKFLOW_COMPLETED, ATLAS_VALIDATED, SOURCE_VERIFIED, STACK_VERIFIED, and STACK_SELFCHECK_PASSED backed by real output?
3. Are failures surfaced honestly?
4. Are compatibility repairs documented instead of hidden?

## Limitation questions

1. Are all known limitations from Move 35 visible?
2. Are blocker and non-blocker limitations separated?
3. Does the project avoid presenting missing future features as current features?
4. Does the project state that whole-folder fabrication remains possible under unkeyed hashes?
5. Does the project admit that a narrow demo path is not production assurance?

## Threat model questions

1. Are protected assets clearly named?
2. Are trust boundaries explicit?
3. Are attacker capabilities realistic for a local demo?
4. Are mitigations current, not promised?
5. Are residual risks still visible after mitigations?

## Freeze-readiness question

Would an outside reviewer be misled about what Project Witness currently can and cannot do?

If the answer is yes, the relevant artifact needs repair before freeze.
