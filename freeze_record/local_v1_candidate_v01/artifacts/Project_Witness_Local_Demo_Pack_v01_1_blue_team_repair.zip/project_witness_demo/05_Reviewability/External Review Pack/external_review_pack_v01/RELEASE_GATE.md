# Release Gate — External Review Pack v0.1

## Purpose

This release gate decides whether Move 37 can be treated as a freeze candidate.

It does not approve production use.
It does not approve the Local Demo Pack freeze.
It does not approve Move 38, Move 39, or Move 40.

## PASS criteria

The package passes only if all of the following are true:

- all required files are present;
- `START_HERE.md` gives a clear reviewer entry point;
- `REVIEW_SCOPE.md` separates in-scope and out-of-scope review;
- `ARTIFACT_MANIFEST.md` lists the primary artifact chain and reference checksums;
- `REVIEWER_GUIDE.md` gives an honest review method;
- `REVIEW_CHECKLIST.md` includes package, scope, claim, limitation, threat model, verifier, and outcome checks;
- `REVIEW_QUESTIONS.md` contains review questions, not hostile prompt templates;
- `FINDINGS_TEMPLATE.md` supports blocker/major/minor/question reporting;
- `SUBMISSION_NOTES.md` gives safe review-request wording without hype;
- Move 35 limitations are referenced;
- Move 36 threat model is referenced;
- no claim says Project Witness proves truth;
- no claim says Project Witness verifies external reality;
- no claim says Project Witness proves source trust;
- no claim says hashes prove authenticity;
- no claim says the system is production-ready;
- no claim says the system prevents all deception;
- no Move 38 Hostile Review Prompt Pack is built;
- no Move 39 Response-to-Review Ledger is built;
- no Move 40 Local Demo Pack freeze is built;
- no runtime code is modified;
- no frozen artifacts are modified;
- no forbidden app, GUI, LLM, signing, anchoring, workflow, action-type, or Atlas feature is added;
- `CHECKSUMS.txt` is present and valid;
- `tools/verify_external_review_pack.py` passes;
- `TEST_RESULTS.md` records real verifier results;
- `REPAIR_LEDGER.md` exists and records repairs honestly.

## FAIL criteria

The package fails if any of the following are true:

- a required file is missing;
- the verifier gives false green;
- checksums are missing or invalid;
- the package includes runtime source folders;
- the package silently modifies frozen artifacts;
- the package builds Move 38, Move 39, or Move 40 work;
- the package contains hostile prompt templates as if Move 38 were complete;
- the package contains a response ledger as if Move 39 were complete;
- the package claims the Local Demo Pack is frozen as if Move 40 were complete;
- the package claims truth proof, external reality verification, source trust proof, tamper-proof guarantees, or production readiness;
- the package hides the limitations from Move 35;
- the package hides residual risks from Move 36.

## Result

If the verifier passes and the release gate criteria are met, this package may be treated as ready for freeze review.
