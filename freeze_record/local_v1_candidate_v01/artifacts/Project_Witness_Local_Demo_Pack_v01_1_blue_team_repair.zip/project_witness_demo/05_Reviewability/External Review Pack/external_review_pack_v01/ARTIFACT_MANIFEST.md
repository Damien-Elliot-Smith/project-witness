# Artifact Manifest — External Review Pack v0.1

## Purpose

This manifest lists the main Project Witness artifacts that an external reviewer should expect to see or request when reviewing the local demo stack through Move 37.

This package does not embed the earlier frozen artifacts. It records their names and known reference checksums so reviewers can compare supplied artifacts against the expected values.

## Primary artifact chain

| Move | Artifact | Status | Reference SHA256 |
|---:|---|---|---|
| 30 | `connected_demo_v01.zip` | DONE / FROZEN | `87ba5c0db336d332dc942c0dcb5d36b464f0de4982537a4217e19fdf782577f8` |
| 31 | `beginner_runbook_v01.zip` | DONE / FROZEN | `d80aa1d6586e82398dab562dcdd4cda26987aecd11019cd9a7ddf0866ba763a9` |
| 32 | `one_command_demo_script_v01.zip` | DONE / FROZEN | `3a6a21b9c10b1f6223130291f1592598558696dcd921a142e09c34dee212bee9` |
| 33 | `demo_output_bundle_v01.zip` | DONE / FROZEN | `bc1599122684640972953bfcfbb85f190c305ce5202af182edc3ddee8496ef1e` |
| 34 | `architecture_diagram_v01.zip` | DONE / FROZEN | `96b3121ce0b9e09c63e8c072ea807e9cbf27b4fe9b96c0b95608ac808fe84133` |
| 35 | `master_known_limitations_v01.zip` | DONE / FREEZE CANDIDATE | `37919a23dd5ac2fde89101db384dabc8120041194cde2f27bb16b24c1619c783` |
| 36 | `threat_model_v01.zip` | DONE / FREEZE CANDIDATE | `d78c1b1e95cae664eca190fc5170f97a62721f856368aa1c4f2e1bdd85ae887a` |
| 37 | `external_review_pack_v01.zip` | CURRENT PACKAGE | recorded outside this file after packaging |

## Move 30 repair chain reference

The Move 30 connected demo was not faked. It was blocked, repaired narrowly, and then completed. Reviewers should check that repair artifacts are described honestly.

| Repair artifact | Purpose | Reference SHA256 |
|---|---|---|
| `coordinator_workflow_v031.zip` | real lower-component runner repair | `9a889d5c579d4fcbceabf631e3cb793f6aedddd874b9ebd9d9728d5a5f9747b2` |
| `companion_cli_v031.zip` | coordinator request-file hygiene repair | `d5294046583f8a2273600f5d928d41ca4214c4f60d72b8667fd3f5543013a6ec` |
| `coordinator_workflow_v032.zip` | Case Bundle evidence_id compatibility repair | `be1d882aab7ccf0b6f343c033966a29dde78a81161acd3186de7b6106daaf2d2` |
| `stack_selfcheck_v011.zip` | legacy documentation compatibility repair | `07fc0c259fd9ae27a645ee33f89c7ffc7d1e80470de67c29333436523e8a7020` |
| `stack_selfcheck_v012.zip` | truth-boundary phrase-model compatibility repair | `151f57d0378db4c06df7f09af8a28ec774d8e09d8fbef4fc6fef8e09d47dab2c` |

## Review note on checksums

Hashes identify bytes, not trust.

A matching SHA256 digest can show that a supplied file matches the expected byte content. It does not prove who created the file, whether the file reflects external reality, or whether the whole folder was fabricated before hashing.
