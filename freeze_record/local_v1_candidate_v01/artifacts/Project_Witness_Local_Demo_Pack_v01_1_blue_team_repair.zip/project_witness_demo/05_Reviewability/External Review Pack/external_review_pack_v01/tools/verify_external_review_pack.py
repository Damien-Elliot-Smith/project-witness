#!/usr/bin/env python3
"""Verify Project Witness External Review Pack v0.1.

Standard-library only. Run from the package root:
    python tools/verify_external_review_pack.py
"""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "START_HERE.md",
    "REVIEW_SCOPE.md",
    "ARTIFACT_MANIFEST.md",
    "REVIEWER_GUIDE.md",
    "REVIEW_CHECKLIST.md",
    "REVIEW_QUESTIONS.md",
    "FINDINGS_TEMPLATE.md",
    "SUBMISSION_NOTES.md",
    "RELEASE_GATE.md",
    "VERIFICATION.md",
    "TEST_RESULTS.md",
    "REPAIR_LEDGER.md",
    "CHECKSUMS.txt",
    "tools/verify_external_review_pack.py",
]

REQUIRED_PHRASES = {
    "README.md": [
        "External Review Pack v0.1",
        "Move: 37",
        "documentation-only review package",
        "This pack is not the Hostile Review Prompt Pack",
        "This pack is not the Response-to-Review Ledger",
        "This pack is not the Local Demo Pack freeze",
        "does not prove evidence contents are true",
        "does not verify external reality",
        "does not prove source trust",
    ],
    "START_HERE.md": [
        "Move 37 — External Review Pack v0.1",
        "Do not review future roadmap promises as current capability",
        "truth proof",
        "external reality verification",
        "source trust proof",
        "production-ready",
    ],
    "REVIEW_SCOPE.md": [
        "In scope",
        "Out of scope",
        "Claim boundary",
        "Current Project Witness claims may say",
        "Current Project Witness claims must not say",
        "building the Hostile Review Prompt Pack",
        "building the Response-to-Review Ledger",
        "freezing the Local Demo Pack",
    ],
    "ARTIFACT_MANIFEST.md": [
        "connected_demo_v01.zip",
        "beginner_runbook_v01.zip",
        "one_command_demo_script_v01.zip",
        "demo_output_bundle_v01.zip",
        "architecture_diagram_v01.zip",
        "master_known_limitations_v01.zip",
        "threat_model_v01.zip",
        "87ba5c0db336d332dc942c0dcb5d36b464f0de4982537a4217e19fdf782577f8",
        "d80aa1d6586e82398dab562dcdd4cda26987aecd11019cd9a7ddf0866ba763a9",
        "3a6a21b9c10b1f6223130291f1592598558696dcd921a142e09c34dee212bee9",
        "bc1599122684640972953bfcfbb85f190c305ce5202af182edc3ddee8496ef1e",
        "96b3121ce0b9e09c63e8c072ea807e9cbf27b4fe9b96c0b95608ac808fe84133",
        "37919a23dd5ac2fde89101db384dabc8120041194cde2f27bb16b24c1619c783",
        "d78c1b1e95cae664eca190fc5170f97a62721f856368aa1c4f2e1bdd85ae887a",
        "Hashes identify bytes, not trust",
    ],
    "REVIEWER_GUIDE.md": [
        "claim-control and provenance system",
        "Severity definitions",
        "BLOCKER",
        "MAJOR",
        "MINOR",
        "QUESTION",
        "Examples of blocker findings",
        "Examples of non-blocker findings",
    ],
    "REVIEW_CHECKLIST.md": [
        "Package identity and structure",
        "Scope boundary",
        "Claim discipline",
        "Limitations visibility",
        "Threat model visibility",
        "Verifier behaviour",
        "Review outcome",
    ],
    "REVIEW_QUESTIONS.md": [
        "These are not hostile prompt templates",
        "Claim questions",
        "Verification questions",
        "Demo questions",
        "Limitation questions",
        "Threat model questions",
        "Freeze-readiness question",
    ],
    "FINDINGS_TEMPLATE.md": [
        "FREEZE-READY",
        "REPAIR NEEDED",
        "REJECTED / FALSE GREEN",
        "INSUFFICIENT ARTIFACTS TO REVIEW",
        "BLOCKER / MAJOR / MINOR / QUESTION",
    ],
    "SUBMISSION_NOTES.md": [
        "Plain-language review request",
        "Suggested message to a reviewer",
        "What not to send yet",
        "Do not send a hostile review prompt pack yet",
        "Do not send a response-to-review ledger yet",
        "Do not claim the Local Demo Pack is frozen yet",
    ],
    "RELEASE_GATE.md": [
        "PASS criteria",
        "FAIL criteria",
        "Move 35 limitations are referenced",
        "Move 36 threat model is referenced",
        "no Move 38 Hostile Review Prompt Pack is built",
        "no Move 39 Response-to-Review Ledger is built",
        "no Move 40 Local Demo Pack freeze is built",
    ],
    "VERIFICATION.md": [
        "What the verifier checks",
        "What the verifier does not check",
        "ResourceWarning sweep",
    ],
    "TEST_RESULTS.md": [
        "Verifier output",
        "ResourceWarning sweep output",
        "Runtime code tests",
        "EXTERNAL_REVIEW_PACK_VERIFIED",
    ],
    "REPAIR_LEDGER.md": [
        "No frozen artifacts were modified",
        "No runtime code was modified",
    ],
}

FORBIDDEN_DIRS = {
    "src", "app", "runtime", "coordinator", "companion", "sentinel", "histor", "odin", "atlas",
    "hostile_review_prompt_pack_v01", "response_to_review_ledger_v01", "local_demo_pack_v01",
}

FORBIDDEN_FILE_PATTERNS = [
    r"(^|/)HOSTILE_PROMPT.*",
    r"(^|/)PROMPT_PACK.*",
    r"(^|/)RESPONSE_LEDGER.*",
    r"(^|/)LOCAL_DEMO_PACK.*",
]

FORBIDDEN_AFFIRMATIVE_LINES = [
    "Project Witness proves truth.",
    "Project Witness verifies external reality.",
    "Project Witness proves source trust.",
    "Project Witness is production-ready.",
    "Project Witness prevents all deception.",
    "Hashes prove authenticity.",
    "ODIN proves claims are true.",
]

ALLOWED_CONTEXT_MARKERS = [
    "must not say",
    "must not claim",
    "does not claim",
    "does not prove",
    "does not verify",
    "Examples:",
    "false",
    "wrong",
]

ALLOWED_EXTENSIONS = {".md", ".py", ".txt"}


def fail(message: str) -> None:
    print(f"VERIFY_FAIL: {message}")
    print("verify_ok = false")
    raise SystemExit(1)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def rel_files() -> list[Path]:
    return sorted(p.relative_to(ROOT) for p in ROOT.rglob("*") if p.is_file())


def check_required_files() -> None:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            fail(f"missing required file: {rel}")


def check_required_phrases() -> None:
    for rel, phrases in REQUIRED_PHRASES.items():
        text = read(rel)
        for phrase in phrases:
            if phrase not in text:
                fail(f"missing required phrase in {rel}: {phrase!r}")


def check_allowed_files_and_dirs() -> None:
    for p in ROOT.rglob("*"):
        rel = p.relative_to(ROOT).as_posix()
        if p.is_dir() and p.name in FORBIDDEN_DIRS:
            fail(f"forbidden directory present: {rel}")
        if p.is_file():
            if p.suffix not in ALLOWED_EXTENSIONS:
                fail(f"forbidden file extension: {rel}")
            for pattern in FORBIDDEN_FILE_PATTERNS:
                if re.search(pattern, rel):
                    fail(f"forbidden Move 38/39/40-style file present: {rel}")


def check_no_dangerous_affirmative_claims() -> None:
    for rel in rel_files():
        if rel.as_posix() == "tools/verify_external_review_pack.py":
            continue
        text = (ROOT / rel).read_text(encoding="utf-8")
        lines = text.splitlines()
        for i, line in enumerate(lines):
            stripped = line.strip().strip("`>*- ")
            if stripped in FORBIDDEN_AFFIRMATIVE_LINES:
                window = "\n".join(lines[max(0, i-3): min(len(lines), i+4)]).lower()
                if not any(marker.lower() in window for marker in ALLOWED_CONTEXT_MARKERS):
                    fail(f"dangerous affirmative overclaim in {rel}: {stripped}")


def parse_checksums() -> dict[str, str]:
    checksums_path = ROOT / "CHECKSUMS.txt"
    if not checksums_path.is_file():
        fail("missing CHECKSUMS.txt")
    entries: dict[str, str] = {}
    for lineno, raw in enumerate(checksums_path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            fail(f"invalid checksum line {lineno}: {raw!r}")
        digest, rel = parts
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            fail(f"invalid sha256 digest on line {lineno}: {digest!r}")
        entries[rel] = digest
    return entries


def check_checksums() -> None:
    entries = parse_checksums()
    expected_files = [p.as_posix() for p in rel_files() if p.as_posix() != "CHECKSUMS.txt"]
    if sorted(entries) != sorted(expected_files):
        missing = sorted(set(expected_files) - set(entries))
        extra = sorted(set(entries) - set(expected_files))
        fail(f"checksum entries do not match files; missing={missing}, extra={extra}")
    for rel, digest in entries.items():
        actual = sha256(ROOT / rel)
        if actual != digest:
            fail(f"checksum mismatch for {rel}: expected {digest}, got {actual}")


def check_script_standard_library_shape() -> None:
    script = read("tools/verify_external_review_pack.py")
    forbidden_imports = ["requests", "numpy", "pandas", "yaml", "click", "pytest"]
    for name in forbidden_imports:
        if f"import {name}" in script or f"from {name}" in script:
            fail(f"non-standard dependency imported: {name}")


def main() -> int:
    check_required_files()
    check_required_phrases()
    check_allowed_files_and_dirs()
    check_no_dangerous_affirmative_claims()
    check_script_standard_library_shape()
    check_checksums()
    print("EXTERNAL_REVIEW_PACK_VERIFIED")
    print("verify_ok = true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
