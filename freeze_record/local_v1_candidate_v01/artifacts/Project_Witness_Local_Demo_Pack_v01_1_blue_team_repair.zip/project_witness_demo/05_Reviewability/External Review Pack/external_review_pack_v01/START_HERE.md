# Start Here — External Review Pack v0.1

## Reviewer summary

You are reviewing a local, frozen, deterministic demo path for Project Witness through Move 36.

Do not review future roadmap promises as current capability. Review only what exists.

## Current project position

```text
Move 30 — Connected Demo v0.1                 DONE / FROZEN
Move 31 — Beginner Runbook v0.1               DONE / FROZEN
Move 32 — One-Command Demo Script v0.1        DONE / FROZEN
Move 33 — Demo Output Bundle v0.1             DONE / FROZEN
Move 34 — Architecture Diagram v0.1           DONE / FROZEN
Move 35 — Master Known Limitations v0.1       DONE / FREEZE CANDIDATE
Move 36 — Threat Model v0.1                   DONE / FREEZE CANDIDATE
Move 37 — External Review Pack v0.1           CURRENT PACKAGE
```

## What to look for first

Start with these review questions:

1. Does the project claim more than it proves?
2. Are all green statuses backed by real artifacts, not invented statuses?
3. Are hash checks used honestly, without pretending they prove origin or truth?
4. Are known limitations visible and not buried?
5. Does the demo path actually run from public/local CLIs when the required artifacts are present?
6. Does the verifier reject missing, incomplete, or overclaiming review documentation?
7. Does the threat model honestly classify residual risk?

## The most important review rule

If a claim says Project Witness proves truth, verifies external reality, proves source trust, makes a truth proof, prevents all deception, or is production-ready, treat that claim as wrong unless a later roadmap artifact explicitly implements and verifies the missing capability.


Reviewers should reject unsupported claims of truth proof, external reality verification, source trust proof, or production-ready status.

## What this pack is not

This is not a marketing pack.
This is not a hostile prompt pack.
This is not a response ledger.
This is not a production assurance case.
This is not a security certification.
This is not the final local demo pack freeze.
