# Findings Template — External Review Pack v0.1

Use this template to report external review findings.

## Review metadata

```text
Reviewer:
Date:
Artifacts reviewed:
Artifact checksums checked: YES / NO / PARTIAL
Verifier runs completed: YES / NO / PARTIAL
Runtime demo run completed: YES / NO / NOT AVAILABLE
```

## Overall verdict

Choose one:

```text
FREEZE-READY
REPAIR NEEDED
REJECTED / FALSE GREEN
INSUFFICIENT ARTIFACTS TO REVIEW
```

## Finding table

| ID | Severity | Artifact/File | Finding | Evidence | Recommended repair |
|---|---|---|---|---|---|
| EXT-001 | BLOCKER / MAJOR / MINOR / QUESTION |  |  |  |  |

## Blocker definition

Use BLOCKER only when the issue prevents honest freeze or public local demo review.

Examples:

- verifier false green;
- missing required package files;
- checksum mismatch;
- hidden known limitation;
- unsupported truth/provenance/security claim;
- Move 37 package includes Move 38/39/40 work;
- package cannot be verified.

## Non-blocker definition

Do not mark a missing future roadmap feature as a blocker if the project clearly documents it as absent.

Examples of non-blockers for the current local demo:

- no GUI;
- no Android app;
- no Windows app;
- no web UI;
- no signing;
- no external anchoring;
- no LLM reasoning;
- no production incident response;
- no organisation governance.

## Reviewer notes

```text
Notes:
```
