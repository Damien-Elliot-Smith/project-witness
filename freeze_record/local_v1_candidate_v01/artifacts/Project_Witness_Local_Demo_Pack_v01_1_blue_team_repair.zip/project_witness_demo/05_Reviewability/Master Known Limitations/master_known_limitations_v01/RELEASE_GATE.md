# Project Witness — Move 35 Release Gate v0.1

```text
Move: 35
Artifact: RELEASE_GATE.md
Gate type: documentation-only release gate
```

## Gate result

A Move 35 package may pass only if it is honest, complete, narrow, and verifiable.

## PASS criteria

The package passes this release gate only when all criteria below are true:

| ID | Criterion | Required result |
|---|---|---|
| RG-001 | all required files present | PASS |
| RG-002 | main limitations document present | PASS |
| RG-003 | dangerous overclaims section present | PASS |
| RG-004 | release blocker classification present | PASS |
| RG-005 | future roadmap mapping present | PASS |
| RG-006 | truth-boundary wording present | PASS |
| RG-007 | no forbidden scope additions | PASS |
| RG-008 | no claims of truth proof | PASS |
| RG-009 | no claims of external reality verification | PASS |
| RG-010 | no claims of production readiness | PASS |
| RG-011 | checksum file present | PASS |
| RG-012 | verifier passes | PASS |
| RG-013 | TEST_RESULTS.md records real result | PASS |
| RG-014 | REPAIR_LEDGER.md exists | PASS |
| RG-015 | Move 36+ work is not built | PASS |

## FAIL criteria

The package fails if any of the following are true:

| ID | Failure condition |
|---|---|
| RF-001 | Required files are missing. |
| RF-002 | The main limitations document is absent or too vague to be useful. |
| RF-003 | Dangerous overclaims are not explicitly corrected. |
| RF-004 | Release blockers and non-blockers are not distinguished. |
| RF-005 | Future roadmap items are implemented instead of merely identified. |
| RF-006 | The package makes or implies a truth-proof claim. |
| RF-007 | The package makes or implies an external-reality-verification claim. |
| RF-008 | The package makes or implies a production-readiness claim. |
| RF-009 | The package claims tamper-proof guarantees without signing or anchoring. |
| RF-010 | CHECKSUMS.txt is missing or incomplete. |
| RF-011 | The verifier fails. |
| RF-012 | Runtime code or frozen artifacts are included or modified. |
| RF-013 | The document contradicts the frozen local demo behaviour. |
| RF-014 | Move 36 Threat Model content is built here. |
| RF-015 | Move 37 External Review Pack content is built here. |
| RF-016 | Move 38 Hostile Review Prompt Pack content is built here. |
| RF-017 | Move 39 Response-to-Review Ledger content is built here. |
| RF-018 | Move 40 Local Demo Pack freeze is performed here. |

## Scope boundary result

Move 35 is allowed to document future work. It is not allowed to build future work.

The correct result is a verifiable documentation package, not new runtime capability.
