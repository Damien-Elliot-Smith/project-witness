#!/usr/bin/env python3
"""Verify Project Witness Move 35 Master Known Limitations package.

This verifier is intentionally narrow. It checks documentation structure,
required limitation phrases, scope boundary, and basic checksum coverage.
It does not verify the wider Project Witness runtime stack.
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "MASTER_KNOWN_LIMITATIONS.md",
    "LIMITATIONS_INDEX.md",
    "RELEASE_GATE.md",
    "VERIFICATION.md",
    "TEST_RESULTS.md",
    "REPAIR_LEDGER.md",
    "CHECKSUMS.txt",
    "tools/verify_master_known_limitations.py",
]

REQUIRED_HEADINGS = [
    "## 1. Purpose",
    "## 2. Truth-boundary statement",
    "## 3. Hard current limitations",
    "## 4. Known expected limitations",
    "## 5. Future roadmap items",
    "## 6. Non-goals for Move 35",
    "## 7. Release blockers vs non-blockers",
    "## 8. Dangerous overclaims",
    "## 9. Reviewer guidance",
    "## 10. What this document does not cover",
]

REQUIRED_LIMITATION_PHRASES = [
    "does not prove evidence contents are true",
    "does not prove ODIN claims are true",
    "does not verify external reality",
    "does not prove sources are trusted",
    "does not prove files are authentic beyond hash matching",
    "does not sign outputs",
    "does not externally anchor outputs",
    "whole-folder fabrication remains possible under unkeyed hashes",
    "one successful demo path is not full production assurance",
    "not a GUI",
    "not an Android app",
    "not a Windows app",
    "not a web UI",
    "not LLM reasoning",
    "not natural-language interpretation",
    "not production incident response",
    "not multi-case search",
    "not multi-actor approval chain",
    "not policy governance",
    "local-only trust assumptions",
    "reviewer trust assumptions",
    "hash-only verification limits",
    "demo-path narrowness",
    "frozen-component compatibility repairs",
    "documentation vs runtime authority",
    "case-bundle portability limits",
    "operator error",
    "environment assumptions",
    "lack of cryptographic identity",
    "lack of remote attestation",
    "lack of access control",
    "lack of role permissions",
    "lack of organisation governance",
    "lack of production monitoring",
    "lack of incident response",
    "lack of privacy/redaction lifecycle",
    "lack of long-term storage/search guarantees",
]

REQUIRED_RELEASE_GATE_PHRASES = [
    "PASS criteria",
    "FAIL criteria",
    "all required files present",
    "no claims of truth proof",
    "no claims of external reality verification",
    "no claims of production readiness",
    "verifier passes",
]

FUTURE_ONLY_PHRASES = [
    "Move 36 — Threat Model v0.1",
    "Move 37 — External Review Pack v0.1",
    "Move 38 — Hostile Review Prompt Pack",
    "Move 39 — Response-to-Review Ledger",
    "Move 40 — Freeze Project Witness Local Demo Pack",
    "Part Two, Step 71+",
    "Part Three",
    "Part Four",
    "Part Five",
]

DISALLOWED_TOP_LEVEL_DIRS = {
    "ConnectedDemo_FREEZES",
    "BeginnerRunbook_FREEZES",
    "OneCommandDemoScript_FREEZES",
    "DemoOutputBundle_FREEZES",
    "ArchitectureDiagram_FREEZES",
    "Coordinator_FREEZES",
    "Companion_FREEZES",
    "StackSelfcheck_FREEZES",
    "src",
    "app",
    "runtime",
    "coordinator",
    "companion",
    "sentinel",
    "histor",
    "odin",
    "atlas",
    "case_bundle",
    "tests",
}

BAD_AFFIRMATIVE_CLAIMS = [
    "Project Witness proves truth",
    "Project Witness verifies external reality",
    "Project Witness proves external reality",
    "Project Witness proves sources are trusted",
    "Project Witness is production-ready",
    "Project Witness is production ready",
    "Project Witness prevents all deception",
    "Hashes prove authenticity",
    "ODIN proves claims are true",
    "The bundle is tamper-proof",
]

ALLOWED_BAD_CLAIM_CONTEXTS = [
    "Overclaim",
    "Dangerous overclaims",
    "False.",
    "claiming",
    "does not",
    "no claims of",
    "FAIL criteria",
]


def fail(message: str) -> None:
    print(f"VERIFY_FAILED: {message}", file=sys.stderr)
    raise SystemExit(1)


def read(rel: str) -> str:
    path = ROOT / rel
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        fail(f"missing required file: {rel}")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def check_required_files() -> None:
    for rel in REQUIRED_FILES:
        path = ROOT / rel
        if not path.is_file():
            fail(f"required file is missing: {rel}")


def check_required_content() -> None:
    main = read("MASTER_KNOWN_LIMITATIONS.md")
    main_lower = main.lower()

    for heading in REQUIRED_HEADINGS:
        if heading not in main:
            fail(f"missing required heading in MASTER_KNOWN_LIMITATIONS.md: {heading}")

    for phrase in REQUIRED_LIMITATION_PHRASES:
        if phrase.lower() not in main_lower:
            fail(f"missing required limitation phrase: {phrase}")

    required_concepts = [
        "dangerous overclaims",
        "truth-boundary",
        "release blockers",
        "non-blockers",
        "future roadmap",
        "correct claim",
        "does not prove truth",
        "does not prove reality",
        "does not prove trust",
        "does not prove production readiness",
    ]
    for concept in required_concepts:
        if concept.lower() not in main_lower:
            fail(f"missing required concept in main document: {concept}")


def check_release_gate() -> None:
    gate = read("RELEASE_GATE.md")
    gate_lower = gate.lower()
    for phrase in REQUIRED_RELEASE_GATE_PHRASES:
        if phrase.lower() not in gate_lower:
            fail(f"release gate missing phrase: {phrase}")


def check_readme_and_ledgers() -> None:
    readme = read("README.md")
    if "Move: 35" not in readme and "Move 35" not in readme:
        fail("README.md does not reference Move 35")

    repair = read("REPAIR_LEDGER.md")
    if "## Repair status" not in repair or "CLOSED" not in repair:
        fail("REPAIR_LEDGER.md does not state repair status")

    tests = read("TEST_RESULTS.md")
    if "Verifier" not in tests or "PASS" not in tests:
        fail("TEST_RESULTS.md does not record verifier PASS")
    if "ResourceWarning" not in tests:
        fail("TEST_RESULTS.md does not record ResourceWarning sweep")


def check_scope_boundary() -> None:
    for child in ROOT.iterdir():
        if child.is_dir() and child.name in DISALLOWED_TOP_LEVEL_DIRS:
            fail(f"disallowed top-level directory included: {child.name}")

    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT).as_posix()
        if path.is_dir():
            continue
        if rel.startswith("tools/"):
            continue
        if path.suffix not in {".md", ".txt"}:
            fail(f"unexpected non-documentation file outside tools/: {rel}")


def check_future_items_are_future_only() -> None:
    main = read("MASTER_KNOWN_LIMITATIONS.md")
    for phrase in FUTURE_ONLY_PHRASES:
        if phrase not in main:
            fail(f"future roadmap item missing from main document: {phrase}")

    forbidden_build_language = [
        "Move 36 is complete",
        "Move 37 is complete",
        "Move 38 is complete",
        "Move 39 is complete",
        "Move 40 is complete",
        "Threat Model v0.1 built",
        "External Review Pack v0.1 built",
        "Hostile Review Prompt Pack built",
        "Response-to-Review Ledger built",
        "Local Demo Pack frozen",
    ]
    combined = "\n".join(
        p.read_text(encoding="utf-8")
        for p in ROOT.rglob("*.md")
        if p.is_file()
    )
    for phrase in forbidden_build_language:
        if phrase in combined:
            fail(f"future work appears to be claimed as built: {phrase}")


def check_affirmative_overclaims() -> None:
    for path in ROOT.rglob("*.md"):
        text = path.read_text(encoding="utf-8")
        for lineno, line in enumerate(text.splitlines(), start=1):
            for phrase in BAD_AFFIRMATIVE_CLAIMS:
                if phrase in line:
                    if not any(ctx in line for ctx in ALLOWED_BAD_CLAIM_CONTEXTS):
                        fail(
                            f"possible affirmative overclaim in {path.relative_to(ROOT)}:{lineno}: {phrase}"
                        )


def check_checksums() -> None:
    checksum_text = read("CHECKSUMS.txt")
    found: dict[str, str] = {}
    for raw_line in checksum_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            fail(f"malformed checksum line: {raw_line}")
        digest, rel = parts
        rel = rel.strip()
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            fail(f"invalid sha256 digest for {rel}")
        found[rel] = digest

    expected_files = sorted(
        p.relative_to(ROOT).as_posix()
        for p in ROOT.rglob("*")
        if p.is_file() and p.relative_to(ROOT).as_posix() != "CHECKSUMS.txt"
    )
    missing = [rel for rel in expected_files if rel not in found]
    extra = [rel for rel in found if rel not in expected_files]
    if missing:
        fail(f"CHECKSUMS.txt missing entries: {missing}")
    if extra:
        fail(f"CHECKSUMS.txt has extra entries: {extra}")

    for rel in expected_files:
        actual = sha256_file(ROOT / rel)
        if found[rel] != actual:
            fail(f"checksum mismatch for {rel}")


def main() -> int:
    check_required_files()
    check_required_content()
    check_release_gate()
    check_readme_and_ledgers()
    check_scope_boundary()
    check_future_items_are_future_only()
    check_affirmative_overclaims()
    check_checksums()
    print("MASTER_KNOWN_LIMITATIONS_VERIFIED")
    print("verify_ok = true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
