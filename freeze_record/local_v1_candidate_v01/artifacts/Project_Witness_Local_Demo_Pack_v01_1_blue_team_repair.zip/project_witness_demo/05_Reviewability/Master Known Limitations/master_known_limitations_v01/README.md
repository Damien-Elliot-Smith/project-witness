# Project Witness — Master Known Limitations Document v0.1

```text
Move: 35
Package: master_known_limitations_v01
Status: candidate for freeze review
Type: documentation-only
```

## Purpose

This package is the Move 35 documentation artifact for Project Witness Part One.
It consolidates the known limitations of the frozen local demo stack so reviewers can see exactly what the project does **not** claim.

The goal is not to make the system look stronger than it is. The goal is to make the boundary visible.

## What this package contains

```text
README.md
MASTER_KNOWN_LIMITATIONS.md
LIMITATIONS_INDEX.md
RELEASE_GATE.md
VERIFICATION.md
TEST_RESULTS.md
REPAIR_LEDGER.md
CHECKSUMS.txt
tools/verify_master_known_limitations.py
```

## What "known limitation" means

A known limitation is a current boundary of the system that must not be hidden, softened, or converted into marketing language.

A limitation is not automatically a failure. It becomes dangerous when the project claims, implies, or lets reviewers assume more than the current artifact can prove.

Examples:

- No GUI is a current limitation, but it is not a blocker for a local demo package.
- No external anchoring is a current limitation, but it is not a blocker if the package does not claim tamper-proof public anchoring.
- Not proving evidence contents are true is a fundamental truth-boundary limitation. It becomes a blocker only if the project claims truth proof.

## How to run the verifier

From the package root:

```bash
python tools/verify_master_known_limitations.py
```

Expected successful output:

```text
MASTER_KNOWN_LIMITATIONS_VERIFIED
verify_ok = true
```

## Why this supports external review

Reviewers need to know the system boundary before they attack it. This document prevents the local demo from being presented as something it is not: not a truth oracle, not a production security product, not a signed public attestation system, not a GUI product, and not a natural-language reasoning agent.

## Scope boundary

This package does not run the Project Witness stack. It does not modify frozen artifacts. It does not add runtime authority. It does not build the Move 36 Threat Model, Move 37 External Review Pack, Move 38 Hostile Review Prompt Pack, Move 39 Response-to-Review Ledger, or Move 40 Local Demo Pack freeze.

## North Star

Power without truth becomes corruption.  
Action without restraint becomes harm.  
Memory without honesty becomes mythology.  
Intelligence without limits becomes predatory.
