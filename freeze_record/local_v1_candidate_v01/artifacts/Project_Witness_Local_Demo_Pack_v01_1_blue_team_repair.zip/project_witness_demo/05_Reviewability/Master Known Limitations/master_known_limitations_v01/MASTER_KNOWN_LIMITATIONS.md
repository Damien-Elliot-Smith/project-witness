# Project Witness — Master Known Limitations Document v0.1

```text
Move: 35
Artifact: MASTER_KNOWN_LIMITATIONS.md
Package: master_known_limitations_v01
Type: documentation-only
```

## 1. Purpose

This document records the known limitations of Project Witness Part One as of Move 35.

Its job is to stop overclaiming. The project is allowed to be unfinished. It is not allowed to pretend that an unfinished boundary is already solved.

This document is part of Phase 6 — Usability and Reviewability. It prepares the stack for honest review by making the current limits explicit before the Threat Model, External Review Pack, Hostile Review Prompt Pack, Response-to-Review Ledger, and Local Demo Pack freeze are built.

## 2. Truth-boundary statement

Project Witness does not prove that the real world is true.

Project Witness does not prove that evidence contents are true.

Project Witness does not prove ODIN claims are true.

Project Witness preserves and verifies structured relationships between files, hashes, manifests, receipts, statuses, and declared workflow outputs under the tested local demo conditions.

The strongest honest claim is:

> Project Witness can make specific provenance, workflow, verification, and documentation boundaries visible, reproducible, and reviewable. It does not by itself prove external reality.

## 3. Hard current limitations

These are current hard limits of the Move 35 / Part One local demo state.

### LIM-001 — Does not prove evidence contents are true

The system can preserve evidence files and hash relationships. It cannot prove that the underlying contents accurately represent reality.

A forged photograph, false statement, misleading document, or fabricated input can still be hashed and preserved.

### LIM-002 — Does not prove ODIN claims are true

ODIN can reason deterministically over structured claims and rule packs. It cannot make false input claims true.

If the claim model is wrong, incomplete, biased, or fabricated, deterministic reasoning can still produce a clean trace over bad material.

### LIM-003 — Does not verify external reality

The current stack does not independently check the outside world. It does not validate physical events, legal facts, human intent, sensor reality, or social context.

### LIM-004 — Does not prove sources are trusted

A source file can be included and hashed. That does not prove the source is trustworthy, authorised, unbiased, complete, or original.

### LIM-005 — Does not prove files are authentic beyond hash matching

Hashes can prove that bytes match a known digest. Hashes do not prove who created the file, whether the creator was authorised, whether the file is original, or whether the first submitted version was honest.

### LIM-006 — Does not sign outputs

The current local demo stack does not apply cryptographic signatures to outputs.

### LIM-007 — Does not externally anchor outputs

The current local demo stack does not anchor outputs to a public ledger, timestamping service, transparency log, blockchain, or external notarisation system.

### LIM-008 — Whole-folder fabrication remains possible under unkeyed hashes

If an attacker can fabricate an entire folder and all internal hashes from the beginning, unkeyed hashes alone cannot prove that the folder came from a trusted origin.

### LIM-009 — One successful demo path is not full production assurance

A completed local demo path proves that this tested path can complete under tested conditions. It does not prove all paths, environments, adversarial inputs, packaging modes, or future changes are safe.

### LIM-010 — Not a GUI

The current demo is not a graphical product.

### LIM-011 — Not an Android app

The current demo is not an Android application.

### LIM-012 — Not a Windows app

The current demo is not a Windows application.

### LIM-013 — Not a web UI

The current demo is not a web interface or hosted web service.

### LIM-014 — Not LLM reasoning

The current local demo stack does not depend on LLM reasoning to complete the verified path.

### LIM-015 — Not natural-language interpretation

The current stack does not claim to understand natural language, interpret ambiguous human context, or infer intent from free text.

### LIM-016 — Not production incident response

The current stack does not provide production incident response, alerting, escalation, containment, forensics workflow, or response coordination.

### LIM-017 — Not multi-case search

The current stack does not provide a long-term searchable case store across many cases.

### LIM-018 — Not a multi-actor approval chain

The current stack does not provide human approval chains, actor roles, approval thresholds, or multi-sign review workflows.

### LIM-019 — Not policy governance

The current stack does not provide organisation-level policy governance, policy lifecycle, exception management, or compliance administration.

### LIM-020 — Local-only trust assumptions

The demo assumes a local filesystem and a local review context. It does not solve remote trust, compromised hosts, malicious operators, or hostile deployment infrastructure.

### LIM-021 — Reviewer trust assumptions

A reviewer must still decide whether they trust the provided artifact source, checksum channel, environment, and operator process.

### LIM-022 — Hash-only verification limits

Hash verification detects byte changes relative to an expected digest. It does not prove identity, authority, provenance outside the bundle, or external truth.

### LIM-023 — Demo-path narrowness

The current demo verifies a narrow local demonstration path. It is not a comprehensive product test matrix.

### LIM-024 — Frozen-component compatibility repairs

Some repairs exist to make legacy frozen components work together honestly. These repairs should be treated as explicit compatibility records, not as proof that early components were perfect.

### LIM-025 — Documentation does not create runtime authority

This is the documentation vs runtime authority boundary.

This limitations document can clarify boundaries. It does not add runtime enforcement, cryptographic guarantees, or new verification powers.

### LIM-026 — Case-bundle portability limits

A portable bundle can help reviewers inspect outputs. Portability does not prove authenticity, authorisation, external anchoring, or future readability forever.

### LIM-027 — Operator error remains possible

Users can run the wrong command, inspect the wrong folder, trust the wrong artifact, ignore warnings, or misunderstand the boundary.

### LIM-028 — Environment assumptions remain

The tested path assumes a compatible Python environment, filesystem behaviour, archive extraction behaviour, and local command execution model.

### LIM-029 — No cryptographic identity

This is the lack of cryptographic identity limitation.

The current stack does not bind outputs to a verified cryptographic identity for a person, organisation, machine, or release authority.

### LIM-030 — No remote attestation

This is the lack of remote attestation limitation.

The current stack does not prove the state of the machine or runtime environment that produced the outputs.

### LIM-031 — No access control

This is the lack of access control limitation.

The current demo does not implement production access control, authentication, authorisation, or permission separation.

### LIM-032 — No role permissions

This is the lack of role permissions limitation.

The current demo does not implement organisation roles such as reviewer, approver, operator, auditor, owner, or administrator.

### LIM-033 — No organisation governance

This is the lack of organisation governance limitation.

The current demo does not implement governance processes, policy boards, approval committees, exception handling, or audit administration.

### LIM-034 — No production monitoring

This is the lack of production monitoring limitation.

The current demo does not include service monitoring, uptime checks, alerting, metrics, or operational dashboards.

### LIM-035 — No incident response

This is the lack of incident response limitation.

The current demo does not implement production incident response playbooks, triage, response ownership, containment, or post-incident review.

### LIM-036 — No privacy/redaction lifecycle

This is the lack of privacy/redaction lifecycle limitation.

The current demo does not provide a complete privacy lifecycle, redaction workflow, retention policy, deletion policy, or data minimisation layer.

### LIM-037 — No long-term storage/search guarantees

This is the lack of long-term storage/search guarantees limitation.

The current demo does not guarantee long-term storage durability, indexing, migration, search, archival integrity, or future compatibility.

## 4. Known expected limitations

These limits are expected at this roadmap stage and are not failures if stated honestly.

| ID | Limitation | Why expected now |
|---|---|---|
| LIM-010 | Not a GUI | Phase 6 is still local demo reviewability, not product UI. |
| LIM-011 | Not an Android app | Android belongs outside the current move. |
| LIM-012 | Not a Windows app | Windows packaging is not part of Move 35. |
| LIM-013 | Not a web UI | No hosted interface is planned for this move. |
| LIM-014 | Not LLM reasoning | The verified demo path is deterministic and local. |
| LIM-016 | Not production incident response | Incident response belongs to later roadmap work. |
| LIM-017 | Not multi-case search | Long-term case store/search belongs to later roadmap work. |
| LIM-018 | Not multi-actor approval chain | Multi-actor approval belongs to later roadmap work. |
| LIM-019 | Not policy governance | Governance belongs to later roadmap work. |

## 5. Future roadmap items

These limitations may be addressed later, but they are not built in Move 35.

| Limitation area | Future roadmap area |
|---|---|
| Threat analysis | Move 36 — Threat Model v0.1 |
| External reviewer packaging | Move 37 — External Review Pack v0.1 |
| Hostile review prompts | Move 38 — Hostile Review Prompt Pack |
| Review response tracking | Move 39 — Response-to-Review Ledger |
| Local demo freeze packaging | Move 40 — Freeze Project Witness Local Demo Pack |
| Stronger verification spine | Part Two, Step 71+ — Rust verification spine |
| Multi-actor approval | Part Three — Multi-Actor Case Bundles and Human Approval Chains |
| Human audit reports and risk bands | Part Three — Human Audit Reports, Evidence Quality Layer, Interpretation Confidence Gate |
| Incident response | Part Four — Incident Response Mode |
| Organisation permissions and governance | Part Four — Organisation Roles, Permissions, Policy/Governance Packs |
| Long-term store, search, redaction | Part Five — Long-Term Case Store, Search, Data Lifecycle, Redaction |
| Upgrade and recovery discipline | Part Five — Upgrade/Release, Backward Compatibility, Recovery Drills |

## 6. Non-goals for Move 35

Move 35 is not trying to solve these areas:

- proving reality;
- proving evidence truth;
- proving source trust;
- adding signatures;
- adding external anchoring;
- adding a GUI;
- adding Android or Windows applications;
- adding a web UI;
- adding LLM interpretation;
- adding production security operations;
- adding organisation governance;
- adding multi-case search;
- adding role permissions;
- adding incident response;
- building the Move 36 Threat Model;
- building the Move 37 External Review Pack;
- building the Move 38 Hostile Review Prompt Pack;
- building the Move 39 Response-to-Review Ledger;
- freezing the Move 40 Local Demo Pack.

## 7. Release blockers vs non-blockers

### 7.1 Non-blockers for local demo release

These are acceptable for the local demo pack if documented honestly:

| Limitation | Local demo blocker? | Reason |
|---|---:|---|
| no GUI | No | CLI/local documentation is acceptable for this phase. |
| no Android app | No | Mobile app is outside this roadmap move. |
| no Windows app | No | Windows packaging is outside this roadmap move. |
| no web UI | No | Hosted interface is outside this roadmap move. |
| no LLM reasoning | No | The local demo is deterministic and should not depend on LLM judgement. |
| no signing | No | Signing is a future hardening item if not claimed now. |
| no external anchoring | No | External anchoring is future work if not claimed now. |
| no production incident response | No | Production incident response is not required for a local demo. |
| no multi-case search | No | One-case demo reviewability is acceptable. |
| no organisation governance | No | Organisation governance is later roadmap work. |
| one narrow demo path only | No | Acceptable if described as a narrow demo, not production assurance. |

### 7.2 Blockers if overclaimed or hidden

These become blockers if the documentation or release language claims more than the system does:

| Hidden or overclaimed item | Why it becomes a blocker |
|---|---|
| claiming truth proof | The system does not prove external truth. |
| claiming external reality verification | The system does not independently verify reality. |
| claiming source trust proof | Hashes and manifests do not prove source trust. |
| claiming cryptographic identity | The current stack does not bind outputs to verified identity. |
| claiming tamper-proof guarantees | Unkeyed hashes do not prevent whole-folder fabrication. |
| claiming production readiness | One local demo path is not production assurance. |
| claiming full security assurance | Threat modelling and security review are not complete. |
| claiming deception prevention | The system cannot prevent all deception. |
| claiming natural-language understanding | The current stack is not an NL understanding system. |

### 7.3 True blockers for Move 40 local demo pack freeze

These would prevent a responsible local demo pack freeze:

| True blocker | Reason |
|---|---|
| known verifier false green | A verifier that passes bad artifacts destroys trust. |
| missing checksum | Reviewers cannot check file integrity. |
| missing release gate | Freeze criteria are not explicit. |
| documentation claiming capabilities not present | Overclaiming violates the project truth boundary. |
| package cannot be verified | Reviewability is required for Phase 6. |
| package references missing frozen artifacts as if present | That would create false provenance. |
| limitations document contradicts frozen demo behaviour | The documentation must match what exists. |

## 8. Dangerous overclaims

| Overclaim | Why it is false or unsafe | Correct claim |
|---|---|---|
| "Project Witness proves truth." | False. It preserves and verifies structured provenance/hash relationships, not reality itself. | Project Witness helps preserve auditable evidence flow and exposes limits. |
| "ODIN proves claims are true." | False. ODIN reasons over structured inputs/rules. If inputs are wrong, outputs can still be wrong. | ODIN can produce deterministic reasoning traces from given claims and rule packs. |
| "The demo proves production readiness." | False. One successful local demo path is not production assurance. | The demo proves this frozen local path can complete and verify under tested conditions. |
| "Hashes prove authenticity." | False. Unkeyed hashes prove content matching, not origin or authority. | Hashes detect content changes relative to a known digest. |
| "The system prevents all deception." | False. It reduces some classes of silent drift and overclaiming but cannot stop all deception. | It makes specific provenance and verification failures more visible. |
| "The system verifies external reality." | False. The current stack does not independently observe or validate the outside world. | It verifies declared local artifacts and relationships under tested conditions. |
| "The bundle is tamper-proof." | False. A whole folder can be fabricated if no external signed reference exists. | The bundle can be checked for internal consistency and expected digest matches. |
| "The project is production-ready." | False. Production operations, access control, monitoring, incident response, and governance are not complete. | The local demo pack can be reviewed as a staged, limited artifact. |

## 9. Reviewer guidance

Reviewers should ask:

1. Does the package claim only what the current stack can support?
2. Are the limitations stated clearly enough that a beginner cannot mistake the demo for production assurance?
3. Are hash, manifest, and verifier claims separated from reality, source trust, and authenticity claims?
4. Are future roadmap items clearly marked as future work rather than hidden inside current claims?
5. Are narrow successful-path results described as narrow successful-path results?
6. Are compatibility repairs named honestly instead of buried?
7. Is any language implying truth proof, tamper-proofing, production readiness, or external reality verification?

A hostile reviewer should treat vague claims as suspect.

## 10. What this document does not cover

This document is not the Threat Model. The Threat Model is Move 36.

This document is not the External Review Pack. The External Review Pack is Move 37.

This document is not the Hostile Review Prompt Pack. The Hostile Review Prompt Pack is Move 38.

This document is not the Response-to-Review Ledger. The Response-to-Review Ledger is Move 39.

This document is not the Local Demo Pack freeze. That is Move 40.

This document does not provide legal, security, compliance, or production deployment assurance.

## 11. Final honest summary

Project Witness Part One has a narrow but useful claim: it can make a local evidence/workflow/provenance path more inspectable, reproducible, and harder to silently hand-wave.

It does not prove truth.

It does not prove reality.

It does not prove trust.

It does not prove production readiness.

Those boundaries are not embarrassing. They are the reason this limitations document exists.
