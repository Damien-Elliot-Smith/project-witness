# Project Witness — Move 35 Repair Ledger v0.1

```text
Move: 35
Artifact: REPAIR_LEDGER.md
```

## Repair status

One pre-release verifier repair was required during construction. It was found before final verification and before zip creation.

## Repair table

| Repair ID | Issue | Fix | Scope impact | Status |
|---|---|---|---|---|
| MKL-R001 | Verifier had a bracket mismatch in the disallowed-directory constant during first local execution. | Corrected the set closing delimiter and reran verification. | No scope change. Documentation package and verifier only. | CLOSED |
| MKL-R002 | Verifier correctly caught missing exact limitation phrases during content coverage checks. | Added explicit wording for documentation vs runtime authority and lack-of-* limitation phrases. | No scope change. Content clarification only. | CLOSED |
| MKL-R003 | Verifier repair-ledger check was too narrow and only accepted a no-repair ledger. | Updated verifier to accept an honest closed repair ledger. | No scope change. Verifier robustness only. | CLOSED |
| MKL-R004 | Verifier flagged release-gate fail-condition examples as possible affirmative overclaims. | Reworded fail-condition lines so they describe unsafe claim types without restating them as project claims. | No scope change. Documentation clarity only. | CLOSED |
