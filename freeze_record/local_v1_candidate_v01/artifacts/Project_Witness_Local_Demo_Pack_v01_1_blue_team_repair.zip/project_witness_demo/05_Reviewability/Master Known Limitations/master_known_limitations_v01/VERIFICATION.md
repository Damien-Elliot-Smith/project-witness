# Project Witness — Move 35 Verification v0.1

```text
Move: 35
Artifact: VERIFICATION.md
Verifier: tools/verify_master_known_limitations.py
```

## Verification purpose

The verifier checks that the Move 35 package has the required documentation structure and does not silently expand scope.

It is not a security proof. It is not a truth proof. It is not a production readiness check.

## How to run

From the package root:

```bash
python tools/verify_master_known_limitations.py
```

Expected success output:

```text
MASTER_KNOWN_LIMITATIONS_VERIFIED
verify_ok = true
```

## What the verifier checks

The verifier checks:

- required files exist;
- required headings exist;
- required limitation phrases appear;
- dangerous overclaims section exists;
- release blocker classification exists;
- future roadmap mapping exists;
- truth-boundary wording exists;
- forbidden overclaim phrases do not appear as affirmative project claims outside the corrected overclaim section;
- future roadmap items are marked as future work only;
- no code/runtime folders are included except tools/;
- CHECKSUMS.txt exists;
- README references Move 35;
- RELEASE_GATE contains PASS/FAIL criteria;
- REPAIR_LEDGER.md exists;
- TEST_RESULTS.md exists.

## What the verifier does not check

The verifier does not prove that the wider Project Witness stack works.

The verifier does not inspect frozen runtime artifacts.

The verifier does not verify external reality.

The verifier does not prove source trust.

The verifier does not check legal, security, compliance, privacy, or production deployment readiness.

## Determinism

The verifier uses only Python standard library modules.

It does not use internet access.

It does not import Project Witness runtime components.

It does not modify frozen artifacts.
