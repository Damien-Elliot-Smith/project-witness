# Project Witness — Limitations Index v0.1

```text
Move: 35
Artifact: LIMITATIONS_INDEX.md
```

| ID | Limitation | Category | Status | Blocker? | Future roadmap area |
|---|---|---|---|---|---|
| LIM-001 | does not prove evidence contents are true | Truth boundary | Hard current limitation | Blocker if overclaimed | Evidence Quality Layer / future review work |
| LIM-002 | does not prove ODIN claims are true | Truth boundary | Hard current limitation | Blocker if overclaimed | ODIN review / future reasoning assurance |
| LIM-003 | does not verify external reality | Truth boundary | Hard current limitation | Blocker if overclaimed | Threat Model / later evidence quality |
| LIM-004 | does not prove sources are trusted | Source trust | Hard current limitation | Blocker if overclaimed | Future source trust and governance work |
| LIM-005 | does not prove files are authentic beyond hash matching | Hash/authenticity | Hard current limitation | Blocker if overclaimed | Signing / identity / anchoring later |
| LIM-006 | does not sign outputs | Cryptographic hardening | Expected limitation | No, if documented | Part Two / later hardening |
| LIM-007 | does not externally anchor outputs | Cryptographic hardening | Expected limitation | No, if documented | Part Two / later anchoring |
| LIM-008 | whole-folder fabrication remains possible under unkeyed hashes | Hash/authenticity | Hard current limitation | Blocker if hidden | Part Two / signing / anchoring |
| LIM-009 | one successful demo path is not full production assurance | Assurance boundary | Hard current limitation | Blocker if overclaimed | Move 40 and Parts Two-Five |
| LIM-010 | not a GUI | Interface | Expected limitation | No | Later product/UI roadmap |
| LIM-011 | not an Android app | Interface | Expected limitation | No | Post-roadmap product work |
| LIM-012 | not a Windows app | Interface | Expected limitation | No | Post-roadmap product work |
| LIM-013 | not a web UI | Interface | Expected limitation | No | Later dashboard/API work |
| LIM-014 | not LLM reasoning | Capability boundary | Expected limitation | No | Future optional integrations only |
| LIM-015 | not natural-language interpretation | Capability boundary | Hard current limitation | Blocker if overclaimed | Future interpretation layer if ever scoped |
| LIM-016 | not production incident response | Operations | Expected limitation | No | Part Four incident response |
| LIM-017 | not multi-case search | Storage/search | Expected limitation | No | Part Five long-term case store/search |
| LIM-018 | not multi-actor approval chain | Human governance | Expected limitation | No | Part Three approval chains |
| LIM-019 | not policy governance | Organisation governance | Expected limitation | No | Part Four governance packs |
| LIM-020 | local-only trust assumptions | Deployment trust | Hard current limitation | Blocker if hidden | Threat Model / future deployment work |
| LIM-021 | reviewer trust assumptions | Review process | Hard current limitation | Blocker if hidden | External Review Pack |
| LIM-022 | hash-only verification limits | Verification boundary | Hard current limitation | Blocker if overclaimed | Rust verifier / signing / anchoring |
| LIM-023 | demo-path narrowness | Assurance boundary | Hard current limitation | No, if documented | Move 40 / later testing |
| LIM-024 | frozen-component compatibility repairs | Provenance history | Known limitation | No, if disclosed | Repair ledgers / future cleanup |
| LIM-025 | documentation vs runtime authority | Scope boundary | Hard current limitation | No | Later runtime enforcement if scoped |
| LIM-026 | case-bundle portability limits | Portability | Hard current limitation | No, if documented | Part Two and Part Five |
| LIM-027 | operator error | Human factors | Hard current limitation | No, if documented | Runbooks / UX / future UI |
| LIM-028 | environment assumptions | Execution environment | Hard current limitation | No, if documented | Portable binaries / Part Two |
| LIM-029 | lack of cryptographic identity | Identity | Hard current limitation | Blocker if overclaimed | Signing / identity later |
| LIM-030 | lack of remote attestation | Deployment trust | Hard current limitation | Blocker if overclaimed | Future hardening only |
| LIM-031 | lack of access control | Security/permissions | Expected limitation | No, if local demo only | Part Four roles/permissions |
| LIM-032 | lack of role permissions | Security/permissions | Expected limitation | No, if local demo only | Part Four roles/permissions |
| LIM-033 | lack of organisation governance | Governance | Expected limitation | No | Part Four governance |
| LIM-034 | lack of production monitoring | Operations | Expected limitation | No | Part Four / later operations |
| LIM-035 | lack of incident response | Operations | Expected limitation | No | Part Four incident response |
| LIM-036 | lack of privacy/redaction lifecycle | Data lifecycle | Expected limitation | No, if documented | Part Five data lifecycle/redaction |
| LIM-037 | lack of long-term storage/search guarantees | Storage/search | Expected limitation | No | Part Five long-term store/search |
