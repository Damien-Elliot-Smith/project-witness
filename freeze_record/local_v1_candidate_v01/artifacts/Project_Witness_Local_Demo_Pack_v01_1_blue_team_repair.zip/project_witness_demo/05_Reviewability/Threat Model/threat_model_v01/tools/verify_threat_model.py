#!/usr/bin/env python3
"""Verify Project Witness Threat Model v0.1 package.

Standard-library only. Run from the package root:
    python tools/verify_threat_model.py
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "THREAT_MODEL.md",
    "ASSETS.md",
    "TRUST_BOUNDARIES.md",
    "THREATS.md",
    "MITIGATIONS.md",
    "NON_GOALS.md",
    "RELEASE_GATE.md",
    "VERIFICATION.md",
    "TEST_RESULTS.md",
    "REPAIR_LEDGER.md",
    "CHECKSUMS.txt",
    "tools/verify_threat_model.py",
]

REQUIRED_PHRASES = {
    "README.md": [
        "Move: 36",
        "documentation-only",
        "does not prove evidence is true",
        "does not prove external reality",
        "does not prove source trust",
    ],
    "THREAT_MODEL.md": [
        "does **not** prove evidence contents are true",
        "does **not** verify external reality",
        "does **not** prove source trust",
        "does **not** provide cryptographic identity",
        "does **not** sign outputs",
        "does **not** externally anchor outputs",
        "whole-folder fabrication",
        "Protected assets",
        "Trust boundaries",
        "Attacker and failure model",
        "Threat catalogue",
        "Current controls",
        "Residual risks",
        "Blocker classification",
        "Dangerous overclaims",
        "Future roadmap mapping",
        "Explicit non-goals",
        "It does not prove truth.",
        "It does not verify external reality.",
        "It does not prove source trust.",
        "It does not provide production security assurance.",
    ],
    "ASSETS.md": [
        "honesty of claim",
        "Truth-boundary clarity",
    ],
    "TRUST_BOUNDARIES.md": [
        "Hashes identify bytes, not trust",
        "Project Witness must not claim",
    ],
    "THREATS.md": [
        "T-001",
        "T-010",
        "Whole-folder fabrication",
    ],
    "MITIGATIONS.md": [
        "Future mitigations not implemented here",
        "future work only",
        "Residual risk statement",
    ],
    "NON_GOALS.md": [
        "no runtime changes",
        "no local demo pack freeze",
    ],
    "RELEASE_GATE.md": [
        "PASS criteria",
        "FAIL criteria",
        "No Move 37/38/39/40 package is built",
        "No production-readiness claim is made",
    ],
    "VERIFICATION.md": [
        "What the verifier checks",
        "What the verifier does not check",
    ],
    "TEST_RESULTS.md": [
        "Verifier output",
        "ResourceWarning sweep output",
        "Runtime code tests",
    ],
    "REPAIR_LEDGER.md": [
        "No frozen artifacts were modified",
        "No runtime code was modified",
    ],
}

FORBIDDEN_DIRS = {
    "src", "app", "runtime", "coordinator", "companion", "sentinel", "histor", "odin", "atlas",
    "external_review_pack_v01", "hostile_review_prompt_pack_v01", "response_to_review_ledger_v01",
    "local_demo_pack_v01",
}

# These are forbidden as standalone affirmative claims. They may appear only as rejected examples
# in sections that also explain they are false/unsafe. This simple check catches the dangerous form.
FORBIDDEN_AFFIRMATIVE_LINES = [
    "Project Witness proves truth.",
    "Project Witness verifies external reality.",
    "Project Witness proves source trust.",
    "Project Witness is production-ready.",
    "Project Witness prevents all deception.",
    "Hashes prove authenticity.",
    "ODIN proves claims are true.",
]

ALLOWED_OVERCLAIM_CONTEXT = [
    "must not claim",
    "Overclaim",
    "Why it is false or unsafe",
    "Correct claim",
    "package claims",
    "claiming",
]


def fail(message: str) -> None:
    print(f"VERIFY_FAIL: {message}")
    print("verify_ok = false")
    raise SystemExit(1)


def read(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def check_required_files() -> None:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).is_file():
            fail(f"missing required file: {rel}")


def check_required_phrases() -> None:
    for rel, phrases in REQUIRED_PHRASES.items():
        text = read(rel)
        for phrase in phrases:
            if phrase not in text:
                fail(f"missing required phrase in {rel}: {phrase!r}")


def check_forbidden_dirs() -> None:
    for path in ROOT.iterdir():
        if path.is_dir() and path.name != "tools" and path.name in FORBIDDEN_DIRS:
            fail(f"forbidden runtime or future-move directory included: {path.name}")
    for path in ROOT.rglob("*"):
        if path.is_dir() and path.name in FORBIDDEN_DIRS:
            fail(f"forbidden directory included: {path.relative_to(ROOT)}")


def check_no_dangerous_affirmative_claims() -> None:
    for rel in [p for p in REQUIRED_FILES if p.endswith(".md")]:
        lines = read(rel).splitlines()
        for idx, line in enumerate(lines, start=1):
            stripped = line.strip().strip("| ")
            for forbidden in FORBIDDEN_AFFIRMATIVE_LINES:
                if stripped == forbidden:
                    context = "\n".join(lines[max(0, idx-3): min(len(lines), idx+2)])
                    if not any(marker in context for marker in ALLOWED_OVERCLAIM_CONTEXT):
                        fail(f"dangerous affirmative claim in {rel}:{idx}: {forbidden}")


def parse_checksums() -> dict[str, str]:
    checksums = {}
    for line in read("CHECKSUMS.txt").splitlines():
        if not line.strip():
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            fail(f"malformed CHECKSUMS.txt line: {line!r}")
        digest, rel = parts
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            fail(f"invalid sha256 digest for {rel}: {digest}")
        checksums[rel] = digest
    return checksums


def check_checksums() -> None:
    checksums = parse_checksums()
    actual_files = []
    for path in ROOT.rglob("*"):
        if path.is_file():
            rel = path.relative_to(ROOT).as_posix()
            if rel == "CHECKSUMS.txt":
                continue
            actual_files.append(rel)
    actual_files.sort()
    expected_files = sorted(checksums)
    if actual_files != expected_files:
        missing = sorted(set(actual_files) - set(expected_files))
        extra = sorted(set(expected_files) - set(actual_files))
        fail(f"checksum file list mismatch; missing={missing}, extra={extra}")
    for rel in actual_files:
        digest = sha256(ROOT / rel)
        if checksums[rel] != digest:
            fail(f"checksum mismatch for {rel}: expected {checksums[rel]}, got {digest}")


def main() -> int:
    check_required_files()
    check_required_phrases()
    check_forbidden_dirs()
    check_no_dangerous_affirmative_claims()
    check_checksums()
    print("THREAT_MODEL_VERIFIED")
    print("verify_ok = true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
