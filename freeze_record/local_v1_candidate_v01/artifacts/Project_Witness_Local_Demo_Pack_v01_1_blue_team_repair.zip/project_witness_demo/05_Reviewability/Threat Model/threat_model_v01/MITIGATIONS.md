# Mitigations and Residual Risks — Threat Model v0.1

## Purpose

This file separates current controls from future mitigations.

## Current mitigations

| Control ID | Current mitigation | Threats helped | Limit |
|---|---|---|---|
| C-001 | Checksums | T-003, T-005 | Do not prove origin or identity. |
| C-002 | Documentation verifier | T-007, T-008, T-010 | Checks package shape and required language only. |
| C-003 | Release gate | T-006, T-007, T-008 | Depends on honest use. |
| C-004 | Repair ledger | T-009 | Does not prove no hidden defects. |
| C-005 | Known limitations document | T-001, T-002, T-003, T-004 | Cannot force readers to understand or obey it. |
| C-006 | Architecture diagrams | T-007 | Explanatory only. |
| C-007 | Future roadmap mapping | T-008 | Does not implement the future feature. |

## Future mitigations not implemented here

| Future mitigation | Roadmap area | Current status |
|---|---|---|
| signing | later roadmap, not Move 36 | future work only |
| external anchoring | later roadmap, not Move 36 | future work only |
| cryptographic identity | later roadmap, not Move 36 | future work only |
| access control | Part Four | future work only |
| organisation roles | Part Four | future work only |
| incident response | Part Four | future work only |
| long-term case search | Part Five | future work only |
| privacy/redaction lifecycle | Part Five | future work only |
| Rust verification spine | Part Two Step 71+ | future work only |

## Residual risk statement

The current package reduces ambiguity. It does not remove the main risks.

The unresolved high-value risks are whole-folder fabrication, source authenticity, external truth verification, production security, and human overclaiming.
