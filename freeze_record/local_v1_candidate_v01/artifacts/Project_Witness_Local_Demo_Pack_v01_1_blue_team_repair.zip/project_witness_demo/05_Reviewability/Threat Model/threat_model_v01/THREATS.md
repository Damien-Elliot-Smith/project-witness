# Threat Catalogue — Threat Model v0.1

## Purpose

This file expands the core threat catalogue into reviewer-friendly entries.

## T-001 — False evidence enters the system

- Category: input truth failure
- Cause: the system receives false or misleading evidence
- Current control: truth-boundary wording and known limitations
- Residual risk: structural validity can be mistaken for truth
- Status: accepted limitation if documented

## T-002 — ODIN output treated as truth proof

- Category: reasoning misuse
- Cause: deterministic reasoning trace is misread as reality proof
- Current control: dangerous overclaim correction
- Residual risk: readers may still overtrust formal-looking output
- Status: blocker if overclaimed

## T-003 — Hashes treated as authenticity proof

- Category: integrity/authenticity confusion
- Cause: users confuse byte equality with origin proof
- Current control: checksum wording
- Residual risk: unkeyed hashes do not prove creator identity
- Status: accepted limitation if documented

## T-004 — Whole-folder fabrication

- Category: package substitution
- Cause: attacker creates a coherent fake folder and checksum set
- Current control: explicit limitation, future signing/anchoring mapping
- Residual risk: unresolved in current local demo
- Status: accepted limitation if documented; blocker if hidden

## T-005 — Frozen artifact silently modified

- Category: integrity drift
- Cause: frozen folder is edited after freeze
- Current control: freeze folder discipline and checksums
- Residual risk: if all references are replaced, detection is limited
- Status: true blocker if known

## T-006 — Demo path overclaimed as production readiness

- Category: scope overclaim
- Cause: one successful demo is advertised as broad assurance
- Current control: known limitations and release gate language
- Residual risk: public misunderstanding
- Status: blocker if claimed

## T-007 — Documentation claims runtime authority

- Category: authority confusion
- Cause: documents imply enforcement not implemented in code
- Current control: documentation-only scope statement
- Residual risk: language drift
- Status: blocker if present

## T-008 — Future roadmap item presented as current feature

- Category: roadmap drift
- Cause: planned features are written as if already built
- Current control: future roadmap mapping
- Residual risk: accidental hype
- Status: blocker if present

## T-009 — Compatibility repair hides earlier defect

- Category: repair opacity
- Cause: repair history is omitted or sanitized
- Current control: repair ledger discipline
- Residual risk: readers may skip repair history
- Status: non-blocker if recorded

## T-010 — Verifier gives false green

- Category: verification defect
- Cause: verifier passes a broken package
- Current control: release gate and reviewer rerun
- Residual risk: verifier itself is limited
- Status: true blocker if known
