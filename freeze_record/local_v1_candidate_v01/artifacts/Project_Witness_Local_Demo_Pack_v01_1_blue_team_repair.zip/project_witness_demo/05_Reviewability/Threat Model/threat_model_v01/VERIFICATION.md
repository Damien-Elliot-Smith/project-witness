# Verification — Threat Model v0.1

## Verifier

The verifier is:

```text
tools/verify_threat_model.py
```

Run from the package root:

```bash
python tools/verify_threat_model.py
```

## Expected output

```text
THREAT_MODEL_VERIFIED
verify_ok = true
```

## What the verifier checks

The verifier checks:

- required files exist
- required headings and phrases exist
- checksum file exists
- checksum file matches package contents
- release gate includes PASS and FAIL criteria
- threat model names protected assets
- threat model names trust boundaries
- threat model names attacker/failure model
- threat model names whole-folder fabrication
- threat model distinguishes blockers and non-blockers
- future roadmap items are marked as future work
- package does not include forbidden runtime directories
- package does not include Move 37, Move 38, Move 39, or Move 40 package folders
- package does not make affirmative production-readiness/truth-proof claims

## What the verifier does not check

The verifier does not prove:

- evidence truth
- external reality
- source trust
- production security
- cryptographic identity
- absence of all defects
- quality of all human wording

The verifier is a local consistency check for this documentation package.
