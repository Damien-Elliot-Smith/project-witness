# Trust Boundaries — Threat Model v0.1

## Purpose

This document records where Project Witness crosses from trusted local checks into untrusted reality, human action, or future work.

## Boundary table

| Boundary ID | Boundary | Trusted side | Untrusted side | Notes |
|---|---|---|---|---|
| TB-001 | External reality to evidence file | Local structural checks | Real-world event truth | The system cannot prove the world matched the evidence. |
| TB-002 | Evidence file to structured claim | Parser/adapter output | Original source context | Important context can be missing or false. |
| TB-003 | Structured claim to ODIN reasoning | Deterministic rule processing | Claim truth | ODIN can reason consistently over false claims. |
| TB-004 | File content to hash digest | Hash function result | Meaning, origin, authority | Hashes identify bytes, not trust. |
| TB-005 | Frozen package to reviewer copy | Known checksum | Distributed copy | Without signing, substitution remains possible. |
| TB-006 | Documentation to runtime behaviour | Actual runtime code | Explanatory text | Docs do not create enforcement. |
| TB-007 | Local demo to production | Tested local path | Real deployment | Production requires controls not present. |
| TB-008 | Current roadmap to future roadmap | Frozen current moves | Planned later capabilities | Future work must stay labelled as future work. |

## Required truth-boundary wording

The system may claim:

```text
Project Witness makes defined local artifacts, hashes, statuses, repairs, and limitations reviewable.
```

Project Witness must not claim:

```text
Forbidden: Project Witness proves truth.
Forbidden: Project Witness verifies external reality.
Forbidden: Project Witness proves source trust.
Forbidden: Project Witness is production-ready.
Forbidden: Project Witness prevents all deception.
```
