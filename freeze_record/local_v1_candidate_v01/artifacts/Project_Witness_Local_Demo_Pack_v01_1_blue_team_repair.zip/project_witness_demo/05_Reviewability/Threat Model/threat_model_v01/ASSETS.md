# Assets — Threat Model v0.1

## Purpose

This file names the assets that the Move 36 threat model is trying to protect or keep honest.

## Asset table

| Asset ID | Asset | Description | Failure if compromised |
|---|---|---|---|
| A-001 | Frozen artifact integrity | Frozen packages should remain unchanged after freeze. | Reviewers may inspect a different system than the one claimed. |
| A-002 | Demo output integrity | Demo outputs should remain exactly as generated. | A fake output may be mistaken for a real run. |
| A-003 | Verification status honesty | PASS/FAIL/INCONCLUSIVE must mean defined checks ran. | The project fakes green. |
| A-004 | Checksum accuracy | CHECKSUMS.txt must match package files. | Review cannot detect accidental drift. |
| A-005 | Repair traceability | Repairs must remain visible. | Defects get buried. |
| A-006 | Limitation visibility | Known limitations must be easy to find. | Users may overtrust the system. |
| A-007 | Roadmap boundary | Future work must not be presented as current capability. | Scope creep creates false claims. |
| A-008 | Reviewer confidence | Reviewers need clear evidence of what was checked. | Review becomes guesswork. |
| A-009 | Truth-boundary clarity | Evidence preservation must not be confused with truth proof. | The system is misunderstood as a truth machine. |
| A-010 | Local demo reproducibility | The local demo path should be understandable and rerunnable. | Reviewers cannot distinguish working demo from claim-only docs. |

## Most important asset

The most important asset at Move 36 is **honesty of claim**.

If the project overclaims, the technical work becomes unsafe even if the files are well-structured.
