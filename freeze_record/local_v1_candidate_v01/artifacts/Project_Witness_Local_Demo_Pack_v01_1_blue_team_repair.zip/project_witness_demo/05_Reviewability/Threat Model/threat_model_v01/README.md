# Project Witness Threat Model v0.1

```text
Move: 36
Package: threat_model_v01
Status: candidate for freeze review
Type: documentation-only
```

## Purpose

This package is the first Project Witness threat model for the frozen local demo stack.

It names the assets, trust boundaries, attacker assumptions, likely threats, existing controls, residual risks, and explicit non-goals for the current Roadmap Part One local demo.

The purpose is not to claim security. The purpose is to prevent false security claims and make review easier.

## Scope

This package covers the frozen local demo and reviewability layer through Move 35:

- Connected Demo v0.1
- Beginner Runbook v0.1
- One-Command Demo Script v0.1
- Demo Output Bundle v0.1
- Architecture Diagram v0.1
- Master Known Limitations Document v0.1

This package does not modify any frozen artifact.

## Out of scope

This package does not build:

- Move 37 External Review Pack
- Move 38 Hostile Review Prompt Pack
- Move 39 Response-to-Review Ledger
- Move 40 Local Demo Pack Freeze
- signing
- anchoring
- identity
- access control
- production incident response
- GUI
- Android app
- Windows app
- web UI
- LLM integration

## How to verify

From inside this package root, run:

```bash
python tools/verify_threat_model.py
```

Expected success output:

```text
THREAT_MODEL_VERIFIED
verify_ok = true
```

## What this threat model means

A threat model is an honest map of what can go wrong.

It does not prove the system is secure.

It does not prove evidence is true.

It does not prove external reality.

It does not prove source trust.

It helps reviewers ask sharper questions and stops the project from hiding known weaknesses.

## North Star

```text
Power without truth becomes corruption.
Action without restraint becomes harm.
Memory without honesty becomes mythology.
Intelligence without limits becomes predatory.
```
