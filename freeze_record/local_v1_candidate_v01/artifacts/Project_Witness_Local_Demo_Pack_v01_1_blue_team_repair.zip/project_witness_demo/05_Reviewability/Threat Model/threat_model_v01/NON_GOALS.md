# Non-Goals — Threat Model v0.1

Move 36 is deliberately narrow.

## Not included

This package does not include:

- code changes
- no runtime changes
- new workflow actions
- new Atlas terms
- new ODIN rules
- new Sentinel rules
- new Histor-lite behaviour
- signing
- anchoring
- identity
- access control
- role permissions
- production monitoring
- incident response
- GUI
- Android app
- Windows app
- web UI
- LLM integration
- natural-language interpretation
- external review pack
- hostile review prompt pack
- response-to-review ledger
- no local demo pack freeze

## Why this matters

A threat model is useful only if it does not smuggle in imaginary controls.

Move 36 names risks. It does not solve all of them.
