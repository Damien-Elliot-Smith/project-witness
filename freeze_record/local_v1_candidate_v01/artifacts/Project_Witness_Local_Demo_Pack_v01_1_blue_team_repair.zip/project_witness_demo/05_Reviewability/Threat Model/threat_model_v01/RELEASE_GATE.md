# Release Gate — Threat Model v0.1

## Gate purpose

This release gate decides whether Move 36 is complete enough for freeze review.

It does not decide whether Project Witness is production-ready.

## PASS criteria

Move 36 passes only if all of the following are true:

| Gate ID | Criterion | Required result |
|---|---|---|
| G-001 | README exists | PASS |
| G-002 | THREAT_MODEL.md exists | PASS |
| G-003 | ASSETS.md exists | PASS |
| G-004 | TRUST_BOUNDARIES.md exists | PASS |
| G-005 | THREATS.md exists | PASS |
| G-006 | MITIGATIONS.md exists | PASS |
| G-007 | NON_GOALS.md exists | PASS |
| G-008 | VERIFICATION.md exists | PASS |
| G-009 | TEST_RESULTS.md exists | PASS |
| G-010 | REPAIR_LEDGER.md exists | PASS |
| G-011 | CHECKSUMS.txt exists | PASS |
| G-012 | Verifier exists | PASS |
| G-013 | Verifier passes | PASS |
| G-014 | Threat model states it does not prove truth | PASS |
| G-015 | Threat model states it does not verify external reality | PASS |
| G-016 | Threat model states hashes do not prove authenticity | PASS |
| G-017 | Whole-folder fabrication risk is named | PASS |
| G-018 | Blockers and non-blockers are distinguished | PASS |
| G-019 | Future roadmap items are marked as future work only | PASS |
| G-020 | No Move 37/38/39/40 package is built | PASS |
| G-021 | No runtime folders are included except tools/ | PASS |
| G-022 | No production-readiness claim is made | PASS |

## FAIL criteria

Move 36 fails if any of the following are true:

- required file missing
- verifier missing
- verifier fails
- checksum file missing
- checksum file stale
- package claims Project Witness proves truth
- package claims external reality verification
- package claims source trust proof
- package claims tamper-proof guarantees
- package claims production readiness
- package implements or packages Move 37, Move 38, Move 39, or Move 40
- package modifies frozen runtime artifacts
- package includes runtime source folders beyond tools/
- package presents future roadmap items as current features

## Gate result

```text
Gate status: PASS, if and only if tools/verify_threat_model.py prints THREAT_MODEL_VERIFIED and verify_ok = true.
```
