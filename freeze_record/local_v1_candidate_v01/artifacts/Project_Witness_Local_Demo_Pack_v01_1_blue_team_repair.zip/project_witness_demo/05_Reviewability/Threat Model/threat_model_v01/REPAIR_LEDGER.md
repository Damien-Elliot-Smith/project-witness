# Repair Ledger — Threat Model v0.1

## Purpose

This ledger records repairs made while building Move 36.

## Repairs

| Repair ID | Issue | Fix | Scope impact | Status |
|---|---|---|---|---|
| R-001 | Initial verifier draft needed stronger checksum validation. | Added checksum-file parsing and digest comparison for all files except CHECKSUMS.txt. | Documentation verifier only. No runtime impact. | COMPLETE |
| R-002 | Initial threat model wording could be misread as broader security assurance. | Added explicit statements that the threat model does not prove security, truth, external reality, source trust, or production readiness. | Documentation wording only. | COMPLETE |
| R-003 | Verifier failed on exact required wording for trust-boundary and non-goal phrases. | Tightened wording so the required scope and boundary phrases are present exactly. | Documentation wording and verifier alignment only. | COMPLETE |
| R-004 | Verifier correctly rejected forbidden claims that appeared as bare lines in a code block. | Reworded forbidden examples so they cannot be mistaken for affirmative claims. | Documentation wording only. | COMPLETE |

## Frozen artifact impact

No frozen artifacts were modified.

## Runtime impact

No runtime code was modified.
