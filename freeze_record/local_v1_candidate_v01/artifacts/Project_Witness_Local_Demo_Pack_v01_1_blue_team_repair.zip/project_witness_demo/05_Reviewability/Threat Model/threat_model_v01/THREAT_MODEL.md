# Project Witness Threat Model v0.1

```text
Move: 36
Document type: threat model
Scope: frozen local demo stack through Move 35
Runtime authority: none
Status: candidate for freeze review
```

## 1. Executive summary

Project Witness is currently a local, deterministic, provenance-and-verification demo stack.

The current stack can demonstrate that a narrow local workflow completed, that expected structured artifacts were produced, and that hashes/statuses/verifier outputs match the tested demo path.

The current stack does **not** prove evidence contents are true, does **not** verify external reality, does **not** prove source trust, does **not** provide cryptographic identity, does **not** sign outputs, and does **not** externally anchor outputs.

The main security risk at this stage is not remote exploitation. The main risk is **overclaiming**: presenting a local hash/provenance demo as a truth machine, production security system, tamper-proof record, or deception-prevention platform.

## 2. Scope boundary

This threat model covers the local demo stack and reviewability documents through Move 35.

Covered artifacts include:

- frozen local demo packages
- verifier scripts for documentation/review packages
- checksum files
- generated demo output bundle
- architecture documentation
- master known limitations document
- local review workflow assumptions

This threat model does not cover production deployments, remote services, organisations, users with roles, live incident response, long-term case storage, distributed signing, external anchoring, or policy governance.

## 3. Protected assets

The main assets are:

| Asset ID | Asset | Why it matters |
|---|---|---|
| A-001 | Frozen artifact integrity | Reviewers need to know whether files changed after freeze. |
| A-002 | Demo output integrity | Demo outputs must not be silently edited after generation. |
| A-003 | Verification status honesty | PASS/FAIL/INCONCLUSIVE statuses must not be invented or hidden. |
| A-004 | Scope boundary honesty | The project must not imply capabilities that are not present. |
| A-005 | Limitation visibility | Known weaknesses must remain visible to reviewers. |
| A-006 | Checksum reproducibility | Reviewers need deterministic file identity checks. |
| A-007 | Review trail continuity | Repairs and compatibility allowances must be traceable. |
| A-008 | Operator trust | Users must not be misled into relying on the demo as production assurance. |
| A-009 | Truth-boundary language | The system must distinguish evidence preservation from truth proof. |
| A-010 | Roadmap discipline | Later features must not be smuggled into earlier moves. |

## 4. Trust boundaries

| Boundary ID | Boundary | Trusted side | Untrusted side | Main risk |
|---|---|---|---|---|
| TB-001 | External world to submitted evidence | Local artifact parser/verifier | Real-world events and claims | False evidence can enter the system. |
| TB-002 | User/operator to local filesystem | Frozen package expectations | Manual copying, editing, deletion | Operator can accidentally or deliberately alter files. |
| TB-003 | Frozen artifact to reviewer copy | Published checksum/reference digest | Downloaded/repacked folder | Whole-folder substitution remains possible without signing. |
| TB-004 | Structured claims to ODIN reasoning | Deterministic rule application | Claim truth in the world | Deterministic reasoning can process false inputs. |
| TB-005 | Hash matching to authenticity | Known digest comparison | Origin/authority of digest | Hashes do not prove who created a file. |
| TB-006 | Documentation to runtime authority | Explanatory docs | Actual execution controls | Documentation can overstate runtime capabilities. |
| TB-007 | Local demo to production claims | One tested path | Real deployments | A narrow demo can be misrepresented as production assurance. |
| TB-008 | Roadmap boundary to feature pressure | Current move scope | Future features | Future work can be accidentally presented as current capability. |

## 5. Attacker and failure model

This threat model considers both malicious attackers and ordinary failure modes.

### 5.1 Malicious actors

| Actor ID | Actor | Capability | Example behaviour |
|---|---|---|---|
| ACT-001 | Dishonest promoter | Can describe the project publicly | Claims the system proves truth or prevents all deception. |
| ACT-002 | Local file tamperer | Can edit files before review | Changes outputs or docs and recomputes local unkeyed hashes. |
| ACT-003 | Bundle fabricator | Can create a complete fake folder | Produces a coherent but non-original package with matching internal hashes. |
| ACT-004 | False evidence submitter | Can provide misleading input evidence | Supplies false files that pass structural validation. |
| ACT-005 | Misleading reviewer | Can quote selectively | Ignores limitations and amplifies only positive claims. |
| ACT-006 | Supply-chain substituter | Can replace a zip or checksum channel | Gives reviewers a different package than the intended one. |

### 5.2 Non-malicious failures

| Failure ID | Failure | Example |
|---|---|---|
| FAIL-001 | Operator error | Running verifier from the wrong folder. |
| FAIL-002 | Environment mismatch | Different Python version or platform behaviour. |
| FAIL-003 | Documentation drift | README says one thing while verifier checks another. |
| FAIL-004 | Missing artifact | A package references a frozen artifact not present to the reviewer. |
| FAIL-005 | Ambiguous wording | A limitation is phrased so weakly that readers infer a false guarantee. |
| FAIL-006 | Green status misuse | A PASS status is treated as proof of reality rather than proof of a defined check. |

## 6. Threat catalogue

| Threat ID | Threat | Category | Existing control | Residual risk | Current status |
|---|---|---|---|---|---|
| T-001 | False evidence enters the system | Input truth | Truth-boundary language; limitations document | Structural checks cannot prove real-world truth | Accepted limitation |
| T-002 | ODIN output treated as truth proof | Reasoning misuse | Dangerous overclaim correction | Readers may still misunderstand deterministic reasoning | Accepted limitation if documented |
| T-003 | Hashes treated as authenticity proof | Integrity/authenticity confusion | Known limitations; checksum wording | Unkeyed hashes do not prove origin | Accepted limitation |
| T-004 | Whole-folder fabrication | Package substitution | Checksums inside package; external reviewer caution | Without signing/anchoring, a full fake package can be coherent | Accepted limitation |
| T-005 | Frozen artifact silently modified | Integrity drift | Freeze folders; checksum recording; verifier checks | If attacker controls all copies, detection is limited | Blocker if hidden |
| T-006 | Demo path overclaimed as production readiness | Scope overclaim | README/release gate/non-goals | Public readers may exaggerate result | Blocker if claimed |
| T-007 | Documentation claims runtime authority | Authority confusion | Documentation-only scope markers | Readers may treat docs as controls | Blocker if docs imply enforcement |
| T-008 | Future roadmap item presented as current feature | Scope creep | Future-work mapping | Marketing language can blur current/future state | Blocker if present |
| T-009 | Compatibility repair hides earlier defect | Repair opacity | Repair ledger | Repair history may be ignored or misunderstood | Non-blocker if recorded |
| T-010 | Verifier gives false green | Verification defect | Deterministic verifier; release gate | Verifier checks are limited and can have bugs | True blocker if known |
| T-011 | Checksum file missing or stale | Verification failure | Required CHECKSUMS.txt | Review cannot confirm package files | True blocker |
| T-012 | Local environment produces divergent output | Reproducibility | Python standard library only; documented assumptions | Different environments may still cause issues | Non-blocker if documented |
| T-013 | Natural language interpreted as formal guarantee | Communication risk | Overclaim table; correct-claim wording | Human readers may still infer too much | Accepted limitation |
| T-014 | Case bundle portability mistaken for trust | Portability/authenticity confusion | Limitations wording | Portable does not mean trusted | Accepted limitation |
| T-015 | No access control in local demo | Security feature absence | Non-goals | Unsuitable for multi-user production use | Non-blocker for local demo |
| T-016 | No incident response | Operational absence | Future roadmap mapping | Unsuitable for production incident handling | Non-blocker for local demo |
| T-017 | No privacy/redaction lifecycle | Data lifecycle absence | Future roadmap mapping | Sensitive data handling not production-ready | Non-blocker for local demo |
| T-018 | Reviewer uses stale package | Review process | Checksums and version labels | Stale copies can still circulate | Accepted limitation |

## 7. Current controls

The current controls are narrow and local:

| Control ID | Control | Helps with | Does not solve |
|---|---|---|---|
| C-001 | SHA256 checksums | Detecting changes relative to known digest | Origin, identity, or authority |
| C-002 | Verifier scripts | Checking expected package structure/content | External reality or full security |
| C-003 | Release gates | Preventing incomplete package freeze | Malicious reviewer behaviour |
| C-004 | Repair ledgers | Making repairs visible | Proving no other defects exist |
| C-005 | Master limitations document | Preventing hidden weaknesses | Preventing people from ignoring it |
| C-006 | Architecture diagrams | Explaining boundaries | Enforcing runtime controls |
| C-007 | One-command demo | Reducing operator friction | Production assurance |
| C-008 | Demo output bundle | Allowing inspection without rerun | Proving the world behind the evidence |

## 8. Residual risks

These risks remain after current controls:

- Real-world false evidence can still be submitted.
- Structured claims can still be false.
- Hashes can still be misunderstood as signatures.
- A whole folder can still be fabricated if the attacker controls the verification reference.
- A successful local demo can still be overclaimed.
- Documentation can still be quoted selectively.
- Reviewers may not understand the difference between deterministic verification and truth proof.
- The current stack lacks cryptographic identity, signing, anchoring, access control, roles, governance, production monitoring, and incident response.

## 9. Blocker classification

### 9.1 True blockers for Move 40 local demo pack freeze

The following are true blockers if found:

- known verifier false green
- missing checksum file
- stale checksum file
- missing release gate
- release gate without PASS/FAIL criteria
- documentation claiming Project Witness proves truth
- documentation claiming external reality verification
- documentation claiming source trust proof
- documentation claiming tamper-proof guarantees
- documentation claiming production readiness
- package cannot be verified
- package references missing frozen artifacts as if present
- threat model contradicts frozen demo behaviour
- Move 37, 38, 39, or 40 work included inside this package

### 9.2 Non-blockers for local demo release if honestly documented

These are current limitations but not blockers for a local demo:

- no GUI
- no Android app
- no Windows app
- no web UI
- no LLM reasoning
- no signing
- no external anchoring
- no production incident response
- no multi-case search
- no organisation governance
- no access control
- no role permissions
- no production monitoring
- one narrow demo path only

### 9.3 Blockers only if overclaimed or hidden

These become blockers if the documentation pretends they are solved:

- truth proof
- external reality verification
- source trust proof
- cryptographic identity
- tamper-proof guarantee
- production readiness
- full security assurance
- deception prevention
- natural-language understanding

## 10. Dangerous overclaims

| Overclaim | Why it is false or unsafe | Correct claim |
|---|---|---|
| Project Witness proves truth. | The stack preserves and checks structured provenance/hash relationships, not reality itself. | Project Witness helps preserve auditable evidence flow and exposes defined limits. |
| ODIN proves claims are true. | ODIN reasons over structured inputs and rules; false inputs can produce misleading outputs. | ODIN can produce deterministic reasoning traces from given claims and rule packs. |
| The demo proves production readiness. | One successful local demo path is not production assurance. | The demo proves this frozen local path can complete and verify under tested conditions. |
| Hashes prove authenticity. | Unkeyed hashes prove content matching relative to a digest, not origin or authority. | Hashes detect content changes relative to a known digest. |
| The system prevents all deception. | The system cannot stop false evidence, dishonest framing, or full-folder fabrication. | It makes specific provenance and verification failures more visible. |
| The threat model proves the system is secure. | A threat model is analysis, not a security guarantee. | The threat model identifies known risks and current controls. |
| Documentation creates runtime protection. | Documentation explains boundaries; it does not enforce them. | Runtime protection requires implemented controls in scoped future work. |

## 11. Future roadmap mapping

This threat model identifies future work but does not build it.

| Current limitation or threat | Future roadmap area |
|---|---|
| deeper threat analysis and adversary prompts | Move 38 Hostile Review Prompt Pack |
| independent reviewer packaging | Move 37 External Review Pack |
| review-response traceability | Move 39 Response-to-Review Ledger |
| local demo final public freeze | Move 40 Local Demo Pack Freeze |
| stronger verifier spine | Part Two, Step 71+ Rust verification spine |
| multi-actor approval and attribution | Part Three Multi-Actor Case Bundles and Approval Chains |
| incident response workflows | Part Four Incident Response Mode |
| organisation roles and governance | Part Four Organisation Roles and Permissions / Governance Packs |
| long-term case store and search | Part Five Long-Term Case Store and Search |
| privacy, redaction, data lifecycle | Part Five Data Lifecycle and Redaction |
| upgrade and backward compatibility assurance | Part Five Upgrade/Release and Backward Compatibility |

## 12. Explicit non-goals

For Move 36, the following are non-goals:

- no runtime code changes
- no new workflow
- no new action type
- no new Atlas term
- no signing implementation
- no anchoring implementation
- no identity system
- no access control implementation
- no production security hardening
- no GUI
- no Android app
- no Windows app
- no web UI
- no LLM integration
- no hostile review prompt pack
- no response-to-review ledger
- no external review pack
- no local demo pack freeze

## 13. Reviewer guidance

Reviewers should ask:

1. Does the package clearly say what it cannot prove?
2. Does it distinguish integrity checks from authenticity checks?
3. Does it distinguish deterministic reasoning from real-world truth?
4. Does it identify whole-folder fabrication risk?
5. Does it avoid production-readiness claims?
6. Does it keep future roadmap items marked as future work?
7. Does the verifier check the documentation package itself?
8. Does the release gate fail on overclaiming?
9. Are residual risks visible rather than hidden?
10. Are repairs recorded rather than erased?

## 14. What this threat model does not cover

This document does not provide:

- a full formal security proof
- a complete STRIDE assessment for production deployment
- a cryptographic protocol analysis
- a privacy impact assessment
- a legal compliance review
- a red-team prompt pack
- a vulnerability disclosure process
- an incident response plan
- an access-control model
- a network threat model
- cloud deployment guidance

Those are future or separate work.

## 15. Final truth-boundary statement

Project Witness currently helps make a narrow local evidence/provenance workflow more inspectable and harder to silently misrepresent.

It does not prove truth.

It does not verify external reality.

It does not prove source trust.

It does not provide production security assurance.

The honest claim is narrower and stronger: the project makes specific claims, artifacts, hashes, statuses, repairs, and limits reviewable.
