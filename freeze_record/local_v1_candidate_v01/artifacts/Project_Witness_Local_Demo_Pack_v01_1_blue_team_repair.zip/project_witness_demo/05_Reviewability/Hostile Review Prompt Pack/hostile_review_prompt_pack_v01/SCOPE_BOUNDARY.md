# Scope Boundary

## Current move

This package is **Move 38 — Hostile Review Prompt Pack v0.1**.

It may create prompt and documentation files only.

## Allowed

Allowed content:

- hostile review prompts
- prompt index
- reviewer protocol
- finding output format
- scope boundary
- release gate
- verification notes
- test results
- repair ledger
- checksums
- a deterministic verifier for this documentation package

## Not allowed

This move must not create:

- Response-to-Review Ledger
- Local Demo Pack freeze
- external review results
- production audit report
- runtime code
- new workflow
- new action type
- new Atlas terms
- new Sentinel behaviour
- new ODIN behaviour
- new Histor-lite behaviour
- new Coordinator behaviour
- new Companion behaviour
- GUI
- Android app
- Windows app
- web UI
- LLM integration
- signing
- anchoring
- queues
- concurrency
- organisation governance

## Future moves

```text
Move 39 — Response-to-Review Ledger
Move 40 — Freeze Project Witness Local Demo Pack
```

Move 38 may reference those future moves, but must not build them.

## Documentation authority limit

This package cannot make runtime claims true.

It can only supply prompts that help reviewers test claims, artifacts, scope, wording, and evidence.
