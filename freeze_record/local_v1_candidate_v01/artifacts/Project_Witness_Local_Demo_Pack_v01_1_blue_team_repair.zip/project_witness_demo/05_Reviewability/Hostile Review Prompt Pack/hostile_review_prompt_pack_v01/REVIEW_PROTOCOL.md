# Review Protocol

## Purpose

The hostile review protocol makes review harder to game.

The reviewer must attack claims, boundaries, evidence, and wording without inventing facts.

## Minimum review pass

A minimum hostile review pass should run these prompts:

```text
HRP-001 Truth Boundary Attack
HRP-002 False Green / Fake Pass Attack
HRP-003 Frozen Artifact Boundary Attack
HRP-004 Hash and Bundle Fabrication Attack
HRP-007 Reviewability Attack
HRP-009 Severity Calibration Attack
HRP-012 Scope Creep Attack
```

## Evidence rule

A finding must identify one of:

```text
Exact artifact evidence
Missing evidence
Ambiguous wording
Cannot determine from supplied material
Out of scope for this move
```

The reviewer must not turn missing evidence into an invented fact.

## Severity model

| Severity | Meaning |
|---|---|
| BLOCKER | Must be fixed before freeze or release of the relevant package |
| MAJOR | Serious weakness; may not block current move if honestly documented |
| MINOR | Small wording, structure, or clarity issue |
| NOTE | Useful observation that does not require immediate repair |

## Freeze rule

A package should not freeze if:

- the verifier is false-green
- the package cannot be verified from its own instructions
- the release gate is missing or vague
- the package claims runtime authority it does not have
- the package claims truth proof, external reality verification, source trust proof, production readiness, signing, or anchoring without evidence
- the package includes future-move artifacts early
- frozen artifacts were modified without an explicit repair move

## Response handling

Do not solve findings inside this package.

Move 39 is the Response-to-Review Ledger.  
This Move 38 package only creates prompts and review instructions.
