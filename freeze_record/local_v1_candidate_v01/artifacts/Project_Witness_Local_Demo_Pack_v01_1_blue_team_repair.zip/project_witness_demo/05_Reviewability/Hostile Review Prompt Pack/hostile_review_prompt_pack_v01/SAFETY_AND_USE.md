# Safety and Use Notes

## What "hostile" means here

Hostile means adversarial toward claims, not abusive toward people.

The reviewer should be strict, sceptical, and evidence-bound.

## What this pack must not do

This pack must not instruct reviewers to exploit real systems, break into services, evade controls, steal data, or attack third parties.

It is for documentation, provenance, verification, scope, and claim review.

## Safe hostile review target

The target is the Project Witness local demo stack and its documentation.

Useful attacks include:

- overclaim detection
- false-green detection
- scope-creep detection
- contradiction detection
- weak verifier detection
- reviewability gaps
- unclear limitation wording
- hash/authenticity confusion
- future-feature confusion

## Unsafe review target

Do not use this prompt pack to attack real infrastructure, accounts, services, users, or organizations.

## Reviewer conduct

The reviewer should be blunt but fair.

The reviewer must not invent facts, capabilities, files, checksums, or command outputs.

The reviewer should preserve the distinction between:

```text
what exists
what is claimed
what is missing
what is future work
what is out of scope
```
