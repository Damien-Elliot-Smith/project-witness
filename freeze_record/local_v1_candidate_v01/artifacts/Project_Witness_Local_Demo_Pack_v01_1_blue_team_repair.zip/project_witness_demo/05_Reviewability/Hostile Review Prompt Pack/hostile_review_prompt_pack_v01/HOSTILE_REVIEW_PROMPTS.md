# Hostile Review Prompts

Each prompt is copy-pasteable. Use one prompt per review pass.

## HRP-001 — Truth Boundary Attack

```text
You are a hostile but fair reviewer of Project Witness.

Your task is to find every place where the reviewed material could be read as claiming that Project Witness proves truth, verifies external reality, proves source trust, proves authenticity beyond hash matching, prevents deception, or proves production readiness.

Do not praise the work.

For each issue, report:

1. Exact wording or artifact location.
2. Why the wording is unsafe or false.
3. The correct weaker claim.
4. Severity: BLOCKER / MAJOR / MINOR / NOTE.
5. Whether this blocks local demo pack freeze.

If there is no evidence for a capability, say "No evidence supplied" rather than assuming it exists.

Do not propose new features. Only propose wording or documentation corrections.
```

## HRP-002 — False Green / Fake Pass Attack

```text
You are a hostile but fair reviewer.

Review the artifacts for signs of fake green, weak green, circular verification, self-certification, missing failure cases, or status labels that sound stronger than the evidence supports.

Focus on:

- verifier output
- release gates
- test results
- checksums
- claimed statuses
- repair ledgers
- demo completion wording
- "verified" language

For each issue, identify whether the project has evidence, partial evidence, or no evidence.

Do not treat a successful demo path as full assurance.

Do not treat a checksum as proof of origin.

Return findings using severity BLOCKER / MAJOR / MINOR / NOTE.
```

## HRP-003 — Frozen Artifact Boundary Attack

```text
You are a hostile but fair reviewer.

Check whether the current move modifies, redefines, weakens, bypasses, or silently depends on frozen artifacts.

Look specifically for:

- edits to frozen folders
- claims that a documentation move changes runtime behaviour
- references to missing frozen artifacts
- compatibility repairs that are not named as repairs
- new features smuggled into a documentation package
- Move 39 or Move 40 work appearing early

If a frozen component is only referenced, distinguish that from modification.

Report blockers separately from non-blocking documentation issues.
```

## HRP-004 — Hash and Bundle Fabrication Attack

```text
You are a hostile but fair reviewer.

Assess whether the artifact review process could be fooled by copied folders, fabricated bundles, stale outputs, recomputed unkeyed hashes, or checksums with no trusted origin.

Do not claim the system is broken merely because these are possible. Instead classify each as:

- current hard limitation
- acceptable limitation if documented
- blocker if hidden or overclaimed
- blocker for local demo freeze

Check whether the artifact correctly says that unkeyed hashes prove matching content only, not identity, origin, source trust, or external anchoring.

Return specific corrections.
```

## HRP-005 — Beginner Misunderstanding Attack

```text
You are a hostile but fair reviewer.

Read the material as a beginner who is honest but inexperienced.

Find wording, steps, diagrams, status names, or checklists that could make a beginner think the system does more than it does.

Focus on:

- "truth"
- "verified"
- "trusted"
- "proof"
- "audit"
- "complete"
- "secure"
- "production"
- "tamper-proof"

For each issue, explain the likely misunderstanding and provide a safer replacement sentence.

Do not simplify by removing important limits.
```

## HRP-006 — Threat Model Gap Attack

```text
You are a hostile but fair reviewer.

Compare the threat model claims against the limitations and review pack.

Find missing attacker classes, missing assets, missing trust boundaries, missing mitigations, and mitigations that sound stronger than they are.

Do not demand production security features from the local demo, but do mark any hidden production-safety assumption as a blocker.

Separate:

- must fix before local demo freeze
- acceptable if documented
- future roadmap item
- out of scope for Part One
```

## HRP-007 — Reviewability Attack

```text
You are a hostile but fair reviewer.

Review whether an external reviewer can inspect the project without trusting the author.

Look for:

- missing start point
- missing artifact manifest
- unclear verification commands
- unclear expected outputs
- missing checksums
- missing failure interpretation
- unclear distinction between run output and documentation
- missing scope boundary

Return the smallest set of changes needed to make review possible.
```

## HRP-008 — Documentation Contradiction Attack

```text
You are a hostile but fair reviewer.

Find contradictions between the runbook, demo output bundle, architecture diagram, known limitations document, threat model, and external review pack.

Look for inconsistent wording around:

- truth proof
- external reality
- source trust
- signing
- anchoring
- production readiness
- GUI/app/web UI
- LLM reasoning
- frozen artifact status
- what has and has not been built

Every contradiction must include the two conflicting statements or artifact locations.

If you cannot inspect an artifact, say that instead of guessing.
```

## HRP-009 — Severity Calibration Attack

```text
You are a hostile but fair reviewer.

Check whether the project is classifying issues honestly.

Find cases where:

- a blocker is treated as minor
- a limitation is hidden as a future enhancement
- a future feature is implied to exist now
- an overclaim is treated as marketing language
- a missing artifact is treated as acceptable
- a failed verifier would still allow freeze

Return a corrected severity classification table.
```

## HRP-010 — Local Demo Freeze Readiness Attack

```text
You are a hostile but fair reviewer.

Assess whether the current artifacts are ready to support Move 40: Project Witness Local Demo Pack freeze.

Do not freeze anything.

Do not build the local demo pack.

Only answer:

1. What would block Move 40?
2. What is acceptable for Move 40 if documented?
3. What wording must be weakened before Move 40?
4. What verifier/release-gate evidence is missing?
5. What should be deferred to Part Two or later?

Use BLOCKER / MAJOR / MINOR / NOTE.
```

## HRP-011 — LLM Reviewer Reliability Attack

```text
You are a hostile but fair reviewer.

Assume an LLM reviewer may hallucinate, overpraise, miss files, or invent capabilities.

Review this prompt pack and identify where the prompt instructions reduce or fail to reduce that risk.

Check for instructions requiring:

- exact evidence
- no invented artifacts
- no assumed command results
- no assumed external anchoring
- no assumed signing
- no assumed production readiness
- clear "cannot determine" outcomes
- separation of confirmed findings from possible issues

Return improvements to the prompts only. Do not create the Response-to-Review Ledger.
```

## HRP-012 — Scope Creep Attack

```text
You are a hostile but fair reviewer.

Find any feature, claim, workflow, integration, governance mechanism, app, UI, signing mechanism, anchoring mechanism, queue, concurrency model, or new action type that appears in the current move but is outside its roadmap scope.

Classify each finding as:

- definite scope creep
- ambiguous wording
- harmless future reference
- not an issue

For definite scope creep, provide the smallest removal or wording correction.
```
