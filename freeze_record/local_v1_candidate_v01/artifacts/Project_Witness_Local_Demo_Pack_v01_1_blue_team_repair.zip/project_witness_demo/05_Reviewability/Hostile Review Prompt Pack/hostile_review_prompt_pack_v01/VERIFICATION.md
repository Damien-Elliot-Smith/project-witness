# Verification

## Verifier

Run from inside the package root:

```bash
python tools/verify_hostile_review_prompt_pack.py
```

Expected output:

```text
HOSTILE_REVIEW_PROMPT_PACK_VERIFIED
verify_ok = true
```

## What the verifier checks

The verifier checks:

- required files exist
- required headings and phrases exist
- at least twelve hostile review prompts exist
- prompt IDs HRP-001 through HRP-012 exist
- scope boundary says Move 39 is not built
- scope boundary says Move 40 is not built
- dangerous overclaim checks are present
- reviewer uncertainty wording is present
- release gate has PASS and FAIL criteria
- no forbidden runtime directories exist
- only `tools/verify_hostile_review_prompt_pack.py` exists under tools
- CHECKSUMS.txt exists
- TEST_RESULTS.md exists
- REPAIR_LEDGER.md exists

## Verification limits

The verifier proves only that this package has the required structure and wording.

It does not prove that future reviewers will be correct.

It does not prove truth.

It does not verify external reality.

It does not prove source trust.

It does not prove production readiness.

It does not sign or externally anchor this package.
