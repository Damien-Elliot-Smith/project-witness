#!/usr/bin/env python3
from pathlib import Path
import sys
import re

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "HOSTILE_REVIEW_PROMPT_PACK.md",
    "HOSTILE_REVIEW_PROMPTS.md",
    "PROMPT_INDEX.md",
    "REVIEW_PROTOCOL.md",
    "FINDING_OUTPUT_FORMAT.md",
    "SCOPE_BOUNDARY.md",
    "SAFETY_AND_USE.md",
    "RELEASE_GATE.md",
    "VERIFICATION.md",
    "TEST_RESULTS.md",
    "REPAIR_LEDGER.md",
    "CHECKSUMS.txt",
    "tools/verify_hostile_review_prompt_pack.py",
]

REQUIRED_PHRASES = {
    "README.md": [
        "Move 38",
        "Hostile Review Prompt Pack",
        "Move 39 will build the Response-to-Review Ledger",
        "HOSTILE_REVIEW_PROMPT_PACK_VERIFIED",
    ],
    "HOSTILE_REVIEW_PROMPT_PACK.md": [
        "Project Witness must not claim to prove truth",
        "hostile but fair external reviewer",
        "Do not invent missing evidence",
        "Non-negotiable overclaim checks",
    ],
    "HOSTILE_REVIEW_PROMPTS.md": [
        "HRP-001",
        "HRP-012",
        "Truth Boundary Attack",
        "False Green / Fake Pass Attack",
        "Scope Creep Attack",
        "Do not freeze anything",
    ],
    "PROMPT_INDEX.md": [
        "HRP-001",
        "HRP-012",
        "Move 40",
    ],
    "REVIEW_PROTOCOL.md": [
        "Minimum review pass",
        "Evidence rule",
        "Severity model",
        "Move 39 is the Response-to-Review Ledger",
    ],
    "FINDING_OUTPUT_FORMAT.md": [
        "Cannot determine from supplied material",
        "No evidence supplied",
        "Out of scope for this move",
    ],
    "SCOPE_BOUNDARY.md": [
        "Move 38",
        "Response-to-Review Ledger",
        "Local Demo Pack freeze",
        "must not build them",
    ],
    "SAFETY_AND_USE.md": [
        "Hostile means adversarial toward claims",
        "must not instruct reviewers to exploit real systems",
        "must not invent facts",
    ],
    "RELEASE_GATE.md": [
        "PASS criteria",
        "FAIL criteria",
        "Move 39 is not built",
        "Move 40 is not built",
    ],
    "VERIFICATION.md": [
        "What the verifier checks",
        "It does not prove truth",
        "It does not sign or externally anchor this package",
    ],
    "TEST_RESULTS.md": [
        "HOSTILE_REVIEW_PROMPT_PACK_VERIFIED",
        "verify_ok = true",
        "ResourceWarning sweep",
        "Runtime code tests",
    ],
    "REPAIR_LEDGER.md": [
        "Repair Ledger",
        "No open repairs",
    ],
}

FORBIDDEN_DIRS = [
    "ConnectedDemo_FREEZES",
    "BeginnerRunbook_FREEZES",
    "OneCommandDemoScript_FREEZES",
    "DemoOutputBundle_FREEZES",
    "ArchitectureDiagram_FREEZES",
    "Coordinator_FREEZES",
    "Companion_FREEZES",
    "StackSelfcheck_FREEZES",
    "src",
    "app",
    "web",
    "android",
    "windows",
    "runtime",
]

def fail(message: str) -> None:
    print(f"VERIFY_FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

def read(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        fail(f"missing required file: {rel}")
    return path.read_text(encoding="utf-8")

def main() -> None:
    if not ROOT.exists():
        fail("package root missing")

    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            fail(f"missing required file: {rel}")

    for rel, phrases in REQUIRED_PHRASES.items():
        text = read(rel)
        for phrase in phrases:
            if phrase not in text:
                fail(f"{rel} missing required phrase: {phrase}")

    prompts = read("HOSTILE_REVIEW_PROMPTS.md")
    for i in range(1, 13):
        pid = f"HRP-{i:03d}"
        if pid not in prompts:
            fail(f"missing prompt id: {pid}")

    prompt_count = len(re.findall(r"^## HRP-\d{3}", prompts, flags=re.MULTILINE))
    if prompt_count < 12:
        fail(f"expected at least 12 hostile review prompts, found {prompt_count}")

    pack = read("HOSTILE_REVIEW_PROMPT_PACK.md")
    required_overclaims = [
        "Project Witness proves truth.",
        "Project Witness verifies external reality.",
        "Project Witness proves source trust.",
        "Project Witness proves authenticity beyond hash matching.",
        "Project Witness is tamper-proof.",
        "Project Witness is production-ready.",
        "Project Witness prevents all deception.",
        "Project Witness provides cryptographic identity.",
        "Project Witness has signing or external anchoring.",
        "Project Witness performs LLM reasoning.",
    ]
    for claim in required_overclaims:
        if claim not in pack:
            fail(f"missing overclaim check: {claim}")

    scope = read("SCOPE_BOUNDARY.md")
    if "Move 38 may reference those future moves, but must not build them." not in scope:
        fail("future move boundary wording missing")

    # No forbidden runtime/project dirs.
    for name in FORBIDDEN_DIRS:
        if (ROOT / name).exists():
            fail(f"forbidden directory present: {name}")

    # tools directory must contain only the verifier.
    tools = ROOT / "tools"
    tool_files = [p.relative_to(ROOT).as_posix() for p in tools.rglob("*") if p.is_file()]
    if tool_files != ["tools/verify_hostile_review_prompt_pack.py"]:
        fail(f"unexpected tools contents: {tool_files}")

    # CHECKSUMS should include every non-CHECKSUMS file.
    checksums = read("CHECKSUMS.txt")
    expected_files = []
    for p in ROOT.rglob("*"):
        if p.is_file():
            rel = p.relative_to(ROOT).as_posix()
            if rel != "CHECKSUMS.txt":
                expected_files.append(rel)
    for rel in sorted(expected_files):
        if rel not in checksums:
            fail(f"CHECKSUMS.txt missing entry for {rel}")

    print("HOSTILE_REVIEW_PROMPT_PACK_VERIFIED")
    print("verify_ok = true")

if __name__ == "__main__":
    main()
