# Prompt Index

| ID | Prompt | Primary target | Expected output | Blocks freeze if serious? |
|---|---|---|---|---|
| HRP-001 | Truth Boundary Attack | overclaims about truth/reality/trust | unsafe wording findings | yes |
| HRP-002 | False Green / Fake Pass Attack | status and verification claims | fake-green findings | yes |
| HRP-003 | Frozen Artifact Boundary Attack | frozen scope discipline | boundary findings | yes |
| HRP-004 | Hash and Bundle Fabrication Attack | hash/authenticity limits | limitation classification | yes if hidden |
| HRP-005 | Beginner Misunderstanding Attack | usability wording | safer wording fixes | sometimes |
| HRP-006 | Threat Model Gap Attack | Move 36 threat model | threat-model gaps | sometimes |
| HRP-007 | Reviewability Attack | external review readiness | review blockers | yes |
| HRP-008 | Documentation Contradiction Attack | cross-document consistency | contradiction list | yes if material |
| HRP-009 | Severity Calibration Attack | blocker classification | corrected severity table | yes |
| HRP-010 | Local Demo Freeze Readiness Attack | Move 40 preparation only | freeze readiness findings | yes |
| HRP-011 | LLM Reviewer Reliability Attack | prompt safety and reliability | prompt improvements | sometimes |
| HRP-012 | Scope Creep Attack | roadmap boundary | scope creep findings | yes |

## Prompt selection guidance

Use at least HRP-001, HRP-002, HRP-003, HRP-004, HRP-007, HRP-009, and HRP-012 before considering the local demo pack ready for Move 40.

HRP-010 may be used to prepare for Move 40, but it must not freeze Move 40.

HRP-011 is specifically for checking whether an LLM-based hostile review is likely to hallucinate or overpraise.
