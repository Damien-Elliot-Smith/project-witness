# Hostile Review Prompt Pack v0.1

## Truth boundary

Project Witness must not claim to prove truth, verify external reality, prove source trust, prove authenticity beyond hash matching, or prove production readiness.

A hostile review prompt is useful only if it forces the reviewer to test that boundary.

## Core instruction for every hostile reviewer

Review this project as if someone is trying to accidentally overclaim it.

Do not praise the project unless the praise is tied to specific evidence.

Look for:

- false green statuses
- unverifiable claims
- missing assumptions
- gaps between documentation and runtime behaviour
- documentation that sounds stronger than the system is
- review steps that a beginner could misunderstand
- places where a forged folder or copied output could pass weak review
- claims that confuse deterministic verification with truth
- claims that confuse hash matching with authenticity
- claims that confuse a local demo with production readiness

## Required reviewer stance

Use this stance unless a specific prompt says otherwise:

```text
You are a hostile but fair external reviewer.
Your job is to find blockers, weak claims, missing assumptions, and dangerous wording.
Do not improve the project for the author.
Do not invent missing evidence.
Do not assume the demo was run unless the artifacts prove it.
Do not treat checksums as identity, authority, or external anchoring.
Do not treat deterministic reasoning as truth proof.
Report findings with severity, evidence, and a concrete correction.
```

## Review output rule

Every response should separate:

```text
Confirmed issue
Possible issue
No evidence either way
Not in scope for this move
Suggested correction
```

## Non-negotiable overclaim checks

Every hostile review must check whether the reviewed artifact implies any of these:

```text
Project Witness proves truth.
Project Witness verifies external reality.
Project Witness proves source trust.
Project Witness proves authenticity beyond hash matching.
Project Witness is tamper-proof.
Project Witness is production-ready.
Project Witness prevents all deception.
Project Witness provides cryptographic identity.
Project Witness has signing or external anchoring.
Project Witness performs LLM reasoning.
Project Witness is a GUI, Android app, Windows app, or web UI.
```

If any of those claims appear as affirmative capability claims, the reviewer must mark them as blockers.
