# Project Witness — Hostile Review Prompt Pack v0.1

## Move

This package is **Move 38 — Hostile Review Prompt Pack v0.1** of Project Witness Part One.

It belongs to:

```text
Phase 6 — Usability and Reviewability
31. Build Beginner Runbook
32. Build One-Command Demo Script
33. Build Demo Output Bundle
34. Build Architecture Diagram
35. Build Master Known Limitations Document
36. Build Threat Model v0.1
37. Build External Review Pack v0.1
38. Build Hostile Review Prompt Pack
39. Build Response-to-Review Ledger
40. Freeze Project Witness Local Demo Pack
```

## Purpose

This package gives reviewers reusable prompts for hostile review of the frozen local demo stack and its documentation.

The goal is not to make Project Witness look good.  
The goal is to find weak claims, hidden assumptions, false greens, unverifiable behaviour, reviewer confusion, and places where the project might accidentally overstate what it proves.

## What this package is

This is a documentation and prompt package.

It contains:

- copy-paste hostile review prompts
- a prompt index
- a review protocol
- a severity model
- a scope boundary
- a release gate
- a deterministic verifier
- checksums and test results

## What this package is not

This package is not:

- the Response-to-Review Ledger
- the Local Demo Pack freeze
- an external review result
- a production security audit
- a penetration-test toolkit
- runtime code
- a GUI
- an Android app
- a Windows app
- a web UI
- LLM integration
- signing
- anchoring
- a new workflow
- a new action type

## How to use

Give a reviewer or an LLM one prompt at a time from `HOSTILE_REVIEW_PROMPTS.md`.

The reviewer should produce findings using `FINDING_OUTPUT_FORMAT.md`.

Do not treat a prompt answer as proof. Treat it as a review input that may need confirmation.

Move 39 will build the Response-to-Review Ledger. This package must not include that ledger.

## How to verify

From inside the package root:

```bash
python tools/verify_hostile_review_prompt_pack.py
```

Expected result:

```text
HOSTILE_REVIEW_PROMPT_PACK_VERIFIED
verify_ok = true
```
