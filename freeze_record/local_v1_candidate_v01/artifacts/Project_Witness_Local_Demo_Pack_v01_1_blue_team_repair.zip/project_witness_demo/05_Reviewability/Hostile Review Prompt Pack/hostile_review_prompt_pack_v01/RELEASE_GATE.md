# Release Gate — Hostile Review Prompt Pack v0.1

## PASS criteria

The package may pass only if all criteria are satisfied.

| Gate | Criterion | Required status |
|---|---|---|
| RG-001 | All required files exist | PASS |
| RG-002 | Prompt pack contains hostile review prompts | PASS |
| RG-003 | Prompt index exists | PASS |
| RG-004 | Review protocol exists | PASS |
| RG-005 | Finding output format exists | PASS |
| RG-006 | Scope boundary exists | PASS |
| RG-007 | Safety and use notes exist | PASS |
| RG-008 | Package explicitly says Move 39 is not built | PASS |
| RG-009 | Package explicitly says Move 40 is not built | PASS |
| RG-010 | Package does not claim truth proof | PASS |
| RG-011 | Package does not claim external reality verification | PASS |
| RG-012 | Package does not claim source trust proof | PASS |
| RG-013 | Package does not claim production readiness | PASS |
| RG-014 | Package does not add runtime code outside tools verifier | PASS |
| RG-015 | Package does not add GUI, app, web UI, LLM integration, signing, or anchoring | PASS |
| RG-016 | Verifier passes | PASS |
| RG-017 | CHECKSUMS.txt exists | PASS |
| RG-018 | TEST_RESULTS.md records real verification result | PASS |
| RG-019 | REPAIR_LEDGER.md exists | PASS |

## FAIL criteria

The package fails if any of these are true:

- required files are missing
- prompts encourage invented evidence
- prompts treat checksums as identity or authority
- prompts treat deterministic reasoning as truth proof
- package contains response ledger entries
- package claims Move 40 is frozen
- package modifies frozen runtime artifacts
- package contains runtime project code outside `tools/verify_hostile_review_prompt_pack.py`
- verifier fails
- checksum file is missing
- test results are fabricated
