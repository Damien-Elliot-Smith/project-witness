# Finding Output Format

Reviewers should report findings in this structure.

```text
Finding ID:
Prompt used:
Severity: BLOCKER / MAJOR / MINOR / NOTE
Status: Confirmed issue / Possible issue / No evidence either way / Not in scope
Artifact:
Evidence:
Why it matters:
Corrected claim or suggested fix:
Blocks current move? yes/no
Blocks Move 40 local demo freeze? yes/no/unknown
Future roadmap area if applicable:
```

## Rules

- Do not invent artifact locations.
- Do not assume commands were run.
- Do not assume checksums are trusted origin.
- Do not assume signing or anchoring exists.
- Do not treat deterministic reasoning as truth proof.
- Do not treat a demo pass as production readiness.
- Do not treat documentation promises as runtime behaviour.

## Required wording for uncertainty

Use these phrases when appropriate:

```text
Cannot determine from supplied material.
No evidence supplied.
Out of scope for this move.
This is a future roadmap item, not a current capability.
This is acceptable only if documented as a limitation.
```
