# Scope Boundary — Move 40

## Current move

This package is **Move 40 — Freeze Project Witness Local Demo Pack**.

## Allowed

Move 40 may create:

- local demo pack wrapper
- manifest
- freeze record
- artifact ledger
- known-limits summary
- baseline inspection report
- release gate
- verification instructions
- test results
- repair ledger
- checksums
- deterministic verifier
- embedded frozen baseline archive

## Not allowed

Move 40 must not create:

- new runtime feature
- new workflow
- new action type
- new Atlas term
- new ODIN logic
- new Sentinel logic
- new Histor-lite logic
- new Coordinator logic
- new Companion logic
- GUI
- Android app
- Windows app
- web UI
- LLM integration
- signing
- external anchoring
- queues
- concurrency
- organisation governance
- production incident response
- Move 41 content

## Freeze rule

Move 40 freezes the local demo pack around the existing baseline.

It must not rewrite history.

It must not pretend review happened if it has not.

It must not hide known limitations.
