# Start Here — Project Witness Local Demo Pack v0.1

## First action

Run the verifier:

```bash
python tools/verify_local_demo_pack.py
```

Expected result:

```text
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

## What to inspect first

1. `FREEZE_RECORD.md`
2. `LOCAL_DEMO_PACK_MANIFEST.md`
3. `INCLUDED_ARTIFACTS.md`
4. `KNOWN_LIMITS_SUMMARY.md`
5. `BASELINE_INSPECTION_REPORT.md`
6. `RELEASE_GATE.md`
7. `TEST_RESULTS.md`

## Baseline archive

The frozen combined baseline is stored at:

```text
artifacts/frozen_working_projects_baseline.zip
```

This is the project material being frozen for the local demo pack.

## Important reading rule

Do not treat this pack as a truth engine, production certification, security certification, signing layer, or external anchoring system.

It is a local demo freeze and reviewability package.
