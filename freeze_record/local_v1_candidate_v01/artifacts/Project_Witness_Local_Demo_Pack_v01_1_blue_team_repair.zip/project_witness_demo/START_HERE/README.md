# Project Witness — Local Demo Pack v0.1

## Move

This package is **Move 40 — Freeze Project Witness Local Demo Pack**.

It freezes the local demo baseline through **Move 39**, built on the frozen foundation artifacts from **Moves 1–29** and the Move 30 repair chain.

## What is frozen here

This package freezes a verified combined baseline archive:

```text
artifacts/frozen_working_projects_baseline.zip
```

Original uploaded filename:

```text
Frozen working projects.zip
```

Baseline SHA256:

```text
0f1d56ac199a788168e24540c9f347010a3f01e8ea17732d4bdbc756040445bc
```


## Authoritative baseline

The authoritative frozen baseline is:

```text
START_HERE/artifacts/frozen_working_projects_baseline.zip
```

The organised folders outside `START_HERE/` are reviewer convenience copies of the same frozen materials. If there is any confusion, verify the authoritative baseline archive and its SHA256 first.

## What this package does

This package provides:

- a start-here guide
- a local demo pack manifest
- a freeze record
- an included-artifacts ledger for Moves 1–39
- a known-limits summary
- a baseline inspection report
- a release gate
- verification instructions
- test results
- a repair ledger
- checksums
- a deterministic verifier

## What this package does not do

This package does not add new Project Witness behaviour.

It does not modify frozen artifacts.

It does not rebuild the stack.

It does not create Move 41.

It does not add GUI, Android app, Windows app, web UI, LLM integration, signing, external anchoring, queues, concurrency, new workflows, new action types, or new governance features.

## How to verify

From inside the package root:

```bash
python tools/verify_local_demo_pack.py
```

Expected output:

```text
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

## Honest meaning of this freeze

This freeze means:

```text
The local demo baseline through Move 39 is packaged, accounted for, checksumed, and reviewable.
```

It does **not** mean:

```text
Project Witness proves truth.
Project Witness verifies external reality.
Project Witness proves source trust.
Project Witness is production-ready.
Project Witness is tamper-proof.
```

## Move 30–39 layer

Moves 30–39 are the connected demo, usability, reviewability, hostile review, and response-ledger layer that sits on top of Moves 1–29.
