# Release Gate — Project Witness Local Demo Pack v0.1

## PASS criteria

| Gate | Criterion | Required status |
|---|---|---|
| RG-001 | Required Move 40 files exist | PASS |
| RG-002 | Baseline archive exists in artifacts/ | PASS |
| RG-003 | Baseline SHA256 matches PACK_INFO.json | PASS |
| RG-004 | Baseline zip integrity passes | PASS |
| RG-005 | Baseline has no duplicate zip entries | PASS |
| RG-006 | Nested .sha256 checks pass | PASS |
| RG-007 | Moves 1–29 foundation artifacts are accounted for | PASS |
| RG-008 | Move 30 connected demo is accounted for | PASS |
| RG-009 | Move 30 repair artifacts are accounted for | PASS |
| RG-010 | Moves 31–39 artifacts are accounted for | PASS |
| RG-011 | Moves 35–39 package verifiers pass | PASS |
| RG-012 | Known limits summary exists | PASS |
| RG-013 | Freeze record exists | PASS |
| RG-014 | Scope boundary exists | PASS |
| RG-015 | Package does not claim truth proof | PASS |
| RG-016 | Package does not claim external reality verification | PASS |
| RG-017 | Package does not claim source trust proof | PASS |
| RG-018 | Package does not claim production readiness | PASS |
| RG-019 | Package does not add runtime code outside tools verifier | PASS |
| RG-020 | Package does not add GUI, app, web UI, LLM integration, signing, or anchoring | PASS |
| RG-021 | CHECKSUMS.txt exists | PASS |
| RG-022 | TEST_RESULTS.md records real verification result | PASS |
| RG-023 | REPAIR_LEDGER.md exists | PASS |

## FAIL criteria

The package fails if any of these are true:

- baseline archive is missing
- baseline SHA256 does not match PACK_INFO.json
- baseline zip integrity fails
- nested checksums fail
- required foundation artifacts are missing
- required demo/reviewability artifacts are missing
- Move 35–39 verifiers fail
- package claims truth proof
- package claims external reality verification
- package claims source trust proof
- package claims production readiness
- package adds runtime project code outside the verifier
- package adds Move 41 content
- test results are fabricated
