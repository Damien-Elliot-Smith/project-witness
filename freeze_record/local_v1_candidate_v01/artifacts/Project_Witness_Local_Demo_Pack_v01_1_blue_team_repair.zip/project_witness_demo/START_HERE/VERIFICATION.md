# Verification

## Verifier

Run from inside the package root:

```bash
python tools/verify_local_demo_pack.py
```

Expected output:

```text
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

## What the verifier checks

The verifier checks:

- required Move 40 files exist
- `artifacts/frozen_working_projects_baseline.zip` exists
- baseline SHA256 matches `PACK_INFO.json`
- baseline zip integrity passes
- no duplicate zip entries exist
- nested `.sha256` files inside the baseline match their target zip files
- Moves 1–29 foundation artifacts are accounted for
- Move 30 connected demo and repair chain are accounted for
- Moves 31–39 artifacts are accounted for
- Move 35 verifier passes after baseline extraction
- Move 36 verifier passes after baseline extraction
- Move 37 verifier passes after baseline extraction
- Move 38 verifier passes after baseline extraction
- Move 39 verifier passes after baseline extraction
- no forbidden runtime directories are added outside `artifacts/` and `tools/`
- `CHECKSUMS.txt` includes every package file except itself

## Verification limits

The verifier does not prove truth.

The verifier does not verify external reality.

The verifier does not prove source trust.

The verifier does not prove origin or authenticity beyond hash matching.

The verifier does not prove production readiness.

The verifier does not sign or externally anchor the package.

## CHECKSUMS.txt integrity (Move 42 / RT-003 repair)

The wrapper checksum check now recomputes and compares hashes; it no longer only
confirms that a path string is present. For every line in `CHECKSUMS.txt` in the
form `<sha256>  <relative/path>`, the verifier:

- confirms the listed file exists,
- recomputes its SHA-256 and compares it to the listed digest,
- fails on any missing file or any digest mismatch, and
- fails if an extra unlisted file is present in the wrapper package.

Documented exclusions from the unlisted-file check are `CHECKSUMS.txt` itself,
`__pycache__` entries, and dotfiles. The embedded baseline archive is still
verified separately by its recorded SHA-256, zip integrity, and nested checksums.
