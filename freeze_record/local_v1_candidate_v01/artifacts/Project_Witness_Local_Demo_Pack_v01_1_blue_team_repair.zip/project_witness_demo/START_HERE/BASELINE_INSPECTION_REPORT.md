# Baseline Inspection Report

## Baseline

```text
File: artifacts/frozen_working_projects_baseline.zip
Original uploaded filename: Frozen working projects.zip
SHA256: 0f1d56ac199a788168e24540c9f347010a3f01e8ea17732d4bdbc756040445bc
Size bytes: 6311187
```

## Zip integrity

```text
Zip test result: PASS
Duplicate entries: 0
Total entries: 253
Nested zip artifacts: 36
Nested .sha256 files: 33
Nested checksum matches: 33 / 33
```

## Move 35–39 verifier policy

The Move 40 verifier extracts the baseline archive and runs these package verifiers when present:

```text
master_known_limitations_v01/tools/verify_master_known_limitations.py
threat_model_v01/tools/verify_threat_model.py
external_review_pack_v01/tools/verify_external_review_pack.py
hostile_review_prompt_pack_v01/tools/verify_hostile_review_prompt_pack.py
response_to_review_ledger_v01/tools/verify_response_to_review_ledger.py
```

## Nested checksum policy

The verifier checks every `.sha256` file inside the baseline archive that points to a zip artifact in the same folder.

A PASS means the nested zip bytes match the digest recorded beside them.

A PASS does not prove origin, identity, trust, signing, or external anchoring.
