# Test Results — Project Witness Local Demo Pack v0.1

## Verification command

```bash
python tools/verify_local_demo_pack.py
```

## Final verifier result

```text
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

## ResourceWarning sweep

Command:

```bash
python -W error::ResourceWarning tools/verify_local_demo_pack.py
```

Result:

```text
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

## Runtime code tests

Not applicable for the Move 40 wrapper package.

Move 40 does not add Project Witness runtime code.

The verifier does inspect the embedded baseline and rerun the documentation package verifiers for Moves 35–39.

## Scope boundary result

PASS.

The package accounts for Moves 1–39 and creates a Move 40 freeze wrapper.

It does not create Move 41.

It does not add runtime features.

It does not modify frozen artifacts.

## Release gate result

PASS.

## Narrow cleanup repair verification

A final documentation cleanup corrected the roadmap wording and clarified that the authoritative frozen baseline is `START_HERE/artifacts/frozen_working_projects_baseline.zip`; organised folders are reviewer convenience copies.

Result: PASS.

No runtime artifacts were modified.

## Move 42 RT-003 repair re-test

The wrapper verifier now recomputes and compares each `CHECKSUMS.txt` hash.

Positive run:

```text
python tools/verify_local_demo_pack.py
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

ResourceWarning sweep:

```text
python -W error::ResourceWarning tools/verify_local_demo_pack.py
LOCAL_DEMO_PACK_VERIFIED
verify_ok = true
```

Negative test (performed in a throwaway copy, not shipped): modifying one wrapper
file (`README.md`) makes the verifier fail with a `CHECKSUMS.txt hash mismatch`,
proving RT-003 is repaired. The corrupted copy was discarded and is not part of
this package.

No frozen baseline artifact and no Moves 1–39 frozen component were modified.
