#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "README.md",
    "START_HERE.md",
    "LOCAL_DEMO_PACK_MANIFEST.md",
    "FREEZE_RECORD.md",
    "INCLUDED_ARTIFACTS.md",
    "KNOWN_LIMITS_SUMMARY.md",
    "BASELINE_INSPECTION_REPORT.md",
    "SCOPE_BOUNDARY.md",
    "RELEASE_GATE.md",
    "VERIFICATION.md",
    "TEST_RESULTS.md",
    "REPAIR_LEDGER.md",
    "PACK_INFO.json",
    "CHECKSUMS.txt",
    "artifacts/frozen_working_projects_baseline.zip",
    "tools/verify_local_demo_pack.py",
]

EXPECTED_MARKERS = {
    "foundation": [
        [
            "Moves 1-3",
            "Sentinel Core v0.2.2",
            "sentinel_core_v022.zip"
        ],
        [
            "Moves 1-3",
            "Sentinel Red/Blue Pack v0.1",
            "sentinel_red_blue_pack_v01.zip"
        ],
        [
            "Move 4",
            "Histor-lite v0.1.2",
            "histor_lite_v012.zip"
        ],
        [
            "Move 5",
            "Case Bundle v0.1.1",
            "case_bundle_v011.zip"
        ],
        [
            "Move 6",
            "Coordinator Workflow v0.1.8",
            "coordinator_workflow_v018.zip"
        ],
        [
            "Move 7",
            "Companion CLI v0.1",
            "companion_cli_v01.zip"
        ],
        [
            "Move 8",
            "Workflow Red/Blue Pack v0.1",
            "project_witness_workflow_red_blue_pack_v01.zip"
        ],
        [
            "Move 9",
            "Aletheia Evidence Bundle v0.1",
            "aletheia_evidence_bundle_v01.zip"
        ],
        [
            "Move 10",
            "ODIN Claim Reasoner v0.1",
            "odin_claim_reasoner_v01.zip"
        ],
        [
            "Moves 11-12",
            "ODIN Red/Blue Pack v0.1",
            "odin_red_blue_pack_v01.zip"
        ],
        [
            "Move 13",
            "Aletheia to ODIN Bridge v0.1",
            "aletheia_odin_bridge_v01.zip"
        ],
        [
            "Moves 14-15",
            "Evidence Reasoning Demo v0.1",
            "evidence_reasoning_demo_v01.zip"
        ],
        [
            "Move 16",
            "Histor-lite Aletheia Importer v0.1",
            "histor_lite_aletheia_importer_v01.zip"
        ],
        [
            "Move 17",
            "Histor-lite ODIN Importer v0.1",
            "histor_lite_odin_importer_v01.zip"
        ],
        [
            "Move 18",
            "Case Bundle v0.2",
            "case_bundle_v02.zip"
        ],
        [
            "Move 19",
            "Coordinator Workflow v0.2",
            "coordinator_workflow_v02.zip"
        ],
        [
            "Move 20",
            "Companion CLI v0.2",
            "companion_cli_v02.zip"
        ],
        [
            "Move 21",
            "Atlas Registry v0.1",
            "atlas_registry_v01.zip"
        ],
        [
            "Move 22",
            "Atlas Release Gate v0.1",
            "atlas_release_gate_v01.zip"
        ],
        [
            "Move 23",
            "Atlas Red/Blue Pack v0.1",
            "atlas_red_blue_pack_v01.zip"
        ],
        [
            "Move 24",
            "Coordinator Workflow v0.3",
            "coordinator_workflow_v03.zip"
        ],
        [
            "Move 25",
            "Companion CLI v0.3",
            "companion_cli_v03.zip"
        ],
        [
            "Move 26",
            "Unified Case Manifest v0.1",
            "unified_case_manifest_v01.zip"
        ],
        [
            "Move 27",
            "Stack Verifier v0.1",
            "stack_verifier_v01.zip"
        ],
        [
            "Move 28",
            "Stack Selfcheck v0.1",
            "stack_selfcheck_v01.zip"
        ],
        [
            "Move 29",
            "Stack Red/Blue Pack v0.2",
            "stack_red_blue_pack_v02.zip"
        ]
    ],
    "repairs": [
        [
            "Move 30 repair",
            "Coordinator Workflow v0.3.1 real runner repair",
            "coordinator_workflow_v031.zip"
        ],
        [
            "Move 30 repair",
            "Companion CLI v0.3.1 request hygiene repair",
            "companion_cli_v031.zip"
        ],
        [
            "Move 30 repair",
            "Coordinator Workflow v0.3.2 Case Bundle evidence_id repair",
            "coordinator_workflow_v032.zip"
        ],
        [
            "Move 30 repair",
            "Stack Selfcheck v0.1.1 legacy documentation repair",
            "stack_selfcheck_v011.zip"
        ],
        [
            "Move 30 repair",
            "Stack Selfcheck v0.1.2 truth-boundary phrase repair",
            "stack_selfcheck_v012.zip"
        ]
    ],
    "demo_reviewability": [
        [
            "Move 30",
            "Connected Demo v0.1",
            "connected_demo_v01.zip"
        ],
        [
            "Move 31",
            "Beginner Runbook v0.1",
            "beginner_runbook_v01.zip"
        ],
        [
            "Move 32",
            "One-Command Demo Script v0.1",
            "one_command_demo_script_v01.zip"
        ],
        [
            "Move 33",
            "Demo Output Bundle v0.1",
            "demo_output_bundle_v01.zip"
        ],
        [
            "Move 34",
            "Architecture Diagram v0.1",
            "architecture_diagram_v01.zip"
        ],
        [
            "Move 35",
            "Master Known Limitations Document v0.1",
            "master_known_limitations_v01/"
        ],
        [
            "Move 36",
            "Threat Model v0.1",
            "threat_model_v01/"
        ],
        [
            "Move 37",
            "External Review Pack v0.1",
            "external_review_pack_v01/"
        ],
        [
            "Move 38",
            "Hostile Review Prompt Pack v0.1",
            "hostile_review_prompt_pack_v01/"
        ],
        [
            "Move 39",
            "Response-to-Review Ledger v0.1",
            "response_to_review_ledger_v01/"
        ]
    ]
}

DOC_VERIFIERS = [
    ("master_known_limitations_v01", "verify_master_known_limitations.py", "MASTER_KNOWN_LIMITATIONS_VERIFIED"),
    ("threat_model_v01", "verify_threat_model.py", "THREAT_MODEL_VERIFIED"),
    ("external_review_pack_v01", "verify_external_review_pack.py", "EXTERNAL_REVIEW_PACK_VERIFIED"),
    ("hostile_review_prompt_pack_v01", "verify_hostile_review_prompt_pack.py", "HOSTILE_REVIEW_PROMPT_PACK_VERIFIED"),
    ("response_to_review_ledger_v01", "verify_response_to_review_ledger.py", "RESPONSE_TO_REVIEW_LEDGER_VERIFIED"),
]

FORBIDDEN_TOP_LEVEL_DIRS = [
    "src",
    "app",
    "web",
    "android",
    "windows",
    "runtime",
    "Coordinator_FREEZES",
    "Companion_FREEZES",
    "ConnectedDemo_FREEZES",
    "BeginnerRunbook_FREEZES",
    "OneCommandDemoScript_FREEZES",
    "DemoOutputBundle_FREEZES",
    "ArchitectureDiagram_FREEZES",
]

def fail(message: str) -> None:
    print(f"VERIFY_FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def read_text(rel: str) -> str:
    path = ROOT / rel
    if not path.exists():
        fail(f"missing required file: {rel}")
    return path.read_text(encoding="utf-8")

def check_required_files() -> None:
    for rel in REQUIRED_FILES:
        if not (ROOT / rel).exists():
            fail(f"missing required file: {rel}")

def check_package_scope() -> None:
    for name in FORBIDDEN_TOP_LEVEL_DIRS:
        if (ROOT / name).exists():
            fail(f"forbidden top-level directory present: {name}")
    tools = ROOT / "tools"
    tool_files = [p.relative_to(ROOT).as_posix() for p in tools.rglob("*") if p.is_file()]
    if tool_files != ["tools/verify_local_demo_pack.py"]:
        fail(f"unexpected tools contents: {tool_files}")

def check_text_boundaries() -> None:
    required_phrases = {
        "README.md": ["Move 40", "Moves 1–29", "Moves 30–39", "LOCAL_DEMO_PACK_VERIFIED"],
        "FREEZE_RECORD.md": ["Foundation accounted for: Moves 1–29", "Direct demo/reviewability layer accounted for: Moves 30–39", "does not mean"],
        "INCLUDED_ARTIFACTS.md": ["Foundation artifacts — Moves 1–29", "Move 30 repair chain", "Local demo and reviewability artifacts — Moves 30–39"],
        "KNOWN_LIMITS_SUMMARY.md": ["does not prove evidence contents are true", "does not verify external reality", "does not prove production readiness"],
        "RELEASE_GATE.md": ["Moves 1–29 foundation artifacts are accounted for", "Moves 31–39 artifacts are accounted for", "FAIL criteria"],
        "VERIFICATION.md": ["Move 35 verifier passes", "Move 39 verifier passes", "Verification limits"],
        "TEST_RESULTS.md": ["LOCAL_DEMO_PACK_VERIFIED", "verify_ok = true", "ResourceWarning sweep"],
        "REPAIR_LEDGER.md": ["M40-REPAIR-001", "No open repairs"],
    }
    for rel, phrases in required_phrases.items():
        text = read_text(rel)
        for phrase in phrases:
            if phrase not in text:
                fail(f"{rel} missing required phrase: {phrase}")

def check_baseline() -> tuple[Path, list[str]]:
    info = json.loads(read_text("PACK_INFO.json"))
    baseline_rel = info["baseline_filename"]
    baseline = ROOT / baseline_rel
    if not baseline.exists():
        fail("baseline archive missing")
    actual_hash = sha256_file(baseline)
    if actual_hash != info["baseline_sha256"]:
        fail(f"baseline SHA256 mismatch: expected {info['baseline_sha256']}, got {actual_hash}")
    try:
        with zipfile.ZipFile(baseline, "r") as z:
            bad = z.testzip()
            if bad is not None:
                fail(f"baseline zip integrity failed at {bad}")
            names = z.namelist()
            if len(names) != len(set(names)):
                fail("baseline archive contains duplicate entries")
    except zipfile.BadZipFile as exc:
        fail(f"baseline is not a valid zip: {exc}")
    return baseline, names

def check_nested_sha256(baseline: Path) -> None:
    with zipfile.ZipFile(baseline, "r") as z:
        names = set(z.namelist())
        sha_files = sorted([n for n in names if n.lower().endswith(".sha256")])
        if not sha_files:
            fail("no nested .sha256 files found")
        checked = 0
        for sha_name in sha_files:
            text = z.read(sha_name).decode("utf-8", errors="replace").strip()
            m = re.search(r"\b([a-fA-F0-9]{64})\b", text)
            if not m:
                fail(f"nested sha file has no digest: {sha_name}")
            expected = m.group(1).lower()
            after = text[m.end():].strip()
            if after:
                token = after.split()[0]
                target = (Path(sha_name).parent / token).as_posix()
            elif sha_name.lower().endswith(".zip.sha256"):
                target = sha_name[:-7]
            else:
                target = sha_name[:-7] + ".zip"
            if target not in names:
                fail(f"nested sha target missing: {sha_name} -> {target}")
            actual = hashlib.sha256(z.read(target)).hexdigest()
            if actual != expected:
                fail(f"nested sha mismatch: {target}")
            checked += 1
        if checked < 30:
            fail(f"too few nested sha files checked: {checked}")

def check_markers(names: list[str]) -> None:
    joined = "\n".join(names).lower()
    missing = []
    for category, items in EXPECTED_MARKERS.items():
        for move, title, marker in items:
            if marker.lower() not in joined:
                missing.append(f"{category}: {move} {title} marker {marker}")
    if missing:
        fail("missing expected baseline markers: " + "; ".join(missing))

def find_dir(root: Path, dirname: str) -> Path | None:
    matches = [p for p in root.rglob(dirname) if p.is_dir()]
    if not matches:
        return None
    with_tools = [p for p in matches if (p / "tools").is_dir()]
    return with_tools[0] if with_tools else matches[0]

def run_doc_verifiers(baseline: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="pw_local_demo_pack_") as tmp:
        tmp_path = Path(tmp)
        with zipfile.ZipFile(baseline, "r") as z:
            z.extractall(tmp_path)
        for package_dir_name, verifier_name, expected_output in DOC_VERIFIERS:
            package_dir = find_dir(tmp_path, package_dir_name)
            if package_dir is None:
                fail(f"documentation package not found after extraction: {package_dir_name}")
            verifier = package_dir / "tools" / verifier_name
            if not verifier.exists():
                fail(f"documentation verifier missing: {verifier}")
            result = subprocess.run([sys.executable, str(verifier)], cwd=package_dir, text=True, capture_output=True)
            if result.returncode != 0:
                fail(f"documentation verifier failed for {package_dir_name}: {result.stdout} {result.stderr}")
            if expected_output not in result.stdout or "verify_ok = true" not in result.stdout:
                fail(f"documentation verifier output unexpected for {package_dir_name}: {result.stdout}")

def check_checksums() -> None:
    # RT-003 repair (Move 42): recompute and compare the SHA-256 of every wrapper
    # file listed in CHECKSUMS.txt, not just confirm the path string is present.
    text = read_text("CHECKSUMS.txt")
    listed: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^([0-9a-fA-F]{64})\s+(.+)$", line)
        if not m:
            fail(f"CHECKSUMS.txt malformed line: {line!r}")
        digest = m.group(1).lower()
        rel = m.group(2).strip()
        if rel in listed:
            fail(f"CHECKSUMS.txt duplicate entry: {rel}")
        listed[rel] = digest
    # Every listed file except CHECKSUMS.txt must exist and hash-match.
    for rel, expected in sorted(listed.items()):
        if rel == "CHECKSUMS.txt":
            continue
        path = ROOT / rel
        if not path.is_file():
            fail(f"CHECKSUMS.txt lists missing file: {rel}")
        actual = sha256_file(path)
        if actual != expected:
            fail(f"CHECKSUMS.txt hash mismatch: {rel}")
    # No extra unlisted wrapper files. Documented exclusions: CHECKSUMS.txt itself,
    # any __pycache__ entry, and dotfiles (none are shipped in the package).
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if rel == "CHECKSUMS.txt":
            continue
        parts = rel.split("/")
        if "__pycache__" in parts or any(part.startswith(".") for part in parts):
            continue
        if rel not in listed:
            fail(f"unlisted wrapper file present: {rel}")

def main() -> None:
    check_required_files()
    check_package_scope()
    check_text_boundaries()
    baseline, names = check_baseline()
    check_nested_sha256(baseline)
    check_markers(names)
    run_doc_verifiers(baseline)
    check_checksums()
    print("LOCAL_DEMO_PACK_VERIFIED")
    print("verify_ok = true")

if __name__ == "__main__":
    main()
