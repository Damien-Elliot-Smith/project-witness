# Known Limits Summary

This summary does not replace Move 35 Master Known Limitations Document.

It repeats the limits that matter most for Move 40.

## Current hard limits

Project Witness Local Demo Pack v0.1:

- does not prove evidence contents are true
- does not prove ODIN claims are true
- does not verify external reality
- does not prove sources are trusted
- does not prove files are authentic beyond hash matching
- does not sign outputs
- does not externally anchor outputs
- cannot prevent whole-folder fabrication under unkeyed hashes
- does not prove production readiness
- does not provide a GUI
- does not provide an Android app
- does not provide a Windows app
- does not provide a web UI
- does not provide LLM reasoning
- does not provide natural-language interpretation
- does not provide production incident response
- does not provide multi-case search
- does not provide multi-actor approval chains
- does not provide policy governance

## Correct claim

A safe claim is:

```text
Project Witness Local Demo Pack v0.1 packages and verifies a frozen local demo baseline through Move 39, with documented limitations and reviewability artifacts.
```

## Unsafe claims

Unsafe claims include:

```text
Project Witness proves truth.
Project Witness verifies reality.
Project Witness proves source trust.
Project Witness is tamper-proof.
Project Witness is production-ready.
Project Witness prevents all deception.
```
