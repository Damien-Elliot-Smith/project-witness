# Included Artifacts Ledger

## Purpose

This ledger makes the Move 40 freeze account for the whole baseline, not only the final reviewability moves.

## Foundation artifacts — Moves 1–29

| Roadmap area | Artifact | Required baseline marker |
|---|---|---|
| Moves 1-3 | Sentinel Core v0.2.2 | `sentinel_core_v022.zip` |
| Moves 1-3 | Sentinel Red/Blue Pack v0.1 | `sentinel_red_blue_pack_v01.zip` |
| Move 4 | Histor-lite v0.1.2 | `histor_lite_v012.zip` |
| Move 5 | Case Bundle v0.1.1 | `case_bundle_v011.zip` |
| Move 6 | Coordinator Workflow v0.1.8 | `coordinator_workflow_v018.zip` |
| Move 7 | Companion CLI v0.1 | `companion_cli_v01.zip` |
| Move 8 | Workflow Red/Blue Pack v0.1 | `project_witness_workflow_red_blue_pack_v01.zip` |
| Move 9 | Aletheia Evidence Bundle v0.1 | `aletheia_evidence_bundle_v01.zip` |
| Move 10 | ODIN Claim Reasoner v0.1 | `odin_claim_reasoner_v01.zip` |
| Moves 11-12 | ODIN Red/Blue Pack v0.1 | `odin_red_blue_pack_v01.zip` |
| Move 13 | Aletheia to ODIN Bridge v0.1 | `aletheia_odin_bridge_v01.zip` |
| Moves 14-15 | Evidence Reasoning Demo v0.1 | `evidence_reasoning_demo_v01.zip` |
| Move 16 | Histor-lite Aletheia Importer v0.1 | `histor_lite_aletheia_importer_v01.zip` |
| Move 17 | Histor-lite ODIN Importer v0.1 | `histor_lite_odin_importer_v01.zip` |
| Move 18 | Case Bundle v0.2 | `case_bundle_v02.zip` |
| Move 19 | Coordinator Workflow v0.2 | `coordinator_workflow_v02.zip` |
| Move 20 | Companion CLI v0.2 | `companion_cli_v02.zip` |
| Move 21 | Atlas Registry v0.1 | `atlas_registry_v01.zip` |
| Move 22 | Atlas Release Gate v0.1 | `atlas_release_gate_v01.zip` |
| Move 23 | Atlas Red/Blue Pack v0.1 | `atlas_red_blue_pack_v01.zip` |
| Move 24 | Coordinator Workflow v0.3 | `coordinator_workflow_v03.zip` |
| Move 25 | Companion CLI v0.3 | `companion_cli_v03.zip` |
| Move 26 | Unified Case Manifest v0.1 | `unified_case_manifest_v01.zip` |
| Move 27 | Stack Verifier v0.1 | `stack_verifier_v01.zip` |
| Move 28 | Stack Selfcheck v0.1 | `stack_selfcheck_v01.zip` |
| Move 29 | Stack Red/Blue Pack v0.2 | `stack_red_blue_pack_v02.zip` |

## Move 30 repair chain

| Roadmap area | Artifact | Required baseline marker |
|---|---|---|
| Move 30 repair | Coordinator Workflow v0.3.1 real runner repair | `coordinator_workflow_v031.zip` |
| Move 30 repair | Companion CLI v0.3.1 request hygiene repair | `companion_cli_v031.zip` |
| Move 30 repair | Coordinator Workflow v0.3.2 Case Bundle evidence_id repair | `coordinator_workflow_v032.zip` |
| Move 30 repair | Stack Selfcheck v0.1.1 legacy documentation repair | `stack_selfcheck_v011.zip` |
| Move 30 repair | Stack Selfcheck v0.1.2 truth-boundary phrase repair | `stack_selfcheck_v012.zip` |

## Local demo and reviewability artifacts — Moves 30–39

| Roadmap area | Artifact | Required baseline marker |
|---|---|---|
| Move 30 | Connected Demo v0.1 | `connected_demo_v01.zip` |
| Move 31 | Beginner Runbook v0.1 | `beginner_runbook_v01.zip` |
| Move 32 | One-Command Demo Script v0.1 | `one_command_demo_script_v01.zip` |
| Move 33 | Demo Output Bundle v0.1 | `demo_output_bundle_v01.zip` |
| Move 34 | Architecture Diagram v0.1 | `architecture_diagram_v01.zip` |
| Move 35 | Master Known Limitations Document v0.1 | `master_known_limitations_v01/` |
| Move 36 | Threat Model v0.1 | `threat_model_v01/` |
| Move 37 | External Review Pack v0.1 | `external_review_pack_v01/` |
| Move 38 | Hostile Review Prompt Pack v0.1 | `hostile_review_prompt_pack_v01/` |
| Move 39 | Response-to-Review Ledger v0.1 | `response_to_review_ledger_v01/` |

## Accounting rule

An artifact is considered accounted for if the Move 40 verifier finds its required marker inside:

```text
artifacts/frozen_working_projects_baseline.zip
```

The verifier checks the markers above.

## Important limit

This ledger confirms presence/accounting inside the baseline archive.

It does not independently re-run every historical component's full original test suite.

For Moves 35–39, the verifier does rerun the documentation package verifiers after extracting the baseline archive.
