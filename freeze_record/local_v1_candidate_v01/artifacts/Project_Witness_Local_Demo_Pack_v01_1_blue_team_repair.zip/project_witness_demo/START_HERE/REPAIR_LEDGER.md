# Repair Ledger — Project Witness Local Demo Pack v0.1

| Repair ID | Issue | Fix | Scope impact | Status |
|---|---|---|---|---|
| M40-REPAIR-001 | Initial Move 40 framing focused too narrowly on Moves 30–39. | Expanded Move 40 accounting to include Moves 1–29 foundation artifacts and the Move 30 repair chain. | Documentation/verifier scope only. No runtime impact. | CLOSED |
| M40-REPAIR-002 | Freeze pack needed to verify the embedded baseline archive itself, not just wrapper files. | Added baseline archive SHA256 check, zip integrity check, nested checksum check, artifact marker checks, and Moves 35–39 verifier reruns. | Verification only. No runtime impact. | CLOSED |
| M40-REPAIR-003 | Candidate reviewer-layout zip used wording that could imply Part One ended at Step 40, and did not clearly distinguish the authoritative baseline from convenience folders. | Corrected `INDEX.md` to say Part One is complete through Step 40, added authoritative-baseline notes to `INDEX.md` and `START_HERE/README.md`, and regenerated checksums. | Documentation/checksum scope only. No runtime impact. | CLOSED |
| M40-REPAIR-004 | Move 41 red team RT-003 (MINOR, CONFIRMED): the wrapper verifier confirmed each `CHECKSUMS.txt` path was present but did not recompute and compare each file's SHA-256, and did not reject extra unlisted wrapper files. | Move 42 blue team rewrote `check_checksums()` to parse each `<sha256>  <path>` line, recompute and compare the SHA-256 of every listed wrapper file (failing on missing file or digest mismatch), and reject extra unlisted files (documented exclusions: `CHECKSUMS.txt`, `__pycache__`, dotfiles). Verifier code and checksums only. The embedded baseline and all frozen components were not touched. | Wrapper verifier + checksum/doc scope only. No runtime impact. | CLOSED |

## Final status

No open repairs for v0.1.
