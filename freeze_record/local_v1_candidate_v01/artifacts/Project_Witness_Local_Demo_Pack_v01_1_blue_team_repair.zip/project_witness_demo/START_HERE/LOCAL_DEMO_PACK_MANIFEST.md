# Local Demo Pack Manifest v0.1

## Package identity

```text
Package: project_witness_local_demo_pack_v01
Move: 40
Purpose: Freeze Project Witness Local Demo Pack
Baseline: artifacts/frozen_working_projects_baseline.zip
Baseline SHA256: 0f1d56ac199a788168e24540c9f347010a3f01e8ea17732d4bdbc756040445bc
```

## Baseline archive statistics

```text
Zip integrity: PASS
Duplicate zip entries: 0
Total entries: 253
Nested zip artifacts: 36
Nested .sha256 files: 33
Nested checksum matches: 33 / 33
```

## Scope summary

This manifest accounts for:

```text
Moves 1–29 — frozen foundation artifacts
Move 30 — connected local demo and repair chain
Moves 31–34 — usability and diagram artifacts
Moves 35–39 — limitations, threat model, external review pack, hostile review prompt pack, response-to-review ledger
Move 40 — this freeze package
```

## Freeze boundary

The freeze boundary is the combined baseline archive plus this Move 40 wrapper package.

This package does not rewrite the baseline archive.

This package does not modify any frozen component inside the baseline archive.

This package verifies the baseline archive and records what it contains.
