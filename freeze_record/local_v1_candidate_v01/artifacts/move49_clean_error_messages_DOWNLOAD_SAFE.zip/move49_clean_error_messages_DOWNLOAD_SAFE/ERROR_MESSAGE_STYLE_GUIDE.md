# Error Message Style Guide

## Good Project Witness error messages

A good error message should say:

1. what failed
2. which file or artifact was involved
3. whether the failure is blocking
4. what the reviewer should do next
5. what should not be assumed

## Pattern

```text
[CODE] Clear failure summary.
Meaning: what this says about the package.
Action: what the reviewer should do next.
Severity: BLOCKER / MAJOR / MINOR / NOTE.
```

## Avoid

- vague messages like "something went wrong"
- success language after a failure
- hiding the file path
- treating checksum failures as warnings
- implying truth proof or production readiness

## Severity definitions

```text
BLOCKER: stop; the package cannot be treated as verified.
MAJOR: serious review problem; likely must be repaired before release candidate.
MINOR: does not block verification but should be cleaned.
NOTE: useful context only.
```
