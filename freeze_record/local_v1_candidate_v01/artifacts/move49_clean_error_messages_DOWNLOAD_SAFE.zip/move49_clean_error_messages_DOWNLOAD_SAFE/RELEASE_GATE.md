# Release Gate — Clean Error Messages v0.1

## PASS criteria

| Gate | Criterion | Required status |
|---|---|---|
| RG-001 | Error-message catalog exists | PASS |
| RG-002 | Raw-to-clean map exists | PASS |
| RG-003 | Reviewer failure guide exists | PASS |
| RG-004 | Troubleshooting decision tree exists | PASS |
| RG-005 | Style guide exists | PASS |
| RG-006 | Machine-readable registry exists | PASS |
| RG-007 | Current Move 48 baseline artifact included | PASS |
| RG-008 | Package verifier passes | PASS |
| RG-009 | ResourceWarning sweep passes | PASS |
| RG-010 | Move 50 not performed | PASS |
| RG-011 | Local v1 Candidate not frozen | PASS |
| RG-012 | No frozen artifacts modified | PASS |

## FAIL criteria

The package fails if:

- required catalogue files are missing
- registry is missing or malformed
- artifacts do not match manifest hashes
- CHECKSUMS.txt does not match package files
- Move 50 is performed
- Local v1 Candidate is claimed as frozen
- failures are softened into warnings
- verifier fails
