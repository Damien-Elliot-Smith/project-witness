# Error Message Catalog

| Code | Severity | Clean message | Reviewer action |
|---|---|---|---|
| `PW49-CHECKSUM-MISMATCH` | BLOCKER | A file does not match its recorded SHA256 checksum. | Stop. Record the file path, command, and full verifier output. Do not continue as if the package passed. |
| `PW49-MISSING-FILE` | BLOCKER | A required file is missing from the package. | Stop. Re-extract from the original zip. If the file is still missing, report the package as failed. |
| `PW49-ZIP-INTEGRITY` | BLOCKER | A zip archive failed integrity checks. | Stop. Re-download or re-copy the archive, then repeat the checksum check. |
| `PW49-EMBEDDED-BASELINE-MISMATCH` | BLOCKER | The embedded frozen baseline does not match the expected SHA256 digest. | Stop. Report a baseline mismatch with the expected and actual digest. |
| `PW49-UNLISTED-FILE` | MAJOR | An unexpected file exists in the package wrapper. | Stop. Record the unexpected path and treat the package as failed until reviewed. |
| `PW49-FORBIDDEN-CLAIM` | MAJOR | The package contains wording that overclaims the project status or capability. | Record the phrase and file. Do not use the misleading claim in public/reviewer material. |
| `PW49-RESOURCEWARNING` | MAJOR | A verifier emitted a resource-management warning under strict warning mode. | Record the warning and treat it as a repair candidate before release-candidate freeze. |
| `PW49-REGISTRY-MISMATCH` | BLOCKER | A registry entry does not match the artifact bytes. | Stop. Record expected and actual hashes and report as a blocker. |

## Principle

These messages do not alter verifier behavior. They give reviewers a clearer way to understand verifier behavior.
