# Error Message Cleaning Scope

## In scope

- catalogue common verifier failure modes
- translate raw failure strings into clear reviewer-facing messages
- explain what the reviewer should do after a failure
- define severity labels
- provide troubleshooting guidance
- verify the report package itself

## Out of scope

- changing verifier logic
- suppressing failures
- converting failures into warnings
- editing frozen artifacts
- performing Move 50
- freezing Local v1 Candidate
- claiming production readiness

## Rule

A clean error message must make failures clearer, not softer.
