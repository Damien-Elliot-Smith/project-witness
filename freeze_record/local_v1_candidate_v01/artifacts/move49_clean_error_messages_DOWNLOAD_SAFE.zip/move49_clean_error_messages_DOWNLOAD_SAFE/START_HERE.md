# Start Here

Read these files in order:

1. `ERROR_MESSAGE_CATALOG.md`
2. `RAW_TO_CLEAN_ERROR_MAP.md`
3. `REVIEWER_FAILURE_GUIDE.md`
4. `TROUBLESHOOTING_DECISION_TREE.md`
5. `ERROR_MESSAGE_STYLE_GUIDE.md`
6. `CLAIMS_AND_LIMITS.md`
7. `MOVE_50_HANDOFF.md`

The machine-readable registry is:

```text
ERROR_MESSAGE_REGISTRY.json
```

This package does not replace the verifiers. It explains their failures in cleaner human language.
