# Raw-to-Clean Error Map

| Canonical code | Raw examples | Clean message |
|---|---|---|
| `PW49-CHECKSUM-MISMATCH` | `CHECKSUMS.txt hash mismatch for README.md`; `CHECKSUMS.txt hash mismatch: README.md` | A file does not match its recorded SHA256 checksum. |
| `PW49-MISSING-FILE` | `missing required file`; `missing copied artifact` | A required file is missing from the package. |
| `PW49-ZIP-INTEGRITY` | `zip integrity failure`; `bad zip member` | A zip archive failed integrity checks. |
| `PW49-EMBEDDED-BASELINE-MISMATCH` | `embedded baseline SHA256 mismatch`; `baseline checksum mismatch` | The embedded frozen baseline does not match the expected SHA256 digest. |
| `PW49-UNLISTED-FILE` | `unlisted wrapper file present` | An unexpected file exists in the package wrapper. |
| `PW49-FORBIDDEN-CLAIM` | `forbidden phrase present`; `forbidden current-status claim present` | The package contains wording that overclaims the project status or capability. |
| `PW49-RESOURCEWARNING` | `ResourceWarning`; `unclosed file` | A verifier emitted a resource-management warning under strict warning mode. |
| `PW49-REGISTRY-MISMATCH` | `registry hash mismatch`; `artifact hash mismatch` | A registry entry does not match the artifact bytes. |

## Observed raw error-like strings from Move 48 docs

```text
No additional raw error-like strings collected.
```
