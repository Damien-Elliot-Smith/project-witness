# Error Message Examples

## Before

```text
VERIFY_FAIL: CHECKSUMS.txt hash mismatch: README.md
```

## After

```text
PW49-CHECKSUM-MISMATCH: A file does not match its recorded SHA256 checksum.
File: README.md
Action: Stop. Record the command and full output. Do not continue as if verified.
Severity: BLOCKER
```

## Before

```text
VERIFY_FAIL: unlisted wrapper file present: SNEAKY_EXTRA.md
```

## After

```text
PW49-UNLISTED-FILE: An unexpected file exists in the package wrapper.
File: SNEAKY_EXTRA.md
Action: Stop and record the path. The package contains material not covered by checksum policy.
Severity: MAJOR
```
