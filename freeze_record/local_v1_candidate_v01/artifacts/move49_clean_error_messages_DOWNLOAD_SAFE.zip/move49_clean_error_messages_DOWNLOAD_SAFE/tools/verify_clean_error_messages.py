#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    'README.md',
    'START_HERE.md',
    'ERROR_MESSAGE_CLEANING_SCOPE.md',
    'ERROR_MESSAGE_STYLE_GUIDE.md',
    'ERROR_MESSAGE_CATALOG.md',
    'RAW_TO_CLEAN_ERROR_MAP.md',
    'REVIEWER_FAILURE_GUIDE.md',
    'TROUBLESHOOTING_DECISION_TREE.md',
    'ERROR_MESSAGE_EXAMPLES.md',
    'VERIFIER_FAILURE_MESSAGES.md',
    'ARTIFACT_INDEX.md',
    'CLAIMS_AND_LIMITS.md',
    'SCOPE_BOUNDARY.md',
    'RELEASE_GATE.md',
    'VERIFICATION.md',
    'TEST_RESULTS.md',
    'REPAIR_LEDGER.md',
    'MOVE_50_HANDOFF.md',
    'ARTIFACT_MANIFEST.json',
    'ERROR_MESSAGE_REGISTRY.json',
    'CHECKSUMS.txt',
    'tools/verify_clean_error_messages.py',
]

REQUIRED_ARTIFACTS = [
    'artifacts/human_readable_reports_v01.zip',
    'artifacts/example_reviewer_walkthrough_v01.zip',
    'artifacts/independent_verification_script_v01.zip',
    'artifacts/full_stack_component_version_freeze_v01.zip',
    'artifacts/project_witness_70_step_roadmap_clean.pdf',
]

FORBIDDEN_DIRS = ['src', 'app', 'web', 'android', 'windows', 'runtime', 'project_witness_demo']
FORBIDDEN_CURRENT_CLAIMS = [
    'Move 50 is complete',
    'Local v1 Candidate has been frozen',
    'Local v1 Candidate is now frozen',
    'Project Witness Part One has been fully completed',
]

VALID_SEVERITIES = {'BLOCKER', 'MAJOR', 'MINOR', 'NOTE'}

def fail(msg: str) -> None:
    print(f'VERIFY_FAIL: {msg}', file=sys.stderr)
    raise SystemExit(1)

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def read_text(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        fail(f'missing required file: {rel}')
    return p.read_text(encoding='utf-8')

def main() -> None:
    for rel in REQUIRED_FILES + REQUIRED_ARTIFACTS:
        if not (ROOT / rel).exists():
            fail(f'missing required file: {rel}')

    for d in FORBIDDEN_DIRS:
        if (ROOT / d).exists():
            fail(f'forbidden runtime/source directory included: {d}')

    boundary_text = '\n'.join(read_text(rel) for rel in ['README.md', 'SCOPE_BOUNDARY.md', 'MOVE_50_HANDOFF.md', 'CLAIMS_AND_LIMITS.md'])
    for phrase in FORBIDDEN_CURRENT_CLAIMS:
        if phrase in boundary_text:
            fail(f'forbidden current-status claim present: {phrase}')

    required_phrases = {
        'ERROR_MESSAGE_CATALOG.md': ['PW49-CHECKSUM-MISMATCH', 'PW49-MISSING-FILE', 'PW49-RESOURCEWARNING'],
        'RAW_TO_CLEAN_ERROR_MAP.md': ['Raw examples', 'Clean message'],
        'REVIEWER_FAILURE_GUIDE.md': ['Do not continue as if the package passed', 'Record'],
        'TROUBLESHOOTING_DECISION_TREE.md': ['Verifier failed?', 'checksum mismatch'],
        'ERROR_MESSAGE_STYLE_GUIDE.md': ['what failed', 'Severity definitions'],
        'MOVE_50_HANDOFF.md': ['Move 50', 'Freeze Local v1 Candidate', 'Do not claim production readiness'],
        'CLAIMS_AND_LIMITS.md': ['Project Witness Part One is complete through Move 49', 'Move 50 remains future work'],
    }
    for rel, phrases in required_phrases.items():
        text = read_text(rel)
        for phrase in phrases:
            if phrase not in text:
                fail(f'{rel} missing phrase: {phrase}')

    manifest = json.loads(read_text('ARTIFACT_MANIFEST.json'))
    by_name = {a['filename']: a for a in manifest['input_artifacts']}
    for rel in REQUIRED_ARTIFACTS:
        path = ROOT / rel
        name = path.name
        if name not in by_name:
            fail(f'artifact missing from manifest: {name}')
        if sha256_file(path) != by_name[name]['sha256']:
            fail(f'artifact hash mismatch: {name}')

    registry = json.loads(read_text('ERROR_MESSAGE_REGISTRY.json'))
    errors = registry.get('canonical_errors', [])
    if len(errors) < 8:
        fail('expected at least 8 canonical errors')
    codes = set()
    for e in errors:
        for key in ['code', 'severity', 'clean_message', 'meaning', 'reviewer_action', 'raw_examples']:
            if key not in e or not e[key]:
                fail(f'canonical error missing {key}')
        if e['code'] in codes:
            fail(f'duplicate error code: {e["code"]}')
        codes.add(e['code'])
        if e['severity'] not in VALID_SEVERITIES:
            fail(f'invalid severity for {e["code"]}: {e["severity"]}')

    expected = {}
    for line in read_text('CHECKSUMS.txt').splitlines():
        if not line.strip():
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            fail(f'bad CHECKSUMS line: {line}')
        expected[parts[1].strip()] = parts[0].strip().lower()

    actual_files = []
    for p in ROOT.rglob('*'):
        if p.is_file():
            rel = p.relative_to(ROOT).as_posix()
            if rel != 'CHECKSUMS.txt':
                actual_files.append(rel)
    for rel in actual_files:
        if rel not in expected:
            fail(f'CHECKSUMS missing file: {rel}')
        if sha256_file(ROOT / rel) != expected[rel]:
            fail(f'CHECKSUMS hash mismatch: {rel}')
    for rel in expected:
        if rel not in actual_files:
            fail(f'CHECKSUMS lists missing file: {rel}')

    print('CLEAN_ERROR_MESSAGES_VERIFIED')
    print('verify_ok = true')

if __name__ == '__main__':
    main()
