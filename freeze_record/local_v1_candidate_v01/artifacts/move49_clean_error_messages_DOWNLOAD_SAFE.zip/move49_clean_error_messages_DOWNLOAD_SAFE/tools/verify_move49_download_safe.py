#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    "README.md",
    "START_HERE.md",
    "ERROR_MESSAGE_CATALOG.md",
    "RAW_TO_CLEAN_ERROR_MAP.md",
    "REVIEWER_FAILURE_GUIDE.md",
    "TROUBLESHOOTING_DECISION_TREE.md",
    "ERROR_MESSAGE_STYLE_GUIDE.md",
    "ERROR_MESSAGE_EXAMPLES.md",
    "VERIFIER_FAILURE_MESSAGES.md",
    "ERROR_MESSAGE_REGISTRY.json",
    "MOVE_50_HANDOFF.md",
    "DOWNLOAD_SAFE_NOTE.md",
    "EXTERNAL_ARTIFACTS_OMITTED.json",
    "CHECKSUMS.txt",
    "tools/verify_move49_download_safe.py",
]

FORBIDDEN_CURRENT_CLAIMS = [
    "Move 50 is complete",
    "Local v1 Candidate has been frozen",
    "Local v1 Candidate is now frozen",
]

def fail(msg):
    print(f"VERIFY_FAIL: {msg}", file=sys.stderr)
    raise SystemExit(1)

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def read(rel):
    p=ROOT/rel
    if not p.exists():
        fail(f"missing required file: {rel}")
    return p.read_text(encoding="utf-8")

def main():
    for rel in REQUIRED:
        if not (ROOT/rel).exists():
            fail(f"missing required file: {rel}")

    all_text = "\n".join((p.read_text(encoding="utf-8", errors="replace") for p in ROOT.rglob("*.md")))
    for phrase in FORBIDDEN_CURRENT_CLAIMS:
        if phrase in all_text:
            fail(f"forbidden current-status claim present: {phrase}")

    # JSON parses.
    json.loads(read("ERROR_MESSAGE_REGISTRY.json"))
    json.loads(read("EXTERNAL_ARTIFACTS_OMITTED.json"))

    # Check checksums.
    expected={}
    for line in read("CHECKSUMS.txt").splitlines():
        if not line.strip():
            continue
        parts=line.split(None,1)
        if len(parts)!=2:
            fail(f"bad CHECKSUMS line: {line}")
        expected[parts[1].strip()] = parts[0].strip().lower()

    actual=[]
    for p in ROOT.rglob("*"):
        if p.is_file():
            rel=p.relative_to(ROOT).as_posix()
            if rel!="CHECKSUMS.txt":
                actual.append(rel)

    for rel in actual:
        if rel not in expected:
            fail(f"CHECKSUMS missing file: {rel}")
        if sha256_file(ROOT/rel) != expected[rel]:
            fail(f"CHECKSUMS hash mismatch: {rel}")

    for rel in expected:
        if rel not in actual:
            fail(f"CHECKSUMS lists missing file: {rel}")

    print("MOVE49_DOWNLOAD_SAFE_VERIFIED")
    print("verify_ok = true")

if __name__ == "__main__":
    main()
