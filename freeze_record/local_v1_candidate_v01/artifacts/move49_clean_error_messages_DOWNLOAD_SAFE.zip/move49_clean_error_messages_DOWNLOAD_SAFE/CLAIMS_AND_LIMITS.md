# Claims and Limits

## Correct claim

Project Witness has a clean error-message catalogue through Move 49.

The package makes verification failures easier to interpret.

## Incorrect claims

Do not claim:

- Local v1 Candidate is frozen.
- Move 50 has been performed.
- Project Witness Part One is finished in full.
- Project Witness proves truth.
- Project Witness verifies external reality.
- Project Witness proves source trust.
- Project Witness is production-ready.
- Project Witness is signed or externally anchored.

## Correct roadmap wording

```text
Project Witness Part One is complete through Move 49. Move 50 remains future work.
```
