# Repair Ledger — Clean Error Messages v0.1

## Boundary

This repair ledger is for the Move 49 package only.

No frozen Project Witness artifact was modified.

## Package construction repairs

| Repair ID | Issue | Fix | Scope impact | Status |
|---|---|---|---|---|
| MV49-PKG-001 | Error-message cleanup could be mistaken for verifier semantic changes. | Added scope language stating this is a documentation/readability layer only. | Documentation only. | CLOSED |
| MV49-PKG-002 | Needed clear distinction between failure explanation and failure softening. | Added rule: clean error messages must make failures clearer, not softer. | Documentation only. | CLOSED |

## Final status

No open repairs.
