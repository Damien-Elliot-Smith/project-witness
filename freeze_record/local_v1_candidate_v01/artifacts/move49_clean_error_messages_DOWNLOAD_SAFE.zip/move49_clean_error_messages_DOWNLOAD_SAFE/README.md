# Project Witness — Clean Error Messages v0.1

## Move

This package is **Move 49 — Clean Error Messages**.

It creates a clean reviewer-facing error-message layer for the current Project Witness stack through Move 48.

## Purpose

The goal is to make verification failures easier for a human reviewer to understand without weakening the verifier or hiding failures.

## What this package includes

- canonical error-message registry
- raw-to-clean error-message map
- reviewer failure guide
- troubleshooting decision tree
- error-message style guide
- release gate
- Move 50 handoff
- package verifier
- checksums

## What this package does not do

It does not modify frozen artifacts.

It does not change verifier semantics.

It does not perform Move 50.

It does not freeze Local v1 Candidate.

It does not add runtime features.

## Verify this package

```bash
python tools/verify_clean_error_messages.py
```

Expected:

```text
CLEAN_ERROR_MESSAGES_VERIFIED
verify_ok = true
```
