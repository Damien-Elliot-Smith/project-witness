# Scope Boundary

## Current move

Move 49 is **Clean Error Messages**.

## Allowed

- create clean error-message catalogues
- create reviewer failure guidance
- create troubleshooting guidance
- include current baseline artifacts for context
- verify this package
- prepare Move 50 handoff

## Not allowed

- modify frozen artifacts
- modify executable verifiers inside previous packages
- perform Move 50
- freeze Local v1 Candidate
- add runtime features
- add signing or anchoring
- add GUI/app/web UI/LLM integration
