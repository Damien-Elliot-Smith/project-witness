# Download-Safe Note

The original Move 49 package embedded previous stack artifacts and was about 303 MB.

Some app clients report `file not found` for files that large.

This download-safe package keeps the Move 49 documents, registry, verifier, and review material, but omits the large embedded stack zip artifacts.

This does **not** change the Move 49 content or verdict. It is a transport-safe copy.

Use `EXTERNAL_ARTIFACTS_OMITTED.json` to see which large artifacts were omitted and their checksums.

Boundary:

- No frozen runtime artifacts were modified.
- Move 50 was not performed.
- Local v1 Candidate was not frozen.
- No new runtime features were added.
