# Troubleshooting Decision Tree

```text
Verifier failed?
  |
  +-- Output says checksum mismatch?
  |     -> BLOCKER. Stop and report the file path.
  |
  +-- Output says missing file?
  |     -> BLOCKER. Re-extract once. If still missing, report failure.
  |
  +-- Output says zip integrity failure?
  |     -> BLOCKER. Re-copy/re-download the archive.
  |
  +-- Output says forbidden claim?
  |     -> MAJOR. Record the exact phrase and file.
  |
  +-- Output says unlisted file?
  |     -> MAJOR/BLOCKER depending location. Record the unexpected path.
  |
  +-- Output says ResourceWarning?
        -> MAJOR hygiene issue. Record and repair before Local v1 Candidate.
```

Do not reinterpret a failure as a pass.
