# Verification

## Command

```bash
python tools/verify_clean_error_messages.py
```

Expected:

```text
CLEAN_ERROR_MESSAGES_VERIFIED
verify_ok = true
```

## What the verifier checks

- required files exist
- included artifacts exist
- artifact hashes match manifest
- error-message registry parses
- canonical errors have code, severity, clean message, meaning, and reviewer action
- `CHECKSUMS.txt` matches package files
- Move 50 is not claimed complete
- Local v1 Candidate is not claimed frozen
- no runtime/source folders are included except tools

## Verification limits

The verifier checks this Move 49 package only.

It does not verify external reality or prove truth.
