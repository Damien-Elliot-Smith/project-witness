# Reviewer Failure Guide

## If checksum verification fails

Stop. Do not continue as if the package passed.

Record:

```text
command
file path
expected digest if shown
actual digest if shown
full output
```

## If a required file is missing

Re-extract the original zip. If the file is still missing, report package failure.

## If a forbidden claim is found

Treat it as a documentation integrity issue. The artifact may still be byte-consistent, but the documentation is not safe to repeat.

## If ResourceWarning appears

Treat it as a verifier hygiene issue. Record it for repair before release-candidate freeze.

## If zip integrity fails

Stop. The archive is not a trustworthy verification target.
