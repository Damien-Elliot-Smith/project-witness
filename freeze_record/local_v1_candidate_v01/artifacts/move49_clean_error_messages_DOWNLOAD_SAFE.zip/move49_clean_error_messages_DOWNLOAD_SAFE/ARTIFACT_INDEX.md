# Artifact Index

| Artifact ID | Filename | SHA256 | Size bytes |
|---|---|---|---|
| `MOVE48_HUMAN_REPORTS` | `human_readable_reports_v01.zip` | `6892e84750fd530386657680c2cc1f213cfec9f8020e540f11c00ca1be75739d` | 100949167 |
| `MOVE47_REVIEWER_WALKTHROUGH` | `example_reviewer_walkthrough_v01.zip` | `68a9da30e20ffca31f76ef530eaf6e514c88866392266036cc928b82c49f49f0` | 100913144 |
| `MOVE46_INDEPENDENT_VERIFIER` | `independent_verification_script_v01.zip` | `d470a5863ae550a732e00ef3b7b34ffc15c88978ebe11d0a47afd328370e2c30` | 50447770 |
| `MOVE45_VERSION_FREEZE` | `full_stack_component_version_freeze_v01.zip` | `e97e4d6dbd40254439506dea43b02e5cd87623d45ecbd6df153e6cd9568e1333` | 50421064 |
| `ROADMAP_CLEAN` | `project_witness_70_step_roadmap_clean.pdf` | `fb1c13a021f82126d0bc8b709ffaaa0ffcf89e6a29cb6a4f16caa0baafbfd27b` | 5009 |
