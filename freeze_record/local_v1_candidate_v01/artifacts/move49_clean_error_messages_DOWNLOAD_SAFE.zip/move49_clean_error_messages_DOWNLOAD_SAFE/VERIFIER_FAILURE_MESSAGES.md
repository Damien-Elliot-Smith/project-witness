# Verifier Failure Messages

This package recommends that future verifier-facing reports use the canonical codes in `ERROR_MESSAGE_REGISTRY.json`.

The actual verifiers are not changed in Move 49.

Move 49 is a documentation/readability layer only.

Future repair moves may choose to incorporate these message codes directly into verifier output, but that is not done here.
